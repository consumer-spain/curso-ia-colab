@echo off
setlocal
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo No se encuentra Python en este equipo. Levanta la mano.
    pause
    exit /b 1
  )
  set "PY=python"
)
%PY% "%~dp0COMPROBAR_BLOQUE5.py"
echo.
echo (Deja esta ventana abierta y avisa si pone FALTA.)
pause
