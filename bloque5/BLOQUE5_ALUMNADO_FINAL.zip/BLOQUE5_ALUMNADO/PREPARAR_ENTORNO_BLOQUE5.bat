@echo off
setlocal
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
echo Este programa instala SOLO estos paquetes de Python para el curso:
echo    httpx  openpyxl  pillow  playwright   (y el navegador Chromium de Playwright)
echo No modifica ajustes del sistema ni toca otros programas.
echo.
choice /m "Quieres continuar"
if errorlevel 2 exit /b 0
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m pip install --user httpx openpyxl pillow playwright
if errorlevel 1 (
  echo.
  echo La instalacion de paquetes ha fallado. Copia el mensaje de arriba y avisa.
  pause
  exit /b 1
)
%PY% -m playwright install chromium
echo.
echo Terminado. Ahora vuelve a ejecutar COMPROBAR_BLOQUE5.bat
pause
