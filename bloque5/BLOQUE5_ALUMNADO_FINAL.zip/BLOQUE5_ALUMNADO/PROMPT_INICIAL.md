# Punto de partida para la IA · Mercadona (Bloque 5)

Copia este texto en tu IA y completa lo que está entre [corchetes].

---

Quiero crear, con tu ayuda, un programa de Python para Windows que trabaje sobre la tienda online de Mercadona.

**Objetivo.** En una misma ejecución, el programa debe:
1. Obtener datos de los productos de **las categorías accesibles para el código postal [MI CÓDIGO POSTAL]**, indicando qué categorías ha intentado, cuáles ha completado y cuáles no (con el motivo).
2. Guardar **capturas individuales, legibles, de solo 2–3 productos** (la tarjeta tal como la ve una persona en la web; una imagen descargada no cuenta).
3. Para cada captura, registrar: URL de origen, producto (id y nombre), código postal, IP pública de salida (si se puede obtener de forma fiable), fecha y hora, y ruta del archivo.

**Resultado.** Un Excel o CSV fácil de revisar con una hoja/archivo de productos, otra de capturas y otra de control (recuentos, cobertura e incidencias), más la carpeta de capturas.

**Cómo quiero trabajar.**
- **Primero diagnostica, después programa.** Antes de escribir código, dime qué vía legítima y proporcionada propones para obtener los datos y cuál para las capturas. No des por hecho que un único método resuelve ambas cosas.
- Yo tengo materiales del Bloque 3 de esta misma web [capturas / HTML / JSON / respuestas de Red]. Pídeme lo que necesites y dime cómo obtenerlo **sin revelar credenciales**. Sé que la web puede haber cambiado: **compruébalo** antes de fiarte de ellos.
- Haz primero una **prueba pequeña** (2–3 categorías) y confirma que datos, capturas y contexto coinciden. Después amplía.
- Si algo falla, **conserva lo que ya funciona** y modifica solo la fase que falla.
- Deja pausas entre peticiones y limita el tráfico a lo necesario. **No intentes eludir CAPTCHA, bloqueos ni restricciones de acceso**: si la web me frena, para y dímelo.
- Si algo no es verificable, márcalo como **pendiente o no evaluable**. Nunca lo inventes. Un resultado parcial bien explicado es válido.
- Que «0 productos» o «0 capturas» **no** se marque nunca como éxito.

No necesito bases de datos, Telegram, servicios de IA por API ni sellado de tiempo. Registro de la ejecución, Programador de tareas y Healthchecks.io serían, como mucho, extras voluntarios posteriores.

**Empieza haciéndome solo las preguntas imprescindibles** (código postal, cómo ejecuto Python en mi equipo, qué material del Bloque 3 puedo compartirte). Luego propón un plan y una primera prueba pequeña.
