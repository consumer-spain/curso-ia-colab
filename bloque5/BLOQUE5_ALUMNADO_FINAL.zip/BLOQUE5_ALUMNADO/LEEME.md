# Bloque 5 · Del script al sistema · Materiales del alumnado

1. Descomprime esta carpeta en un lugar local (Documentos o Escritorio; evita OneDrive).
2. Doble clic en `COMPROBAR_BLOQUE5.bat` (solo comprueba: no instala ni modifica nada; puede hacer una consulta de conectividad para saber si la red permite llegar a los servicios, sin enviar datos del equipo). Si dice FALTA, doble clic en `PREPARAR_ENTORNO_BLOQUE5.bat` y vuelve a comprobar.
3. El **reto final** se abre más tarde en clase: `ENUNCIADO_RETO_MERCADONA.md`, `PROMPT_INICIAL.md` y `CHECKLIST_VALIDACION.md`.

Esta carpeta **no contiene soluciones**. Web del curso: https://curso-ia-consumo.onrender.com/

## Extra de la primera parte de la sesión
`BLOQUE5_EJEMPLO_RELACIONAL.sqlite` y `CONSULTA_BBDD_DEMO.sql`: base de ejemplo (datos ficticios) para abrir con DB Browser for SQLite (https://sqlitebrowser.org). No son necesarios para el reto.
