#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Comprobador de entorno · Bloque 5.
QUÉ HACE: mira la versión de Python, los paquetes, si está el navegador de Playwright, si se puede escribir en esta carpeta
(crea y borra al instante un archivo temporal vacío) y, de forma informativa, hace UNA petición de lectura (GET) a
https://tienda.mercadona.es/ para ver si hay conexión.
QUÉ NO HACE: no instala nada, no borra nada tuyo, no sube archivos ni datos tuyos a ningún sitio.
OJO: esa única petición sale de tu red como cuando abres la web: Mercadona recibe una visita normal desde tu dirección IP.
Si no quieres hacerla: python COMPROBAR_BLOQUE5.py --sin-red
Salida: una línea por comprobación (OK / FALTA / AVISO) y, al final, qué hacer."""
import importlib, os, platform, sys, tempfile, urllib.request
from pathlib import Path

PAQUETES = [("httpx", "httpx"), ("openpyxl", "openpyxl"), ("PIL", "pillow"), ("playwright", "playwright")]
faltan, avisos = [], []
SIN_RED = "--sin-red" in sys.argv

def linea(estado, texto):
    print(f"  [{estado:<5}] {texto}")

print("COMPROBACIÓN DEL BLOQUE 5")
print(f"  Sistema: {platform.system()} {platform.release()} · Python {sys.version.split()[0]}")
print()
if sys.version_info >= (3, 10):
    linea("OK", f"Python {sys.version_info.major}.{sys.version_info.minor} (se necesita 3.10 o superior)")
else:
    linea("FALTA", "Python es anterior a 3.10: pide ayuda antes de continuar"); faltan.append("python")

for modulo, paquete in PAQUETES:
    try:
        m = importlib.import_module(modulo); v = getattr(m, "__version__", "")
        linea("OK", f"{paquete} {v}".strip())
    except Exception:
        linea("FALTA", f"{paquete} no está instalado"); faltan.append(paquete)

if "playwright" not in faltan:
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            exe = Path(p.chromium.executable_path)
            if exe.exists():
                linea("OK", "Navegador de Playwright (Chromium) instalado")
            else:
                linea("FALTA", "Chromium de Playwright no instalado"); faltan.append("chromium")
    except Exception as e:
        linea("FALTA", f"Playwright no puede iniciarse ({type(e).__name__})"); faltan.append("chromium")

try:
    with tempfile.NamedTemporaryFile(dir=Path.cwd(), prefix="prueba_escritura_", delete=True):
        pass
    linea("OK", "Se puede escribir en esta carpeta")
except Exception:
    linea("FALTA", "No se puede escribir en esta carpeta: descomprime el ZIP en Documentos o en el Escritorio"); faltan.append("escritura")

if "OneDrive" in str(Path.cwd()):
    linea("AVISO", "Estás dentro de OneDrive: la sincronización puede bloquear archivos. Mejor una carpeta local."); avisos.append("onedrive")

if SIN_RED:
    linea("OMIT", "Prueba de conexión a Mercadona omitida (--sin-red)")
else:
  try:
    req = urllib.request.Request("https://tienda.mercadona.es/", headers={"User-Agent": "CursoIA-comprobador"}, method="GET")
    with urllib.request.urlopen(req, timeout=10) as r:
        linea("OK", f"La web de Mercadona responde (HTTP {r.status}); esto NO garantiza que el reto funcione")
  except Exception as e:
    linea("AVISO", f"No se pudo abrir la web de Mercadona desde este equipo ({type(e).__name__}). Avisa al docente: puede ser la red del aula."); avisos.append("red")

print()
if faltan:
    print("RESULTADO: FALTA ALGO. No es un fallo tuyo; se arregla con el preparador:")
    print("  → doble clic en PREPARAR_ENTORNO_BLOQUE5.bat  (o levanta la mano)")
    sys.exit(1)
print("RESULTADO: TODO LISTO" + (" (con avisos)" if avisos else "") + ". Puedes empezar.")
sys.exit(0)
