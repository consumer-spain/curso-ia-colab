-- Consulta usada en V9, con datos del archivo BLOQUE5_EJEMPLO_RELACIONAL.sqlite
-- E27 y E28 deben pertenecer a la misma zona y cada producto a un identificador estable.
SELECT p.nombre,
       a.precio AS antes,
       b.precio AS ahora,
       ROUND(b.precio - a.precio, 2) AS cambio
FROM observaciones a
JOIN observaciones b ON a.producto_id = b.producto_id
JOIN productos p ON p.id = a.producto_id
WHERE a.ejecucion_id = 'E27'
  AND b.ejecucion_id = 'E28'
ORDER BY cambio DESC;
