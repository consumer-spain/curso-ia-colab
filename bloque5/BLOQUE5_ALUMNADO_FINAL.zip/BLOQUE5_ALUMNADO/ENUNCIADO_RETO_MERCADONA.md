# RETO FINAL · MERCADONA · Bloque 5

## El encargo

**Tiempo orientativo:** unos 28 minutos de trabajo y 5 de validación. Es un reto simplificado: un resultado parcial bien explicado es un buen resultado.

Ya trabajaste con la tienda online de Mercadona en el Bloque 3. Ahora crea, con ayuda de una IA, **un único programa que obtenga datos de la tienda y conserve una muestra documentada de lo que vio**.

### A. Obtener los datos

Recorre las categorías de la tienda online **accesibles para el código postal que elijas** y recoge la información útil de los productos (identificador, nombre, precio, formato, categoría y URL, cuando la fuente los ofrezca).

Deja escrito **qué categorías has intentado, cuáles has completado y cuáles no** (con el motivo). Si un producto aparece en varias categorías, decide cómo cuentas y explícalo. **No inventes cifras de cobertura**: «12.345 filas» no demuestra que hayas recorrido todo.

### B. Conservar una muestra visual

Guarda **capturas individuales y legibles de 2–3 productos** (o de una categoría pequeña). La captura debe mostrar el producto **tal como lo ve una persona en la web**. Una imagen descargada del producto **no** sustituye a la captura de su tarjeta o ficha.

### C. Contexto y correspondencia

Relaciona cada captura con su producto (su fila de datos) y registra, como mínimo:

- la **URL** donde se observó;
- el **producto** (identificador y nombre);
- el **código postal** / contexto de la sesión;
- la **IP pública de salida** de esa ejecución, si puedes obtenerla de forma fiable;
- la **fecha y hora** de la captura (son las de tu equipo: contexto, **no** sello de tiempo);
- la **ruta del archivo** de la captura.

### D. Comprobar

Contrasta a mano una muestra con la web actual. Comprueba recuentos y relaciones, y anota errores y partes no evaluables. **Un resultado parcial bien explicado vale más que un total que no puedes demostrar.**

## Cómo empezar

- Puedes dar a la IA tus materiales del Bloque 3 (capturas, HTML, JSON, respuestas de la pestaña Red) **como punto de partida**. La web cambia: pide a la IA que **compruebe** que siguen sirviendo.
- **Empieza por una prueba pequeña** (2–3 categorías) y amplía después. Una ejecución completa implica muchas peticiones: deja pausas entre ellas y no sobrecargues la web.
- Cuando algo falle, no empieces de cero: enseña a la IA el error y el código, y corrige solo esa fase.
- **No intentes saltarte** CAPTCHA, bloqueos (401/403/429) ni otras medidas de protección. Si la web te frena, documenta el límite y avisa al docente: hay material de respaldo.
- No compartas con la IA contraseñas, claves ni datos personales.

## Extras voluntarios (solo si el núcleo ya funciona)

Registro de la ejecución (**log**), ejecución programada en Windows (**Programador de tareas**) o aviso externo (**Healthchecks.io**). **No son requisitos.**

## Lo que NO se pide

Bases de datos, SQL, Telegram, análisis por API de IA, sellado de tiempo, ni capturas de todos los productos.

*No es un examen: importa cómo diagnosticas, corriges y compruebas.*
