# Antes de darlo por bueno · Checklist del reto

## Cobertura de los datos
- [ ] Sé qué **código postal** y qué **fecha** usé.
- [ ] Hay un registro de **categorías intentadas / completadas / no completadas** y el motivo.
- [ ] Sé explicar el **total de filas** (¿hay productos repetidos entre categorías?).
- [ ] **Comparé a mano 2–3 productos** del Excel con la web actual (nombre, precio, formato).

## Muestra visual
- [ ] Hay **2–3 capturas individuales legibles** (o una categoría pequeña).
- [ ] Son capturas de **cómo se ve en la web**, no solo la imagen descargada del producto.
- [ ] Cada captura está **asociada a una fila** (id y nombre del producto).

## Contexto
- [ ] Cada captura tiene **URL, código postal, fecha/hora, ruta del archivo** y, si se pudo, **IP pública de salida**.
- [ ] Sé decir que la IP es la del **canal de salida** (no identifica a una persona) y que la hora es la **de mi equipo** (no es un sello de tiempo).

## Prudencia
- [ ] Lo que falló o no se pudo evaluar está **escrito**, no escondido ni inventado.
- [ ] No me he saltado ningún CAPTCHA, bloqueo ni límite de la web.
- [ ] No di por buenos materiales del Bloque 3 sin **comprobar** que la web sigue igual.
- [ ] Puedo explicar el resultado **y sus límites en 60 segundos**.

*Registro, Programador de tareas y Healthchecks.io son extras: no cuentan para esta lista.*
