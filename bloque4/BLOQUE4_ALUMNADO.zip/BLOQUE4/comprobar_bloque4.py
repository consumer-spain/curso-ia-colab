"""Comprobador inicial del Bloque 4. No modifica nada salvo un archivo temporal que borra al momento."""
from __future__ import annotations
import sys as _sys
for _f in (_sys.stdout, _sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass

import hashlib
import importlib
import os
import socket
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
problemas: list[str] = []
avisos: list[str] = []


def linea(texto: str, ok: bool | None) -> None:
    marca = {True: "OK ", False: "XX ", None: "-- "}[ok]
    print(f"  [{marca}] {texto}")


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


print("\nCOMPROBADOR · BLOQUE 4\n")

# 1. Python
print("1. Python")
ok = sys.version_info >= (3, 10)
linea(f"Python {sys.version.split()[0]}", ok)
if not ok:
    problemas.append("Se necesita Python 3.10 o posterior.")

# 2. Paquetes
print("2. Paquetes")
for modulo, paquete in [("pandas", "pandas"), ("openpyxl", "openpyxl"), ("requests", "requests"),
                        ("bs4", "beautifulsoup4"), ("PIL", "Pillow"), ("tkinter", "tkinter (solo para la Bola extra)")]:
    try:
        importlib.import_module(modulo)
        linea(paquete, True)
    except Exception:
        if modulo == "tkinter":
            linea("tkinter no disponible (solo hace falta para la Bola extra)", None)
            avisos.append("Sin tkinter: la ventana de la Bola extra no se abrirá; puedes seguirla en pareja.")
        else:
            linea(f"{paquete} NO disponible", False)
            problemas.append(f"Falta {paquete}.")

# 3. Material
print("3. Material")
if ".zip" in str(AQUI).lower() or "\\temp\\" in str(AQUI).lower():
    problemas.append("Parece que trabajas DENTRO del ZIP: descomprímelo primero (clic derecho → Extraer todo).")
esperados = {
    "01_BOOKS/obtener_libros.py": None,
    "01_BOOKS/recoger_libro.py": None,
    "01_BOOKS/RESPALDO_BOOKS/index.html": None,
    "02_INSPECTORAPP/captura_original.jpg": "6cc3cbc8e557f5cf47aa37632dccd06a6c46fabd3f9bbd18a93396066b267f50",
    "02_INSPECTORAPP/captura_reducida.jpg": "e45eba2a937c7df935401cea22f495d5050265cd4d9ebbdf28cdb1113f4ddd3e",
    "02_INSPECTORAPP/SELLO_DEMO/captura_original_demo.tsr": None,
    "02_INSPECTORAPP/2_COMPARAR_HASHES.bat": None,
    "02_INSPECTORAPP/3_VERIFICAR_SELLO.bat": None,
    "03_PAQUETE_VERIFICACION/sellado_core.py": None,
    "03_PAQUETE_VERIFICACION/COMPROBAR_PAQUETE.bat": None,
    "03_PAQUETE_VERIFICACION/EVIDENCIA_orion3_paquete_A/manifiesto.json": None,
    "03_PAQUETE_VERIFICACION/EVIDENCIA_orion3_paquete_B/manifiesto.json": None,
    "04_CONSUMOKU/00_CASO_Y_REGLAS_FINAL.pdf": None,
    "04_CONSUMOKU/01_MANIFIESTO_ANONIMO_FINAL.xlsx": None,
    "04_CONSUMOKU/04_HOJA_DEL_JURADO.xlsx": None,
    "04_CONSUMOKU/02_IMAGENES_ANONIMAS/archivo_10.jpg": None,
    "04_CONSUMOKU/03_SELLOS/INS-10_sello.tsr": None,
    "05_BOLA_EXTRA_SELLADOR/SELLADOR_BASE.py": None,
}
faltan = 0
for rel, huella in esperados.items():
    ruta = AQUI / rel
    if not ruta.exists():
        faltan += 1
        linea(f"falta {rel}", False)
    elif huella and sha256(ruta) != huella:
        linea(f"{rel} ha cambiado (no coincide con el original del curso)", False)
        problemas.append(f"{rel} no es el archivo original: vuelve a descomprimir el material.")
if faltan:
    problemas.append("Faltan archivos del material: vuelve a descomprimir el ZIP completo.")
else:
    linea("carpetas 01_BOOKS · 02_INSPECTORAPP · 03_PAQUETE_VERIFICACION · 04_CONSUMOKU · 05_BOLA_EXTRA_SELLADOR completas", True)
try:
    with tempfile.NamedTemporaryFile(dir=AQUI, delete=True):
        pass
    linea("se puede escribir en la carpeta", True)
except OSError:
    linea("no se puede escribir en la carpeta", False)
    problemas.append("No se puede escribir en la carpeta: muévela a Documentos o al Escritorio.")
try:
    sys.path.insert(0, str(AQUI / "03_PAQUETE_VERIFICACION"))
    importlib.import_module("sellado_core")
    linea("núcleo de sellado cargado", True)
except Exception as exc:
    linea(f"núcleo de sellado: {exc}", False)
    problemas.append("No se puede cargar 03_PAQUETE_VERIFICACION/sellado_core.py.")

# 4. Extensiones visibles (solo Windows)
print("4. Windows")
if os.name == "nt":
    try:
        import winreg
        clave = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                               r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced")
        ocultas = winreg.QueryValueEx(clave, "HideFileExt")[0] == 1
        linea("extensiones de archivo " + ("OCULTAS" if ocultas else "visibles"), not ocultas)
        if ocultas:
            avisos.append("Activa las extensiones: Explorador → Ver → Mostrar → Extensiones de nombre de archivo.")
    except OSError:
        linea("no se pudo comprobar si se ven las extensiones", None)
else:
    linea("no es Windows: comprobación de extensiones omitida", None)

# 5. Red (informativo: hay alternativas preparadas)
print("5. Red (informativo)")
try:
    with socket.create_connection(("books.toscrape.com", 443), timeout=4):
        linea("Books to Scrape accesible", True)
except OSError:
    linea("Books to Scrape no accesible · usa --respaldo (el .bat lo hace solo)", None)
if "--tsa" in sys.argv:   # solo para la Bola extra: no hace falta en el itinerario principal
    print("   Sellado de prueba con la TSA configurada (hasta 10 s)…")
    try:
        import shutil as _sh
        import sellado_core as _sc
        _tmp = Path(tempfile.mkdtemp(prefix="b4_prueba_tsa_"))
        try:
            _r = _sc.sellar_archivo(AQUI / "02_INSPECTORAPP" / "ARCHIVO_DE_MUESTRA.txt", _tmp, observaciones="prueba inicial")
            linea(f"TSA: sello real recibido · {_r.emisor_tsa or 'emisor no declarado'}", True)
        finally:
            _sh.rmtree(_tmp, ignore_errors=True)
    except Exception as exc:  # noqa: BLE001
        linea(f"TSA no disponible ahora · {str(exc)[:70]}", None)
else:
    linea("sellado de prueba con la TSA: omitido (solo hace falta para la Bola extra · COMPROBAR_BLOQUE4.bat --tsa)", None)

print()
if problemas:
    print("HAY ALGO QUE REVISAR · levanta la mano y deja esta ventana abierta")
    for p in problemas:
        print("  -", p)
    print("  Paquetes: py -3 -m pip install -r requirements.txt   (o python -m pip …)")
else:
    print("TODO LISTO")
for a in avisos:
    print("  Aviso:", a)
print(f"\nComando de Python que funciona en este equipo: {os.environ.get('B4_PY', 'python')}")
sys.exit(1 if problemas else 0)
