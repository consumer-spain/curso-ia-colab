#!/usr/bin/env python3
"""TALLER DEL SELLADOR · SOLUCIÓN DE REFERENCIA (recuperación).

Es la misma ventana que 02_reto_ventana_incompleta.py con ejecutar_sellado() completa.
Las cuatro decisiones del mini-reto están arriba: cambia el valor para probar otra opción.
"""
import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

from sellado_core import ErrorTSA, SelladoError, sellar_archivo

# ---- DECISIONES (mini-reto del prompt) -------------------------------------------------
SI_TSA_NO_RESPONDE = "abortar"        # "abortar" · "reintentar" (una vez y abortar) · "pendiente"
SI_CARPETA_EXISTE = "impedir"         # "impedir" · "numerar" (_2, _3…) · "otro_destino"
AL_TERMINAR = "mensaje_y_ruta"        # "mensaje" · "mensaje_y_ruta" · "abrir_carpeta"
FUENTE = "opcional_con_aviso"         # "obligatoria" · "opcional_con_aviso"
# ----------------------------------------------------------------------------------------

archivo_seleccionado = ""
destino_seleccionado = ""


def abrir_carpeta(ruta: str) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(ruta)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", ruta])
        else:
            subprocess.Popen(["xdg-open", ruta])
    except Exception:
        pass


def seleccionar_archivo():
    global archivo_seleccionado
    archivo_seleccionado = filedialog.askopenfilename(title="Elige el archivo que quieres conservar")
    etiqueta_archivo.config(text=archivo_seleccionado or "Ningún archivo seleccionado")


def seleccionar_destino():
    global destino_seleccionado
    destino_seleccionado = filedialog.askdirectory(title="Elige la carpeta donde se creará el paquete")
    etiqueta_destino.config(text=destino_seleccionado or "Ninguna carpeta seleccionada")


def ejecutar_sellado():
    global destino_seleccionado
    # 1 · leer
    fuente = entrada_fuente.get().strip()
    observaciones = entrada_observaciones.get("1.0", "end").strip()
    # 2 · validar
    if not archivo_seleccionado:
        messagebox.showwarning("Falta el archivo", "Elige primero el archivo que quieres conservar.")
        return
    if not destino_seleccionado:
        messagebox.showwarning("Falta el destino", "Elige la carpeta donde se creará el paquete.")
        return
    if not fuente:
        if FUENTE == "obligatoria":
            messagebox.showwarning("Falta la fuente", "Indica la fuente o URL de la que procede el archivo.")
            return
        if not messagebox.askyesno("Sin fuente", "No has indicado fuente o URL. ¿Crear el paquete igualmente?"):
            return
    # 3 · llamar al núcleo con las decisiones
    opciones = {
        "fuente": fuente,
        "observaciones": observaciones,
        "si_existe": "numerar" if SI_CARPETA_EXISTE == "numerar" else "error",
        "reintentos": 1 if SI_TSA_NO_RESPONDE == "reintentar" else 0,
        "si_tsa_falla": "pendiente" if SI_TSA_NO_RESPONDE == "pendiente" else "abortar",
    }
    boton_sellar.config(state="disabled")
    estado.config(text="Creando la petición y contactando con la TSA…")
    raiz.update_idletasks()
    try:
        try:
            resultado = sellar_archivo(archivo_seleccionado, destino_seleccionado, **opciones)
        except SelladoError as exc:
            if SI_CARPETA_EXISTE == "otro_destino" and str(exc).startswith("Ya existe la carpeta"):
                nuevo = filedialog.askdirectory(title="Ya existe un paquete ahí: elige otro destino")
                if not nuevo:
                    estado.config(text="Cancelado. No se ha creado ningún paquete.")
                    return
                destino_seleccionado = nuevo
                etiqueta_destino.config(text=nuevo)
                resultado = sellar_archivo(archivo_seleccionado, nuevo, **opciones)
            else:
                raise
    except ErrorTSA as exc:
        messagebox.showerror("La TSA no ha respondido",
                             f"{exc}\n\nNo se ha creado ningún paquete. El archivo de partida no se ha tocado.")
        estado.config(text="Sin paquete: la TSA no respondió.")
    except SelladoError as exc:
        messagebox.showerror("No se pudo crear el paquete", f"{exc}\n\nEl archivo de partida no se ha tocado.")
        estado.config(text="Sin paquete.")
    except Exception as exc:  # error inesperado: se muestra, la ventana sigue abierta
        messagebox.showerror("Error inesperado", repr(exc))
        estado.config(text="Error inesperado.")
    else:
        # 4 · mostrar el resultado
        if resultado.estado == "PENDIENTE_DE_SELLO":
            texto = (f"La TSA no respondió. Paquete creado y marcado PENDIENTE DE SELLO:\n{resultado.carpeta}\n\n"
                     "No tiene garantía temporal externa.")
            messagebox.showwarning("Paquete pendiente de sello", texto)
            estado.config(text="Paquete PENDIENTE DE SELLO.")
        else:
            texto = "Paquete creado. La huella sellada corresponde al original."
            if AL_TERMINAR in ("mensaje_y_ruta", "abrir_carpeta"):
                texto += (f"\n\nCarpeta: {resultado.carpeta}\nSHA-256: {resultado.sha256}"
                          f"\nHora del sello: {resultado.hora_sello}")
            messagebox.showinfo("Paquete creado", texto)
            estado.config(text="Paquete creado. Compruébalo con COMPROBAR_PAQUETE.bat")
            if AL_TERMINAR == "abrir_carpeta":
                abrir_carpeta(resultado.carpeta)
    finally:
        boton_sellar.config(state="normal")


raiz = tk.Tk()
raiz.title("Mi sellador")
raiz.geometry("760x560")
raiz.columnconfigure(0, weight=1)

tk.Label(raiz, text="CREAR PAQUETE DE EVIDENCIA", font=("Arial", 17, "bold")).grid(row=0, column=0, pady=(20, 12))

tk.Button(raiz, text="1. Elegir archivo", command=seleccionar_archivo, width=28).grid(row=1, column=0, pady=6)
etiqueta_archivo = tk.Label(raiz, text="Ningún archivo seleccionado", wraplength=680)
etiqueta_archivo.grid(row=2, column=0, pady=4)

tk.Button(raiz, text="2. Elegir destino", command=seleccionar_destino, width=28).grid(row=3, column=0, pady=6)
etiqueta_destino = tk.Label(raiz, text="Ninguna carpeta seleccionada", wraplength=680)
etiqueta_destino.grid(row=4, column=0, pady=4)

tk.Label(raiz, text="Fuente o URL").grid(row=5, column=0, pady=(12, 3))
entrada_fuente = tk.Entry(raiz, width=86)
entrada_fuente.grid(row=6, column=0, padx=20)

tk.Label(raiz, text="Observaciones").grid(row=7, column=0, pady=(12, 3))
entrada_observaciones = tk.Text(raiz, width=82, height=5)
entrada_observaciones.grid(row=8, column=0, padx=20)

boton_sellar = tk.Button(raiz, text="3. CREAR PAQUETE", command=ejecutar_sellado, width=30, height=2)
boton_sellar.grid(row=9, column=0, pady=18)
estado = tk.Label(raiz, text="Preparado.")
estado.grid(row=10, column=0)

raiz.mainloop()
