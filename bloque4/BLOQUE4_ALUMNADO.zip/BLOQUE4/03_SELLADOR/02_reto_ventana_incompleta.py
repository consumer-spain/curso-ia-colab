#!/usr/bin/env python3
"""TALLER DEL SELLADOR · la ventana de la herramienta (incompleta).

La ventana ya tiene sus campos y botones. Falta lo que hace el botón «CREAR PAQUETE»:
completa SOLO la función ejecutar_sellado(). El núcleo (sellado_core.py) no se modifica.
"""
import tkinter as tk
from tkinter import filedialog, messagebox

from sellado_core import ErrorTSA, SelladoError, sellar_archivo  # noqa: F401  (los usarás)

archivo_seleccionado = ""
destino_seleccionado = ""


def seleccionar_archivo():
    global archivo_seleccionado
    archivo_seleccionado = filedialog.askopenfilename(title="Elige el archivo que quieres conservar")
    etiqueta_archivo.config(text=archivo_seleccionado or "Ningún archivo seleccionado")


def seleccionar_destino():
    global destino_seleccionado
    destino_seleccionado = filedialog.askdirectory(title="Elige la carpeta donde se creará el paquete")
    etiqueta_destino.config(text=destino_seleccionado or "Ninguna carpeta seleccionada")


def ejecutar_sellado():
    # TODO 1 · Leer los datos: archivo_seleccionado, destino_seleccionado,
    #          entrada_fuente.get() y entrada_observaciones.get("1.0", "end").
    # TODO 2 · Validar: si falta el archivo o el destino, avisar y no seguir.
    # TODO 3 · Llamar al núcleo: sellar_archivo(archivo, destino, fuente=..., observaciones=...)
    #          y aplicar VUESTRAS DECISIONES (TSA que no responde, carpeta que ya existe,
    #          qué mostrar al terminar, fuente obligatoria u opcional).
    # TODO 4 · Mostrar el resultado (carpeta, huella, hora del sello) o el error de forma comprensible,
    #          sin que la ventana se cierre.
    messagebox.showinfo("Pendiente", "El botón todavía no hace nada: completa ejecutar_sellado().")


raiz = tk.Tk()
raiz.title("Mi sellador")
raiz.geometry("760x560")
raiz.columnconfigure(0, weight=1)

tk.Label(raiz, text="CREAR PAQUETE DE EVIDENCIA", font=("Arial", 17, "bold")).grid(row=0, column=0, pady=(20, 12))

tk.Button(raiz, text="1. Elegir archivo", command=seleccionar_archivo, width=28).grid(row=1, column=0, pady=6)
etiqueta_archivo = tk.Label(raiz, text="Ningún archivo seleccionado", wraplength=680)
etiqueta_archivo.grid(row=2, column=0, pady=4)

tk.Button(raiz, text="2. Elegir destino", command=seleccionar_destino, width=28).grid(row=3, column=0, pady=6)
etiqueta_destino = tk.Label(raiz, text="Ninguna carpeta seleccionada", wraplength=680)
etiqueta_destino.grid(row=4, column=0, pady=4)

tk.Label(raiz, text="Fuente o URL").grid(row=5, column=0, pady=(12, 3))
entrada_fuente = tk.Entry(raiz, width=86)
entrada_fuente.grid(row=6, column=0, padx=20)

tk.Label(raiz, text="Observaciones").grid(row=7, column=0, pady=(12, 3))
entrada_observaciones = tk.Text(raiz, width=82, height=5)
entrada_observaciones.grid(row=8, column=0, padx=20)

boton_sellar = tk.Button(raiz, text="3. CREAR PAQUETE", command=ejecutar_sellado, width=30, height=2)
boton_sellar.grid(row=9, column=0, pady=18)
estado = tk.Label(raiz, text="Preparado.")
estado.grid(row=10, column=0)

raiz.mainloop()
