@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% recoger_libro.py 7
if errorlevel 1 (
  echo.
  echo Repetimos con la copia local de respaldo...
  %PY% recoger_libro.py 7 --respaldo
)
echo.
pause
