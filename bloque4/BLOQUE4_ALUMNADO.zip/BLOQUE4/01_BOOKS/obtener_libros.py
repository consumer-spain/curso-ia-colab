"""Bloque 4 · Paso previo: obtener los 20 libros de la primera página de Books to Scrape.

Para cada libro entra en su ficha y añade UPC, categoría y stock exacto.
Genera libros_books.xlsx en esta misma carpeta.

Uso:
    py -3 obtener_libros.py              (o: python obtener_libros.py)
    py -3 obtener_libros.py --respaldo   sin Internet: usa la copia local preparada
"""
from __future__ import annotations
import sys as _sys
for _f in (_sys.stdout, _sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass

import argparse
import re
import sys
import time
from pathlib import Path
from urllib.parse import urljoin

try:
    import pandas as pd
    import requests
    from bs4 import BeautifulSoup
except ImportError as exc:  # mensaje comprensible si falta un paquete
    sys.exit(f"Falta un paquete: {exc.name}. Ejecuta COMPROBAR_BLOQUE4.bat o: py -3 -m pip install -r requirements.txt")

AQUI = Path(__file__).resolve().parent
URL_WEB = "https://books.toscrape.com/"
SALIDA = AQUI / "libros_books.xlsx"


def texto(elemento) -> str:
    return elemento.get_text(" ", strip=True) if elemento else ""


def leer_pagina(sesion: requests.Session, url: str) -> BeautifulSoup:
    respuesta = sesion.get(url, timeout=30)
    respuesta.raise_for_status()
    respuesta.encoding = "utf-8"
    return BeautifulSoup(respuesta.text, "html.parser")


def leer_ficha(sesion: requests.Session, url: str) -> dict:
    pagina = leer_pagina(sesion, url)
    datos = {texto(f.select_one("th")): texto(f.select_one("td")) for f in pagina.select("table.table-striped tr")}
    migas = pagina.select("ul.breadcrumb li a")
    stock = re.search(r"(\d+)\s+available", datos.get("Availability", ""))
    return {
        "UPC": datos.get("UPC", ""),
        "Categoría": texto(migas[-1]) if migas else "",
        "Stock exacto": int(stock.group(1)) if stock else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--respaldo", action="store_true", help="usar la copia local (sin Internet)")
    args = parser.parse_args()

    url = URL_WEB
    if args.respaldo:
        sys.path.insert(0, str(AQUI))
        from _respaldo import arrancar_respaldo
        url = arrancar_respaldo()
        print("Fuente: copia local de respaldo de Books to Scrape")
    else:
        print("Fuente:", URL_WEB)

    sesion = requests.Session()
    sesion.headers.update({"User-Agent": "Curso IA Consumo - practica educativa"})
    try:
        portada = leer_pagina(sesion, url)
    except requests.RequestException as exc:
        sys.exit(f"No se pudo abrir la web ({exc.__class__.__name__}).\n"
                 "Sin Internet: vuelve a ejecutarlo con --respaldo")

    tarjetas = portada.select("article.product_pod")
    filas, errores = [], []
    for numero, tarjeta in enumerate(tarjetas, start=1):
        enlace = tarjeta.select_one("h3 a")
        url_ficha = urljoin(url, enlace.get("href", ""))
        fila = {
            "Nº": numero,
            "Título": enlace.get("title", "").strip(),
            "Precio": texto(tarjeta.select_one("p.price_color")),
            "Disponibilidad": texto(tarjeta.select_one("p.availability")),
            "Valoración": tarjeta.select_one("p.star-rating").get("class", ["", ""])[-1],
            "URL ficha": url_ficha.replace(url, URL_WEB) if args.respaldo else url_ficha,
            "UPC": "", "Categoría": "", "Stock exacto": None,
        }
        try:
            fila.update(leer_ficha(sesion, url_ficha))
            estado = "OK"
        except requests.RequestException as exc:
            errores.append(f"libro {numero}: {exc.__class__.__name__}")
            estado = "ERROR"
        filas.append(fila)
        barra = "#" * numero + "." * (len(tarjetas) - numero)
        print(f"[{barra}] {numero:02d}/{len(tarjetas)} {estado}  {fila['Título'][:45]}")
        time.sleep(0.1)

    pd.DataFrame(filas).to_excel(SALIDA, index=False)
    print(f"\nExcel guardado: {SALIDA.name}")
    print(f"Libros: {len(filas)} · Errores: {len(errores)}")
    for e in errores:
        print(" -", e)


if __name__ == "__main__":
    main()
