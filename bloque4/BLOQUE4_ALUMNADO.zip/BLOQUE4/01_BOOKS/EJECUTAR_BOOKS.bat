@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
echo Ejecutando obtener_libros.py con: %PY%
echo.
%PY% obtener_libros.py
if errorlevel 1 (
  echo.
  echo La web no ha respondido. Repetimos con la copia local de respaldo...
  echo.
  %PY% obtener_libros.py --respaldo
)
echo.
pause
