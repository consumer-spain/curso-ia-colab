"""Bloque 4 · RECOGER: conservar algo más que una fila del Excel.

Toma un libro de libros_books.xlsx (por su número) y guarda en una carpeta nueva:
  - la ficha web tal como se ha recibido (HTML, sin modificar);
  - un registro de recogida: qué libro, de qué dirección, cuándo y con qué herramienta.

Uso:
    py -3 recoger_libro.py 7              (o: python recoger_libro.py 7)
    py -3 recoger_libro.py 7 --respaldo   sin Internet: usa la copia local preparada
"""
from __future__ import annotations

import argparse
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import pandas as pd
    import requests
except ImportError as exc:
    sys.exit(f"Falta un paquete: {exc.name}. Ejecuta COMPROBAR_BLOQUE4.bat")

AQUI = Path(__file__).resolve().parent
EXCEL = AQUI / "libros_books.xlsx"
URL_WEB = "https://books.toscrape.com/"
HERRAMIENTA = "recoger_libro.py · Bloque 4"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("numero", type=int, help="número del libro (columna Nº del Excel)")
    parser.add_argument("--respaldo", action="store_true", help="usar la copia local (sin Internet)")
    args = parser.parse_args()

    if not EXCEL.exists():
        sys.exit("No encuentro libros_books.xlsx. Ejecuta primero obtener_libros.py")
    tabla = pd.read_excel(EXCEL)
    fila = tabla[tabla["Nº"] == args.numero]
    if fila.empty:
        sys.exit(f"No hay ningún libro con Nº {args.numero} (el Excel tiene {len(tabla)}).")
    fila = fila.iloc[0].to_dict()
    url_ficha = fila["URL ficha"]

    url_consultada, fuente = url_ficha, "web Books to Scrape"
    if args.respaldo:
        sys.path.insert(0, str(AQUI))
        from _respaldo import arrancar_respaldo
        url_consultada = url_ficha.replace(URL_WEB, arrancar_respaldo())
        fuente = "copia local de respaldo preparada para el curso"

    print(f"[1/3] Descargando la ficha del libro {args.numero}…")
    try:
        respuesta = requests.get(url_consultada, timeout=30,
                                 headers={"User-Agent": "Curso IA Consumo - practica educativa"})
        respuesta.raise_for_status()
    except requests.RequestException as exc:
        sys.exit(f"No se pudo descargar ({exc.__class__.__name__}). Sin Internet: añade --respaldo")
    ahora = datetime.now().astimezone()

    carpeta = AQUI / f"RECOGIDA_libro_{args.numero:02d}"
    if carpeta.exists():
        carpeta = AQUI / f"RECOGIDA_libro_{args.numero:02d}_{ahora:%Y%m%d_%H%M%S}"
    carpeta.mkdir()

    print("[2/3] Guardando la ficha tal como se ha recibido…")
    html = carpeta / f"ficha_libro_{args.numero:02d}.html"
    html.write_bytes(respuesta.content)  # bytes exactos recibidos, sin reinterpretar

    print("[3/3] Escribiendo el registro de recogida…")
    registro = {
        "que_se_recogio": {
            "libro_n": int(fila["Nº"]),
            "titulo": fila["Título"],
            "precio_en_el_excel": fila["Precio"],
            "upc": fila["UPC"],
            "archivo_ficha": html.name,
            "tamano_ficha_bytes": len(respuesta.content),
        },
        "de_donde": {
            "url_ficha": url_ficha,
            "fuente_consultada": fuente,
        },
        "cuando": {
            "fecha_hora_local": ahora.isoformat(timespec="seconds"),
            "fecha_hora_utc": ahora.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
            "nota": "Hora del reloj de este equipo: es una declaración, no una garantía externa.",
        },
        "como": {
            "herramienta": HERRAMIENTA,
            "python": platform.python_version(),
            "excel_de_partida": EXCEL.name,
        },
    }
    (carpeta / "registro_recogida.json").write_text(
        json.dumps(registro, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\nCarpeta creada: {carpeta.name}")
    for p in sorted(carpeta.iterdir()):
        print("  ·", p.name)


if __name__ == "__main__":
    main()
