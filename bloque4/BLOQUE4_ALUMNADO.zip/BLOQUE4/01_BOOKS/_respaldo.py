"""Servidor local de respaldo de Books to Scrape (copia preparada para el curso).

Lo usan obtener_libros.py y recoger_libro.py cuando se añade --respaldo.
No hace falta abrirlo a mano.
"""
from __future__ import annotations

import functools
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

CARPETA = Path(__file__).resolve().parent / "RESPALDO_BOOKS"


class _Silencioso(SimpleHTTPRequestHandler):
    def log_message(self, *args):  # no llenar la terminal con cada petición
        pass


def arrancar_respaldo() -> str:
    """Arranca el respaldo en un puerto libre y devuelve su URL."""
    if not (CARPETA / "index.html").exists():
        raise SystemExit(f"No encuentro la copia de respaldo en {CARPETA}")
    manejador = functools.partial(_Silencioso, directory=str(CARPETA))
    servidor = ThreadingHTTPServer(("127.0.0.1", 0), manejador)
    hilo = threading.Thread(target=servidor.serve_forever, daemon=True)
    hilo.start()
    return f"http://127.0.0.1:{servidor.server_address[1]}/"
