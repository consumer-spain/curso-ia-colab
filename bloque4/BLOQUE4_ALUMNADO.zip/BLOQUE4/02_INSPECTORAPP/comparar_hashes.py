"""Bloque 4 · FIJAR: calcular el SHA-256 de los archivos de esta carpeta y agruparlos.

Alternativa local a la herramienta web /hash.

Uso:
    py -3 comparar_hashes.py               todos los archivos .jpg y .txt de esta carpeta
    py -3 comparar_hashes.py a.jpg b.jpg   solo los archivos indicados
    py -3 comparar_hashes.py CARPETA       todos los archivos de esa carpeta, con el SHA-256 completo
También se puede arrastrar una carpeta o varios archivos sobre 2_COMPARAR_HASHES.bat.
"""
from __future__ import annotations

import hashlib
import sys
from collections import defaultdict
from pathlib import Path

AQUI = Path(__file__).resolve().parent


def sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as f:
        for bloque in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloque)
    return h.hexdigest()


def main() -> None:
    completo = False
    if len(sys.argv) > 1:
        rutas = []
        for a in sys.argv[1:]:
            p = Path(a)
            if p.is_dir():
                completo = True
                rutas.extend(sorted(x for x in p.iterdir() if x.is_file() and not x.name.startswith(".")))
            else:
                rutas.append(p)
    else:
        rutas = sorted(p for p in AQUI.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".txt"})
    grupos = defaultdict(list)
    print(f"{'ARCHIVO':<28} {'BYTES':>8}  SHA-256 (primeros y últimos caracteres)")
    for ruta in rutas:
        if not ruta.is_file():
            print(f"No existe: {ruta}")
            continue
        h = sha256(ruta)
        grupos[h].append(ruta.name)
        print(f"{ruta.name:<28} {ruta.stat().st_size:>8}  {h[:8]}…{h[-6:]}")
    print("\nAGRUPADOS POR SHA-256 (mismo grupo = mismos bytes):")
    for h, nombres in grupos.items():
        marca = "  =  ".join(nombres)
        print(f"  {h[:8]}…{h[-6:]}  ->  {marca}" + ("" if len(nombres) > 1 else "   (único)"))
    if completo:
        print("\nSHA-256 COMPLETO (para buscarlo en un Excel con Ctrl+F):")
        for h, nombres in grupos.items():
            for n in nombres:
                print(f"  {n:<28} {h}")


if __name__ == "__main__":
    main()
