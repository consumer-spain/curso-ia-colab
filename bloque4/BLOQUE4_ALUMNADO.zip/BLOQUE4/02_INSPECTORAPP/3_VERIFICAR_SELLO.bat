@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && py -3 --version >nul 2>nul && set "PY=py -3"
%PY% verificar_sello.py %*
echo.
pause
