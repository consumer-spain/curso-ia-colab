"""Bloque 4 · VINCULAR AL TIEMPO / VERIFICAR: leer un sello .tsr y comprobar si corresponde a un archivo.

Muestra el resultado descompuesto, no un único «válido»:
  RESPUESTA · ORIGEN/TSA · TIEMPO · HUELLA SELLADA · HUELLA DEL ARCHIVO · CORRESPONDENCIA

En este equipo NO se comprueba la firma ni la cadena de confianza de la TSA:
eso lo hace /verificador en la web del curso.

Uso:
    py -3 verificar_sello.py                          original y reducida frente al sello de muestra
    py -3 verificar_sello.py archivo.jpg sello.tsr    cualquier pareja archivo + sello (en cualquier orden)
También se pueden arrastrar juntos el archivo y su .tsr sobre 3_VERIFICAR_SELLO.bat.
"""
from __future__ import annotations
import sys as _sys
for _f in (_sys.stdout, _sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass

import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / "03_PAQUETE_VERIFICACION"))  # aquí está sellado_core.py
try:
    import sellado_core as sc
except ImportError:
    sys.exit("No encuentro 03_PAQUETE_VERIFICACION/sellado_core.py. ¿Has descomprimido toda la carpeta BLOQUE4?")

SELLO_DEMO = AQUI / "SELLO_DEMO" / "captura_original_demo.tsr"


def verificar(archivo: Path, sello: Path) -> None:
    print(f"\nARCHIVO: {archivo.name}    SELLO: {sello.name}")
    try:
        d = sc.leer_sello(sello)
    except sc.SelladoError as exc:
        print(f"  RESPUESTA        NO LEGIBLE · {exc}")
        return
    huella = d["huella_sellada"]
    actual = sc.calcular_sha256(archivo)
    print("  RESPUESTA        legible · sello concedido")
    print(f"  ORIGEN / TSA     {d['emisor'] or 'no declarado en el sello'}")
    print(f"  TIEMPO (UTC)     {d['hora']}")
    print(f"  HUELLA SELLADA   {d['algoritmo']} · {huella[:8]}…{huella[-6:]}")
    print(f"  HUELLA ARCHIVO   sha256 · {actual[:8]}…{actual[-6:]}")
    print("  CORRESPONDENCIA  " + ("CORRESPONDE" if huella == actual else "NO CORRESPONDE"))
    print("  FIRMA / CADENA   no se comprueban en este equipo → /verificador de la web del curso")


def main() -> None:
    if len(sys.argv) == 3:
        a, b = Path(sys.argv[1]), Path(sys.argv[2])
        if a.suffix.lower() == ".tsr" and b.suffix.lower() != ".tsr":
            a, b = b, a  # el orden no importa: el .tsr es el sello
        verificar(a, b)
        return
    if len(sys.argv) != 1:
        sys.exit(__doc__)
    print("MUESTRA TÉCNICA · TSA DE DEMOSTRACIÓN NO CUALIFICADA")
    for nombre in ("captura_original.jpg", "captura_reducida.jpg"):
        verificar(AQUI / nombre, SELLO_DEMO)


if __name__ == "__main__":
    main()
