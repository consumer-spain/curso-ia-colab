"""Bloque 4 · CONTEXTUALIZAR: ver solo los metadatos que nos interesan de una imagen.

Alternativa local a la herramienta web /exif. No sube nada a Internet.

Uso:
    py -3 ver_metadatos.py                       muestra captura_original.jpg y captura_reducida.jpg
    py -3 ver_metadatos.py otra_imagen.jpg       muestra la imagen indicada
    py -3 ver_metadatos.py CARPETA               todas las imágenes de esa carpeta
También se puede arrastrar una carpeta o varias imágenes sobre 1_VER_METADATOS.bat.
"""
from __future__ import annotations
import sys as _sys
for _f in (_sys.stdout, _sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass

import sys
from pathlib import Path

try:
    from PIL import Image, ExifTags
except ImportError:
    sys.exit("Falta el paquete Pillow. Ejecuta COMPROBAR_BLOQUE4.bat")

AQUI = Path(__file__).resolve().parent
CAMPOS = [  # (etiqueta EXIF, nombre que mostramos)
    ("Software", "Software"),
    ("Make", "Fabricante"),
    ("Model", "Dispositivo"),
    ("DateTime", "Fecha declarada"),
    ("Orientation", "Orientación"),
]


def leer(ruta: Path) -> dict:
    with Image.open(ruta) as img:
        exif = img.getexif()
        datos = {"Dimensiones": f"{img.width} × {img.height}"}
        nombres = {ExifTags.TAGS.get(k, k): v for k, v in exif.items()}
        for etiqueta, nombre in CAMPOS:
            datos[nombre] = str(nombres.get(etiqueta, "—")).strip("\x00 ") or "—"
        gps = exif.get_ifd(0x8825) if hasattr(exif, "get_ifd") else {}
        datos["GPS"] = "sí (revisar)" if gps else "no contiene"
    return datos


def main() -> None:
    rutas = []
    for a in sys.argv[1:]:
        p = Path(a)
        if p.is_dir():
            rutas.extend(sorted(x for x in p.iterdir() if x.suffix.lower() in {".jpg", ".jpeg", ".png"}))
        else:
            rutas.append(p)
    rutas = rutas or [AQUI / "captura_original.jpg", AQUI / "captura_reducida.jpg"]
    for ruta in rutas:
        if not ruta.is_file():
            print(f"No existe: {ruta}")
            continue
        print(f"\n{ruta.name}")
        print("-" * len(ruta.name))
        for nombre, valor in leer(ruta).items():
            print(f"  {nombre:<16} {valor}")
    print("\nRecuerda: los metadatos forman parte del archivo y pueden alterarse o desaparecer.")


if __name__ == "__main__":
    main()
