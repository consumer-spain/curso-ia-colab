#!/usr/bin/env python3
"""BOLA EXTRA · SELLADOR_BASE.py  ·  un sellador que FUNCIONA, pero es incómodo.

Hace el trabajo completo (conserva el original, calcula el SHA-256, pide el sello a la TSA,
comprueba que la huella sellada corresponde y escribe el manifiesto) llamando al núcleo
sellado_core.py. Pero:
  · solo funciona desde la terminal,
  · hay que escribir las rutas a mano,
  · no hay ventana, ni botones, ni barra de progreso,
  · los mensajes son secos.

Uso:
    py -3 SELLADOR_BASE.py                                   (te va preguntando)
    py -3 SELLADOR_BASE.py ARCHIVO CARPETA_DESTINO [FUENTE]  (todo de una vez)

Ejemplo con el archivo de muestra:
    py -3 SELLADOR_BASE.py MUESTRA\\captura_orion3.jpg MIS_EVIDENCIAS https://hogarprueba.test/productos/orion-3
"""
from __future__ import annotations

import sys
for _f in (sys.stdout, sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass
from pathlib import Path

from sellado_core import ErrorTSA, SelladoError, sellar_archivo


def limpia(ruta: str) -> str:
    """Quita las comillas que añade Windows al arrastrar un archivo a la terminal."""
    return ruta.strip().strip('"').strip("'")


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) >= 2:
        archivo, destino = limpia(args[0]), limpia(args[1])
        fuente = args[2] if len(args) > 2 else ""
    else:
        print("SELLADOR_BASE · escribe las rutas a mano (o arrastra el archivo a esta ventana)")
        archivo = limpia(input("Archivo a conservar: "))
        destino = limpia(input("Carpeta de destino: "))
        fuente = input("Fuente o URL (puede quedar vacía): ").strip()
    observaciones = ""

    if not archivo or not Path(archivo).is_file():
        print(f"ERROR: no existe el archivo '{archivo}'.")
        return 1
    if not destino:
        print("ERROR: falta la carpeta de destino.")
        return 1

    print("Creando petición y contactando con la TSA...")
    try:
        r = sellar_archivo(archivo, destino, fuente=fuente, observaciones=observaciones)
    except ErrorTSA as exc:
        print(f"ERROR: la TSA no ha respondido: {exc}")
        print("No se ha creado ningún paquete. El archivo de partida no se ha tocado.")
        return 2
    except SelladoError as exc:
        print(f"ERROR: {exc}")
        print("El archivo de partida no se ha tocado.")
        return 3
    print("")
    print("Paquete creado.")
    print("Carpeta:        ", r.carpeta)
    print("Estado:         ", r.estado)
    print("SHA-256:        ", r.sha256)
    print("Hora del sello: ", r.hora_sello)
    print("TSA:            ", r.emisor_tsa)
    return 0


if __name__ == "__main__":
    sys.exit(main())
