#!/usr/bin/env python3
"""Bloque 4 · CONFIGURAR LA TSA DE ESTE EQUIPO (solo si el docente lo indica).

Por defecto el sellador usa el servicio de sellado de tiempo de la ACCV y no necesita configurar nada.
Si el docente os da un archivo de configuración del aula (por ejemplo TSA_AULA.json) o unos datos:

    arrastra el archivo TSA_AULA.json sobre CONFIGURAR_TSA.bat      → lo instala en este equipo
    doble clic en CONFIGURAR_TSA.bat                                → pregunta los datos
    py -3 configurar_tsa.py --probar                                → solo hace un sellado de prueba
    py -3 configurar_tsa.py --borrar                                → borra la configuración del equipo

La configuración se guarda FUERA de la carpeta del curso (no viaja en ningún ZIP):
    Windows: %LOCALAPPDATA%\\CursoIA\\tsa.json
La contraseña, si existe, nunca se muestra en pantalla.
"""
from __future__ import annotations

import getpass
import json
import shutil
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI / "03_SELLADOR"))
import sellado_core as sc  # noqa: E402


def mostrar() -> None:
    ruta = sc.ruta_config_tsa()
    cfg = sc._config_equipo()
    print(f"Configuración del equipo: {ruta if ruta.exists() else 'ninguna (se usa la TSA de la ACCV)'}")
    print(f"  URL:        {cfg.get('url') or sc.TSA_URL_PUBLICADA}")
    print(f"  Usuario:    {'definido' if cfg.get('usuario') else 'ninguno'}")
    print(f"  Contraseña: {'definida (no se muestra)' if cfg.get('contrasena') else 'ninguna'}")


def guardar(cfg: dict) -> None:
    limpio = {k: cfg[k] for k in ("url", "usuario", "contrasena", "timeout") if cfg.get(k)}
    ruta = sc.ruta_config_tsa()
    ruta.parent.mkdir(parents=True, exist_ok=True)
    ruta.write_text(json.dumps(limpio, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Guardada en {ruta}")


def probar() -> int:
    muestra = AQUI / "02_INSPECTORAPP" / "ARCHIVO_DE_MUESTRA.txt"
    tmp = Path(tempfile.mkdtemp(prefix="b4_prueba_tsa_"))
    print("\nSellado de prueba de ARCHIVO_DE_MUESTRA.txt · contactando con la TSA (hasta 10 s)…")
    try:
        r = sc.sellar_archivo(muestra, tmp, observaciones="prueba de configuración")
        print(f"  [OK] sello recibido · TSA: {r.emisor_tsa or 'no declarada'} · hora: {r.hora_sello}")
        print("  [OK] la huella sellada corresponde al archivo")
        return 0
    except sc.SelladoError as exc:
        print(f"  [XX] {exc}")
        print("  Avisa al docente. Si la TSA no está disponible para el aula se usará el paquete de contingencia.")
        return 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> int:
    args = sys.argv[1:]
    if args[:1] == ["--borrar"]:
        ruta = sc.ruta_config_tsa()
        if ruta.exists():
            ruta.unlink()
            print(f"Borrada {ruta}")
        else:
            print("No había configuración en este equipo.")
        return 0
    if args[:1] == ["--probar"]:
        mostrar()
        return probar()
    if args:
        origen = Path(args[0])
        try:
            cfg = json.loads(origen.read_text(encoding="utf-8"))
            assert isinstance(cfg, dict) and cfg.get("url")
        except Exception:
            print(f"{origen.name} no es un archivo de configuración válido (debe tener al menos «url»).")
            return 1
        guardar(cfg)
    else:
        mostrar()
        print("\nPulsa Intro para dejar cada dato como está.")
        actual = sc._config_equipo()
        url = input(f"URL de la TSA [{actual.get('url') or sc.TSA_URL_PUBLICADA}]: ").strip() or actual.get("url")
        usuario = input("Usuario (si el docente os lo ha dado): ").strip() or actual.get("usuario")
        contrasena = getpass.getpass("Contraseña (no se verá al escribir): ").strip() or actual.get("contrasena")
        if url or usuario or contrasena:
            guardar({"url": url, "usuario": usuario, "contrasena": contrasena})
    mostrar()
    return probar()


if __name__ == "__main__":
    sys.exit(main())
