@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "B4_PY=python"
where py >nul 2>nul && py -3 --version >nul 2>nul && set "B4_PY=py -3"
%B4_PY% comprobar_bloque4.py
echo.
pause
