#!/usr/bin/env python3
r"""sellado_core.py · núcleo reutilizable del sellador del Bloque 4 (versión 3).

Qué hace sellar_archivo(), en este orden (es la misma lógica que se dibuja en clase):

    original      = conservar_archivo(archivo, carpeta)      copia exacta, el de partida no se toca
    huella        = calcular_sha256(original)
    peticion      = preparar_peticion(original, ...)          la petición lleva la huella, no el archivo
    sello         = pedir_sello(peticion, ...)                 envío a la TSA y respuesta .tsr
    datos_sello   = leer_sello(sello)                          hora, huella sellada, emisor
    si datos_sello["huella_sellada"] != huella  ->  error y no queda paquete
    crear_manifiesto(...)                                      relaciona las piezas del paquete

Solo usa la biblioteca estándar de Python (sin programas externos). La petición y la
lectura del sello siguen el RFC 3161, el estándar técnico para pedir y recibir sellos
de tiempo. La firma y la cadena de certificados de la TSA NO se comprueban aquí: eso lo
hace un verificador independiente (por ejemplo, /verificador en la web del curso).

Configuración de la TSA (nunca dentro del código ni del ZIP), por orden de prioridad:
  1. argumentos de sellar_archivo(tsa_url=..., usuario=..., contrasena=..., timeout=...)
  2. variables de entorno TSA_URL, TSA_USER, TSA_PASSWORD, TSA_TIMEOUT
  3. archivo de configuración del equipo creado con CONFIGURAR_TSA.bat
     (Windows: %LOCALAPPDATA%/CursoIA/tsa.json · otros: ~/.config/cursoia/tsa.json)
  4. URL publicada de la TSA de la ACCV, sin credenciales.
"""
from __future__ import annotations

import base64
import secrets
import hashlib
import http.client
import json
import mimetypes
import os
import re
import shutil
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

TSA_URL_PUBLICADA = "http://tss.accv.es:8318/tsa"
TSA_TIMEOUT_DEFAULT = 10


class SelladoError(RuntimeError):
    """Error comprensible para la interfaz del curso."""


def calcular_sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as f:
        for bloque in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloque)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# DER mínimo (RFC 3161 / CMS). Solo lo necesario para crear la petición y leer
# los campos del sello. La validación criptográfica de la firma de la TSA se
# hace en el verificador del curso.
# ---------------------------------------------------------------------------
OID_SHA256 = "2.16.840.1.101.3.4.2.1"
OID_SIGNED_DATA = "1.2.840.113549.1.7.2"
OID_TST_INFO = "1.2.840.113549.1.9.16.1.4"
NOMBRES_HASH = {
    OID_SHA256: "sha256",
    "1.3.14.3.2.26": "sha1",
    "2.16.840.1.101.3.4.2.2": "sha384",
    "2.16.840.1.101.3.4.2.3": "sha512",
}
ESTADOS_PKI = {
    0: "Granted.",
    1: "Granted with modifications.",
    2: "Rejected.",
    3: "Waiting.",
    4: "Revocation warning.",
    5: "Revoked.",
}


def _der(tag: int, contenido: bytes) -> bytes:
    n = len(contenido)
    if n < 0x80:
        longitud = bytes([n])
    else:
        cuerpo = n.to_bytes((n.bit_length() + 7) // 8, "big")
        longitud = bytes([0x80 | len(cuerpo)]) + cuerpo
    return bytes([tag]) + longitud + contenido


def _der_entero(valor: int) -> bytes:
    cuerpo = valor.to_bytes(max(1, (valor.bit_length() + 8) // 8), "big", signed=True)
    return _der(0x02, cuerpo)


def _der_oid(oid: str) -> bytes:
    partes = [int(x) for x in oid.split(".")]
    cuerpo = bytearray([40 * partes[0] + partes[1]])
    for valor in partes[2:]:
        trozos = [valor & 0x7F]
        valor >>= 7
        while valor:
            trozos.append(0x80 | (valor & 0x7F))
            valor >>= 7
        cuerpo.extend(reversed(trozos))
    return _der(0x06, bytes(cuerpo))


def _leer(datos: bytes, pos: int = 0) -> tuple[int, bytes, int]:
    """Devuelve (etiqueta, contenido, posición siguiente) de un elemento DER."""
    if pos + 2 > len(datos):
        raise ValueError("estructura ASN.1 incompleta")
    tag = datos[pos]
    if tag & 0x1F == 0x1F:
        raise ValueError("etiqueta ASN.1 no soportada")
    longitud = datos[pos + 1]
    pos += 2
    if longitud & 0x80:
        num = longitud & 0x7F
        if num == 0 or num > 4 or pos + num > len(datos):
            raise ValueError("longitud ASN.1 no válida")
        longitud = int.from_bytes(datos[pos:pos + num], "big")
        pos += num
    fin = pos + longitud
    if fin > len(datos):
        raise ValueError("estructura ASN.1 truncada")
    return tag, datos[pos:fin], fin


def _hijos(contenido: bytes) -> list[tuple[int, bytes]]:
    elementos, pos = [], 0
    while pos < len(contenido):
        tag, valor, pos = _leer(contenido, pos)
        elementos.append((tag, valor))
    return elementos


def _unico(datos: bytes) -> tuple[int, bytes]:
    tag, valor, fin = _leer(datos)
    if fin != len(datos):
        raise ValueError("datos sobrantes tras la estructura ASN.1")
    return tag, valor


def _oid_texto(contenido: bytes) -> str:
    partes, valor = [], 0
    for byte in contenido:
        valor = (valor << 7) | (byte & 0x7F)
        if not byte & 0x80:
            partes.append(valor)
            valor = 0
    primero = min(partes[0] // 40, 2)
    return ".".join(str(x) for x in [primero, partes[0] - 40 * primero, *partes[1:]])


def _octetos(tag: int, contenido: bytes) -> bytes:
    if tag == 0x04:
        return contenido
    if tag == 0x24:  # OCTET STRING construido (BER): se concatenan los trozos
        return b"".join(_octetos(t, v) for t, v in _hijos(contenido))
    raise ValueError("se esperaba un OCTET STRING")


def _fecha_legible(generalized_time: bytes) -> str:
    """Convierte GeneralizedTime a texto UTC legible ("Oct 14 16:00:00 2026 GMT")."""
    texto = generalized_time.decode("ascii")
    m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\.\d+)?Z", texto)
    if not m:
        return texto
    anio, mes, dia, h, mi, se, frac = m.groups()
    meses = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()
    return f"{meses[int(mes) - 1]} {int(dia):2d} {h}:{mi}:{se}{frac or ''} {anio} GMT"


def _volcado_hex(datos: bytes) -> list[str]:
    return [f"    {i:04x} - " + " ".join(f"{b:02x}" for b in datos[i:i + 16])
            for i in range(0, len(datos), 16)]


def _analizar_tst_info(tst: bytes) -> dict:
    campos = _hijos(_unico(tst)[1])
    version = int.from_bytes(campos[0][1], "big", signed=True)
    politica = _oid_texto(campos[1][1])
    imprint = _hijos(campos[2][1])
    algoritmo = _hijos(imprint[0][1])
    oid_hash = _oid_texto(algoritmo[0][1])
    resultado = {
        "version": version,
        "politica": politica,
        "algoritmo": NOMBRES_HASH.get(oid_hash, oid_hash),
        "imprint": _octetos(*imprint[1]),
        "serie": int.from_bytes(campos[3][1], "big", signed=True),
        "fecha": _fecha_legible(campos[4][1]),
        "nonce": None,
    }
    resultado["emisor"] = ""
    for tag, valor in campos[5:]:
        if tag == 0x02:  # el único INTEGER opcional de TSTInfo es el nonce
            resultado["nonce"] = int.from_bytes(valor, "big", signed=True)
        elif tag == 0xA0:  # campo opcional «tsa» (GeneralName): buscamos el CN
            resultado["emisor"] = _buscar_cn(valor)
    return resultado


OID_CN = "2.5.4.3"


def _buscar_cn(contenido: bytes) -> str:
    try:
        pendientes = [_unico(contenido)]
        while pendientes:
            t, v = pendientes.pop()
            if t in (0x30, 0x31, 0xA4):
                hijos = _hijos(v)
                if len(hijos) == 2 and hijos[0][0] == 0x06 and _oid_texto(hijos[0][1]) == OID_CN:
                    return hijos[1][1].decode("utf-8", errors="replace")
                pendientes.extend(hijos)
    except (ValueError, IndexError):
        pass
    return ""


def _analizar_token(token: bytes) -> dict:
    """ContentInfo (SignedData) que contiene el TSTInfo."""
    content_info = _hijos(_unico(token)[1])
    if content_info[0][0] != 0x06 or _oid_texto(content_info[0][1]) != OID_SIGNED_DATA:
        raise ValueError("el sello no contiene una estructura SignedData")
    signed_data = _hijos(_unico(content_info[1][1])[1])
    encap = _hijos(signed_data[2][1])
    if _oid_texto(encap[0][1]) != OID_TST_INFO:
        raise ValueError("el sello no contiene un TSTInfo")
    explicito = _unico(encap[1][1])
    return _analizar_tst_info(_octetos(*explicito))


def _analizar_respuesta(datos: bytes) -> tuple[Optional[int], list[str], Optional[dict]]:
    """Devuelve (estado PKI o None si es un token suelto, textos de estado, TSTInfo)."""
    tag, contenido = _unico(datos)
    if tag != 0x30:
        raise ValueError("la respuesta no es una estructura ASN.1 válida")
    hijos = _hijos(contenido)
    if hijos and hijos[0][0] == 0x06:  # token suelto (ContentInfo), sin estado
        return None, [], _analizar_token(datos)
    estado_info = _hijos(hijos[0][1])
    estado = int.from_bytes(estado_info[0][1], "big", signed=True)
    textos = []
    for t, v in estado_info[1:]:
        if t == 0x30:
            textos = [s.decode("utf-8", errors="replace") for _, s in _hijos(v)]
    if len(hijos) < 2:
        return estado, textos, None
    token_tag, token_valor = hijos[1]
    return estado, textos, _analizar_token(_der(token_tag, token_valor))


def describir_motor() -> str:
    """Describe el motor usado para crear y leer los sellos (se guarda en el manifiesto)."""
    import platform
    return f"sellado_core.py · RFC 3161 en Python {platform.python_version()} (biblioteca estándar)"


def crear_peticion_tsa(archivo: Path, salida_tsq: Path) -> None:
    """Petición RFC 3161 estándar: SHA-256 del archivo, nonce aleatorio de
    64 bits y solicitud del certificado de la TSA (certReq = TRUE)."""
    try:
        resumen = bytes.fromhex(calcular_sha256(Path(archivo)))
        nonce = secrets.randbits(64) | 1
        peticion = _der(0x30, b"".join([
            _der_entero(1),
            _der(0x30, _der(0x30, _der_oid(OID_SHA256) + b"\x05\x00") + _der(0x04, resumen)),
            _der_entero(nonce),
            b"\x01\x01\xff",
        ]))
        Path(salida_tsq).write_bytes(peticion)
    except OSError as exc:
        raise SelladoError(f"No se pudo crear la petición RFC 3161: {exc}") from exc


def _nonce_peticion(peticion_tsq: Path) -> Optional[int]:
    try:
        for tag, valor in _hijos(_unico(Path(peticion_tsq).read_bytes())[1])[2:]:
            if tag == 0x02:
                return int.from_bytes(valor, "big", signed=True)
    except (OSError, ValueError, IndexError):
        pass
    return None


def ruta_config_tsa() -> Path:
    """Archivo de configuración de la TSA de este equipo (fuera de la carpeta del curso)."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        return base / "CursoIA" / "tsa.json"
    return Path.home() / ".config" / "cursoia" / "tsa.json"


def _config_equipo() -> dict:
    try:
        datos = json.loads(ruta_config_tsa().read_text(encoding="utf-8"))
        return datos if isinstance(datos, dict) else {}
    except (OSError, ValueError):
        return {}


def _resolver_config_tsa(
    tsa_url: Optional[str],
    usuario: Optional[str],
    contrasena: Optional[str],
    timeout: Optional[int],
) -> tuple[str, Optional[str], Optional[str], int]:
    cfg = _config_equipo()
    url = tsa_url or os.environ.get("TSA_URL") or cfg.get("url") or TSA_URL_PUBLICADA
    user = usuario if usuario is not None else (os.environ.get("TSA_USER") or cfg.get("usuario") or None)
    pwd = contrasena if contrasena is not None else (os.environ.get("TSA_PASSWORD") or cfg.get("contrasena") or None)
    if timeout is None:
        raw = os.environ.get("TSA_TIMEOUT") or str(cfg.get("timeout") or TSA_TIMEOUT_DEFAULT)
        try:
            resolved_timeout = max(1, int(raw))
        except ValueError as exc:
            raise SelladoError("TSA_TIMEOUT debe ser un número entero de segundos.") from exc
    else:
        resolved_timeout = max(1, int(timeout))
    return url, user, pwd, resolved_timeout


def enviar_peticion_tsa(
    peticion_tsq: Path,
    salida_tsr: Path,
    tsa_url: Optional[str] = None,
    usuario: Optional[str] = None,
    contrasena: Optional[str] = None,
    timeout: Optional[int] = None,
) -> str:
    url, user, pwd, timeout_s = _resolver_config_tsa(
        tsa_url, usuario, contrasena, timeout
    )
    datos = peticion_tsq.read_bytes()
    cabeceras = {
        "Content-Type": "application/timestamp-query",
        "Accept": "application/timestamp-reply",
        "User-Agent": "Curso-IA-Consumo-Sellador/3.0",
    }
    if user:
        token = base64.b64encode(f"{user}:{pwd or ''}".encode()).decode()
        cabeceras["Authorization"] = f"Basic {token}"
    solicitud = urllib.request.Request(url, data=datos, headers=cabeceras, method="POST")
    try:
        with urllib.request.urlopen(solicitud, timeout=timeout_s) as respuesta:
            cuerpo = respuesta.read()
    except urllib.error.HTTPError as exc:
        detalle = exc.read().decode("utf-8", errors="replace")
        raise SelladoError(f"La TSA respondió HTTP {exc.code}: {detalle[:300]}") from exc
    except urllib.error.URLError as exc:
        raise SelladoError(
            f"No se pudo conectar con la TSA en {timeout_s} s: {exc.reason}"
        ) from exc
    except TimeoutError as exc:
        raise SelladoError(f"La TSA no respondió en {timeout_s} s.") from exc
    except (http.client.HTTPException, OSError) as exc:
        raise SelladoError(f"La conexión con la TSA se interrumpió: {exc}") from exc
    if not cuerpo:
        raise SelladoError("La TSA devolvió una respuesta vacía.")
    salida_tsr.write_bytes(cuerpo)
    return url


def comprobar_respuesta_tsr(sello_tsr: Path) -> str:
    """Lee el sello y devuelve un resumen de texto (estado, algoritmo, huella,
    serie, fecha y nonce). Falla si la TSA no concede el sello."""
    try:
        estado, textos, tst = _analizar_respuesta(Path(sello_tsr).read_bytes())
    except (OSError, ValueError, IndexError) as exc:
        raise SelladoError(f"La respuesta recibida no parece un sello legible: {exc}") from exc
    if estado is not None and estado not in (0, 1):
        motivo = f" ({'; '.join(textos)})" if textos else ""
        raise SelladoError(
            "La TSA devolvió una respuesta RFC 3161 que no concede el sello: "
            f"{ESTADOS_PKI.get(estado, estado)}{motivo}"
        )
    if tst is None:
        raise SelladoError("La TSA devolvió una respuesta RFC 3161 que no concede el sello.")
    lineas = []
    if estado is not None:
        lineas += ["Status info:", f"Status: {ESTADOS_PKI[estado]}", ""]
    lineas += [
        "TST info:",
        f"Version: {tst['version']}",
        f"Policy OID: {tst['politica']}",
        "Hash Algorithm: " + tst["algoritmo"],
        "Message data:",
        *_volcado_hex(tst["imprint"]),
        f"Serial number: 0x{tst['serie']:X}",
        f"Time stamp: {tst['fecha']}",
        "Nonce: " + (f"0x{tst['nonce']:X}" if tst["nonce"] is not None else "unspecified"),
    ]
    return "\n".join(lineas) + "\n"


def _extraer_nonce(detalle_tsr: str) -> Optional[int]:
    m = re.search(r"^Nonce:\s*0x([0-9A-Fa-f]+)", detalle_tsr, flags=re.M)
    return int(m.group(1), 16) if m else None


def _extraer_imprint(detalle_tsr: str) -> tuple[str, str]:
    alg = re.search(r"Hash Algorithm:\s*([^\s]+)", detalle_tsr, flags=re.I)
    if not alg:
        raise SelladoError("No se pudo identificar el algoritmo del messageImprint.")
    lineas = detalle_tsr.splitlines()
    inicio = next((i for i, l in enumerate(lineas) if "Message data:" in l), None)
    if inicio is None:
        raise SelladoError("No se encontró el messageImprint en el sello.")
    pares: list[str] = []
    for linea in lineas[inicio + 1:]:
        if not re.match(r"\s*[0-9A-Fa-f]{4}\s*-", linea):
            break
        parte = linea.split("-", 1)[1]
        # El volcado separa la parte hexadecimal de la ASCII con varios espacios.
        parte_hex = re.split(r"\s{3,}", parte, maxsplit=1)[0]
        pares.extend(re.findall(r"(?<![0-9A-Fa-f])[0-9A-Fa-f]{2}(?![0-9A-Fa-f])", parte_hex))
    if not pares:
        raise SelladoError("No se pudo extraer el valor del messageImprint.")
    return alg.group(1).lower(), "".join(pares).lower()


def comprobar_correspondencia_tsr(sello_tsr: Path, archivo: Path) -> tuple[bool, str, str]:
    detalle = comprobar_respuesta_tsr(sello_tsr)
    algoritmo, imprint = _extraer_imprint(detalle)
    if algoritmo not in {"sha256", "sha-256"}:
        raise SelladoError(
            f"El sello usa {algoritmo}; esta práctica espera SHA-256."
        )
    actual = calcular_sha256(archivo)
    return imprint == actual, imprint, detalle


def _extraer_fecha_sello(detalle_tsr: str) -> str:
    m = re.search(r"^Time stamp:\s*(.+)$", detalle_tsr, flags=re.I | re.M)
    return m.group(1).strip() if m else ""


# ---------------------------------------------------------------------------
# Funciones con el nombre de cada paso de la lógica (ver docstring del módulo)
# ---------------------------------------------------------------------------
def conservar_archivo(archivo: Path, carpeta: Path) -> Path:
    """Copia exacta del archivo de partida dentro de la carpeta del paquete."""
    copia = carpeta / f"original{Path(archivo).suffix.lower()}"
    shutil.copy2(archivo, copia)
    if calcular_sha256(Path(archivo)) != calcular_sha256(copia):
        raise SelladoError("La copia del original no coincide byte a byte con el archivo de partida.")
    return copia


def preparar_peticion(original: Path, carpeta: Path) -> Path:
    """Petición de sellado (.tsq): contiene la huella SHA-256; el archivo no sale del equipo."""
    peticion = carpeta / "peticion.tsq"
    crear_peticion_tsa(original, peticion)
    return peticion


def pedir_sello(peticion: Path, carpeta: Path, tsa_url=None, usuario=None, contrasena=None,
                timeout=None, reintentos: int = 0) -> tuple[Path, str]:
    """Envía la petición a la TSA y guarda su respuesta (.tsr). Devuelve (sello, url usada)."""
    sello = carpeta / "sello.tsr"
    ultimo: Optional[SelladoError] = None
    for _ in range(max(0, int(reintentos)) + 1):
        try:
            url = enviar_peticion_tsa(peticion, sello, tsa_url=tsa_url, usuario=usuario,
                                      contrasena=contrasena, timeout=timeout)
            return sello, url
        except SelladoError as exc:
            ultimo = exc
    raise ErrorTSA(str(ultimo))


def leer_sello(sello: Path) -> dict:
    """Lo que dice el sello: estado, hora, huella sellada (messageImprint), algoritmo, emisor, serie, nonce."""
    try:
        estado, textos, tst = _analizar_respuesta(Path(sello).read_bytes())
    except (OSError, ValueError, IndexError) as exc:
        raise SelladoError(f"La respuesta recibida no parece un sello legible: {exc}") from exc
    if (estado is not None and estado not in (0, 1)) or tst is None:
        motivo = f" ({'; '.join(textos)})" if textos else ""
        raise SelladoError("La TSA no ha concedido el sello: "
                           f"{ESTADOS_PKI.get(estado, estado) if estado is not None else 'sin token'}{motivo}")
    return {
        "estado": "concedido",
        "hora": tst["fecha"],
        "algoritmo": tst["algoritmo"],
        "huella_sellada": tst["imprint"].hex(),
        "emisor": tst.get("emisor", ""),
        "numero_serie": f"{tst['serie']:X}",
        "nonce": tst["nonce"],
    }


def crear_manifiesto(carpeta: Path, contenido: dict) -> Path:
    manifiesto = carpeta / "manifiesto.json"
    manifiesto.write_text(json.dumps(contenido, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifiesto


class ErrorTSA(SelladoError):
    """La TSA no ha respondido o no ha concedido el sello (red, HTTP, timeout, rechazo)."""


@dataclass
class ResultadoSellado:
    carpeta: str
    estado: str                      # "SELLADO" o "PENDIENTE_DE_SELLO"
    original: str
    sha256: str
    tamano_bytes: int
    peticion: str
    sello: str                       # "" si está pendiente de sello
    manifiesto: str
    tsa_url: str
    hora_sello: str                  # "" si está pendiente de sello
    huella_sellada: str              # "" si está pendiente de sello
    emisor_tsa: str
    corresponde: bool
    aviso: str = ""                  # motivo si quedó pendiente


def _carpeta_destino(destino_base: Path, nombre: str, si_existe: str) -> Path:
    carpeta = destino_base / nombre
    if not carpeta.exists():
        return carpeta
    if si_existe == "numerar":
        n = 2
        while (destino_base / f"{nombre}_{n}").exists():
            n += 1
        return destino_base / f"{nombre}_{n}"
    raise SelladoError(f"Ya existe la carpeta {carpeta.name} en el destino. No se sobrescribe: "
                       "elige otro destino o borra/renombra la carpeta anterior.")


def sellar_archivo(
    archivo: str | Path,
    destino: str | Path,
    fuente: str = "",
    observaciones: str = "",
    tsa_url: Optional[str] = None,
    usuario: Optional[str] = None,
    contrasena: Optional[str] = None,
    timeout: Optional[int] = None,
    si_existe: str = "error",
    reintentos: int = 0,
    si_tsa_falla: str = "abortar",
) -> ResultadoSellado:
    """Crea EVIDENCIA_<nombre> en `destino` con original, peticion.tsq, sello.tsr y manifiesto.json.

    si_existe     "error" (por defecto: no sobrescribe y avisa) · "numerar" (EVIDENCIA_x_2, _3…)
    reintentos    veces que se repite la petición si la TSA no responde (0 = ninguna)
    si_tsa_falla  "abortar" (por defecto: no queda ningún paquete) ·
                  "pendiente" (queda EVIDENCIA_<nombre>_PENDIENTE_DE_SELLO, sin sello y marcado así)
    Lanza SelladoError con un mensaje comprensible si algo falla.
    """
    if si_existe not in ("error", "numerar"):
        raise ValueError("si_existe debe ser 'error' o 'numerar'")
    if si_tsa_falla not in ("abortar", "pendiente"):
        raise ValueError("si_tsa_falla debe ser 'abortar' o 'pendiente'")
    origen = Path(archivo).expanduser().resolve()
    if not origen.is_file():
        raise SelladoError("El archivo seleccionado no existe o no es un archivo.")
    destino_base = Path(destino).expanduser().resolve()
    if destino_base == origen.parent or origen.parent in destino_base.parents:
        pass  # está permitido; el original nunca se modifica
    destino_base.mkdir(parents=True, exist_ok=True)
    carpeta = _carpeta_destino(destino_base, f"EVIDENCIA_{origen.stem}", si_existe)
    carpeta.mkdir()
    ahora = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    url_config = _resolver_config_tsa(tsa_url, usuario, contrasena, timeout)[0]

    try:
        original = conservar_archivo(origen, carpeta)
        huella = calcular_sha256(original)
        peticion = preparar_peticion(original, carpeta)
        contexto = {"nombre_archivo_de_partida": origen.name, "fuente_o_url": fuente,
                    "observaciones": observaciones}
        calculado = {"sha256": huella, "tamano_bytes": original.stat().st_size,
                     "tipo_mime": mimetypes.guess_type(original.name)[0] or "application/octet-stream",
                     "copia_identica_al_archivo_de_partida": True,
                     "hora_local_de_ejecucion_utc": ahora}
        proceso = {"tsa_llamada": url_config, "reintentos_configurados": int(reintentos),
                   "motor": describir_motor()}
        try:
            sello, url_usada = pedir_sello(peticion, carpeta, tsa_url, usuario, contrasena, timeout, reintentos)
        except ErrorTSA as exc:
            if si_tsa_falla != "pendiente":
                raise
            # Paquete marcado inequívocamente como PENDIENTE DE SELLO (sin .tsr).
            pendiente = _carpeta_destino(destino_base, carpeta.name + "_PENDIENTE_DE_SELLO", "numerar")
            calculado["huella_sellada_corresponde"] = None
            crear_manifiesto(carpeta, {
                "version_manifiesto": 3,
                "paquete": {"estado": "PENDIENTE_DE_SELLO", "original": original.name,
                            "peticion": peticion.name, "sello": None},
                "calculado_por_la_herramienta": calculado,
                "obtenido_del_sello": None,
                "configuracion_del_proceso": proceso,
                "aportado_como_contexto": contexto,
                "nota": "PENDIENTE DE SELLO: la TSA no respondió. Este paquete NO tiene garantía temporal "
                        f"externa. Motivo: {exc}",
            })
            carpeta.rename(pendiente)
            return ResultadoSellado(str(pendiente), "PENDIENTE_DE_SELLO", original.name, huella,
                                    calculado["tamano_bytes"], peticion.name, "", "manifiesto.json",
                                    url_config, "", "", "", False, str(exc))
        datos = leer_sello(sello)
        if datos["algoritmo"] not in ("sha256", "sha-256"):
            raise SelladoError(f"El sello usa {datos['algoritmo']}; esta práctica espera SHA-256.")
        if datos["huella_sellada"] != huella:
            raise SelladoError("La TSA devolvió un sello legible, pero la huella sellada no corresponde "
                               "al archivo conservado. No se conserva el paquete.")
        nonce = _nonce_peticion(peticion)
        if nonce is not None and datos["nonce"] != nonce:
            raise SelladoError("La respuesta de la TSA no corresponde a esta petición (el nonce no coincide). "
                               "No se conserva el paquete.")
        calculado["huella_sellada_corresponde"] = True
        proceso["tsa_llamada"] = url_usada
        crear_manifiesto(carpeta, {
            "version_manifiesto": 3,
            "paquete": {"estado": "SELLADO", "original": original.name, "peticion": peticion.name,
                        "sello": sello.name},
            "calculado_por_la_herramienta": calculado,
            "obtenido_del_sello": {"hora_del_sello": datos["hora"], "huella_sellada": datos["huella_sellada"],
                                   "algoritmo": datos["algoritmo"], "emisor_tsa": datos["emisor"],
                                   "numero_serie": datos["numero_serie"]},
            "configuracion_del_proceso": proceso,
            "aportado_como_contexto": contexto,
            "nota": "El manifiesto relaciona y documenta las piezas; no certifica por sí mismo. La firma y la "
                    "cadena de confianza de la TSA se comprueban con un verificador independiente.",
        })
        return ResultadoSellado(str(carpeta), "SELLADO", original.name, huella, calculado["tamano_bytes"],
                                peticion.name, sello.name, "manifiesto.json", url_usada, datos["hora"],
                                datos["huella_sellada"], datos["emisor"], True)
    except Exception:
        if carpeta.exists():
            shutil.rmtree(carpeta, ignore_errors=True)  # nunca queda un paquete a medias
        raise
