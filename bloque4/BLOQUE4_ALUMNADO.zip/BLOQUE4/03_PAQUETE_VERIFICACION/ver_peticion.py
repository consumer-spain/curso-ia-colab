"""Bloque 4 · VINCULAR AL TIEMPO: ver qué viajaría a la TSA (sin enviar nada).

Crea la petición de sellado (.tsq) de captura_original.jpg y muestra que contiene
la huella SHA-256 del archivo; el archivo no sale hacia la TSA.

Uso:
    py -3 ver_peticion.py                    usa ../02_INSPECTORAPP/captura_original.jpg
    py -3 ver_peticion.py otro_archivo.ext
"""
import sys as _sys
for _f in (_sys.stdout, _sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass
import sys
from pathlib import Path

from sellado_core import calcular_sha256, crear_peticion_tsa

AQUI = Path(__file__).resolve().parent
archivo = Path(sys.argv[1]) if len(sys.argv) > 1 else AQUI.parent / "02_INSPECTORAPP" / "captura_original.jpg"
peticion = AQUI / "peticion_de_muestra.tsq"

huella = calcular_sha256(archivo)
crear_peticion_tsa(archivo, peticion)
contenido = peticion.read_bytes()
print(f"Archivo:          {archivo.name}  ({archivo.stat().st_size:,} bytes)".replace(",", "."))
print(f"SHA-256:          {huella[:8]}…{huella[-6:]}")
print(f"Petición creada:  {peticion.name}  ({len(contenido)} bytes)")
print("¿La huella va dentro de la petición?", "SÍ" if bytes.fromhex(huella) in contenido else "NO")
print("La petición contiene la huella; el archivo no sale hacia la TSA. La TSA devuelve un sello (.tsr).")
