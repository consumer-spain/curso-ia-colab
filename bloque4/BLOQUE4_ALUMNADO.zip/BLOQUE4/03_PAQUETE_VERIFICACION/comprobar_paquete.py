#!/usr/bin/env python3
"""Bloque 4 · COMPROBAR UN PAQUETE de evidencia (EVIDENCIA_...).

No se fía de lo que dice el manifiesto: vuelve a calcular la huella del original, lee el
sello y comprueba que todo encaja. No modifica nada.

Comprueba:  manifiesto legible · original presente · huella del original = la del manifiesto ·
            la petición contiene esa huella · sello presente y legible (o paquete pendiente) ·
            HUELLA DEL ARCHIVO = HUELLA SELLADA · manifiesto coherente con el sello.
No comprueba: la firma, el certificado ni la cadena de confianza de la TSA → /verificador.

Uso:  arrastra la carpeta EVIDENCIA_... sobre COMPROBAR_PAQUETE.bat
      (o doble clic y elige la carpeta · o: py -3 comprobar_paquete.py CARPETA)
"""
from __future__ import annotations
import sys as _sys
for _f in (_sys.stdout, _sys.stderr):
    try:
        _f.reconfigure(errors="replace")   # la consola de Windows no admite todos los símbolos
    except Exception:
        pass

import json
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import sellado_core as sc  # noqa: E402

resultados: list[tuple[str, str]] = []


def linea(estado: str, texto: str) -> None:
    resultados.append((estado, texto))
    print(f"  [{estado}] {texto}")


def corto(h: str) -> str:
    return f"{h[:8]}…{h[-6:]}" if h and len(h) > 16 else (h or "—")


def elegir_carpeta() -> Path | None:
    try:
        import tkinter as tk
        from tkinter import filedialog
        raiz = tk.Tk()
        raiz.withdraw()
        ruta = filedialog.askdirectory(title="Elige la carpeta EVIDENCIA_... que quieres comprobar")
        raiz.destroy()
        return Path(ruta) if ruta else None
    except Exception:
        ruta = input("Ruta de la carpeta EVIDENCIA_...: ").strip().strip('"')
        return Path(ruta) if ruta else None


def comprobar(carpeta: Path) -> int:
    print(f"\nCOMPROBAR PAQUETE · {carpeta.name}\n")
    man_path = carpeta / "manifiesto.json"
    if not man_path.is_file():
        linea("XX", "no hay manifiesto.json en esta carpeta (¿es una carpeta EVIDENCIA_...?)")
        return 1
    try:
        m = json.loads(man_path.read_text(encoding="utf-8"))
    except ValueError as exc:
        linea("XX", f"el manifiesto no se puede leer: {exc}")
        return 1
    if m.get("version_manifiesto") != 3:
        linea("XX", "el manifiesto no es de la versión 3 del curso; no se puede comprobar con esta herramienta")
        return 1
    linea("OK", "manifiesto legible (versión 3)")
    paquete = m.get("paquete") or {}
    calc = m.get("calculado_por_la_herramienta") or {}
    del_sello = m.get("obtenido_del_sello") or {}

    original = carpeta / str(paquete.get("original", ""))
    if not original.is_file():
        linea("XX", f"falta el original ({paquete.get('original')})")
        return 1
    huella = sc.calcular_sha256(original)
    tam = original.stat().st_size
    linea("OK", f"original presente · {tam:,} bytes".replace(",", "."))
    if huella == calc.get("sha256") and tam == calc.get("tamano_bytes"):
        linea("OK", f"huella del original = la del manifiesto   {corto(huella)}")
    else:
        linea("XX", f"el original NO es el que registra el manifiesto   ahora {corto(huella)} · manifiesto {corto(calc.get('sha256', ''))}")

    peticion = carpeta / str(paquete.get("peticion", ""))
    if peticion.is_file() and bytes.fromhex(huella) in peticion.read_bytes():
        linea("OK", "la petición (.tsq) contiene esa huella")
    else:
        linea("XX", "la petición (.tsq) falta o no contiene la huella del original")

    if paquete.get("estado") == "PENDIENTE_DE_SELLO":
        linea("!!", "PAQUETE PENDIENTE DE SELLO: no tiene garantía temporal externa")
        return fin()
    sello = carpeta / str(paquete.get("sello") or "")
    if not sello.is_file():
        linea("XX", "falta el sello (.tsr)")
        return fin()
    try:
        datos = sc.leer_sello(sello)
    except sc.SelladoError as exc:
        linea("XX", f"el sello no se puede leer: {exc}")
        return fin()
    linea("OK", f"sello legible · TSA: {datos['emisor'] or 'no declarada'} · hora: {datos['hora']}")
    if datos["huella_sellada"] == huella:
        linea("OK", f"HUELLA DEL ARCHIVO = HUELLA SELLADA   {corto(huella)}  →  CORRESPONDE")
    else:
        linea("XX", f"HUELLA DEL ARCHIVO {corto(huella)} ≠ HUELLA SELLADA {corto(datos['huella_sellada'])}  →  NO CORRESPONDE")
    if del_sello.get("huella_sellada") == datos["huella_sellada"] and del_sello.get("hora_del_sello") == datos["hora"]:
        linea("OK", "el manifiesto dice lo mismo que el sello (hora y huella sellada)")
    else:
        linea("XX", "el manifiesto NO coincide con lo que dice el sello")
    linea("--", "firma, certificado y cadena de la TSA: no se comprueban aquí → /verificador")
    return fin()


def fin() -> int:
    malos = [t for e, t in resultados if e == "XX"]
    pendiente = any(e == "!!" for e, _ in resultados)
    print()
    if malos:
        print("RESULTADO: HAY PROBLEMAS · revisa las líneas [XX]")
        return 1
    print("RESULTADO: PAQUETE PENDIENTE DE SELLO" if pendiente else "RESULTADO: PAQUETE COHERENTE")
    return 0


if __name__ == "__main__":
    destino = Path(sys.argv[1]) if len(sys.argv) > 1 else elegir_carpeta()
    if not destino or not destino.is_dir():
        sys.exit("No se ha indicado una carpeta EVIDENCIA_...")
    sys.exit(comprobar(destino.resolve()))
