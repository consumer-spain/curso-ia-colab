"""Comprobación inicial del Bloque 1 (se ejecuta AL PRINCIPIO de la sesión).

Normalmente se lanza con doble clic en COMPROBAR_BLOQUE1.bat (carpeta raíz).
También puede ejecutarse a mano desde esta carpeta:

    py -3 comprobador_b1.py
    python comprobador_b1.py

Comprueba que el equipo tiene todo lo necesario para las misiones del bloque:
  - Python operativo;
  - paquetes pandas y openpyxl;
  - que el material está descomprimido y completo;
  - que se puede escribir en la carpeta de trabajo;
  - que el Excel de prácticas se puede abrir.

NO muestra ni revela el contenido de los ejercicios: ni columnas del Excel,
ni número de imágenes, ni la causa ni la solución de ningún error.
"""

from __future__ import annotations

import sys
from pathlib import Path

OK = "OK"
REVISAR = "REVISAR"

RAIZ = Path(__file__).resolve().parent.parent
CARPETA_M1 = RAIZ / "01_ejecucion_comun"
CARPETA_M3 = RAIZ / "02_error_guiado"


def comprobar_python() -> tuple[str, str, str]:
    version = sys.version.split()[0]
    if sys.version_info >= (3, 9):
        return ("Python", OK, version)
    return ("Python", REVISAR, f"versión {version}: se necesita 3.9 o superior")


def comprobar_paquete(nombre: str) -> tuple[str, str, str]:
    try:
        modulo = __import__(nombre)
        return (f"Paquete {nombre}", OK, getattr(modulo, "__version__", "instalado"))
    except ImportError:
        return (f"Paquete {nombre}", REVISAR, "no instalado")


def comprobar_descomprimido() -> tuple[str, str, str]:
    # Si se ejecuta "desde dentro" del ZIP, Windows usa una carpeta temporal.
    ruta = str(RAIZ).lower()
    if "\\temp\\" in ruta and ".zip" in ruta:
        return ("Material descomprimido", REVISAR, "parece que estás dentro del ZIP: descomprímelo primero")
    return ("Material descomprimido", OK, "sí")


def comprobar_archivos() -> tuple[str, str, str]:
    necesarios = [
        CARPETA_M1 / "contar_imagenes.py",
        CARPETA_M1 / "imagenes_demo",
        CARPETA_M3 / "error_keyerror.py",
        CARPETA_M3 / "registro_imagenes.xlsx",
    ]
    faltan = [ruta.relative_to(RAIZ).as_posix() for ruta in necesarios if not ruta.exists()]
    if faltan:
        return ("Archivos del bloque", REVISAR, "faltan: " + ", ".join(faltan))
    return ("Archivos del bloque", OK, "completos")


def comprobar_escritura() -> tuple[str, str, str]:
    prueba = CARPETA_M1 / ".prueba_escritura.tmp"
    try:
        prueba.write_text("ok", encoding="utf-8")
        prueba.unlink()
        return ("Permiso de escritura", OK, "sí")
    except OSError as exc:
        return ("Permiso de escritura", REVISAR, f"no se puede escribir ({type(exc).__name__})")


def comprobar_excel() -> tuple[str, str, str]:
    ruta = CARPETA_M3 / "registro_imagenes.xlsx"
    if not ruta.exists():
        return ("Lectura de Excel", REVISAR, "no se encuentra el Excel de prácticas")
    try:
        import pandas as pd

        pd.read_excel(ruta)  # solo comprobamos que se abre; no mostramos nada
        return ("Lectura de Excel", OK, "se abre correctamente")
    except ImportError as exc:
        # pandas avisa de openpyxl con un ImportError sin atributo .name
        paquete = exc.name or ("openpyxl" if "openpyxl" in str(exc) else "desconocido")
        return ("Lectura de Excel", REVISAR, f"falta un paquete ({paquete})")
    except Exception as exc:  # noqa: BLE001 - cualquier fallo de apertura interesa
        return ("Lectura de Excel", REVISAR, f"no se pudo abrir ({type(exc).__name__})")


def main() -> int:
    resultados = [
        comprobar_python(),
        comprobar_paquete("pandas"),
        comprobar_paquete("openpyxl"),
        comprobar_descomprimido(),
        comprobar_archivos(),
        comprobar_escritura(),
        comprobar_excel(),
    ]

    print("COMPROBACIÓN INICIAL · BLOQUE 1")
    print("=" * 31)
    for nombre, estado, detalle in resultados:
        print(f"[{estado:^7}] {nombre}: {detalle}")

    print()
    if all(estado == OK for _, estado, _ in resultados):
        print("TODO LISTO. Puedes empezar el Bloque 1.")
        return 0

    print("HAY ALGO QUE REVISAR. Levanta la mano y enseña esta ventana al docente.")
    if any(n.startswith("Paquete") and e == REVISAR for n, e, _ in resultados):
        print("(Para instalar paquetes: py -3 -m pip install -r requirements.txt")
        print(" o bien:                python -m pip install -r requirements.txt)")
    return 1


if __name__ == "__main__":
    sys.exit(main())
