"""Comparador de precios por kilo · referencia de la Misión 4 (Concretar).

Es lo que una IA puede construir a partir del encargo que concretamos en
clase. No es "la solución correcta": es una referencia preparada para
mostrar un resultado real sin depender de generarlo en directo.

Encargo concretado:
  Pedir nombre, precio y gramos de dos productos; calcular el precio por
  kilogramo de cada uno; mostrar ambos resultados, cuál es más barato y la
  diferencia; avisar si una cantidad no es válida.

Solo usa Python estándar (no hay que instalar nada).

Caso de control:
  Producto A: 3,60 EUR · 600 g   -> 6,00 EUR/kg
  Producto B: 5,20 EUR · 1000 g  -> 5,20 EUR/kg
  Resultado:  B es 0,80 EUR/kg más barato.
"""


def pedir_numero(texto):
    """Pide un número hasta que sea válido. Acepta coma decimal y el símbolo €."""
    while True:
        bruto = input(texto).strip().replace("€", "").replace(",", ".").strip()
        try:
            return float(bruto)
        except ValueError:
            print("  Escribe solo un número (por ejemplo: 3,60).")


def pedir_producto(etiqueta):
    print(f"\n--- {etiqueta} ---")
    nombre = input("Nombre: ").strip() or etiqueta
    precio = pedir_numero("Precio (EUR): ")
    gramos = pedir_numero("Cantidad (gramos): ")
    return nombre, precio, gramos


def precio_por_kilo(precio, gramos):
    """Devuelve el precio por kilo, o None si la cantidad no es válida."""
    if gramos <= 0:
        return None
    return precio / (gramos / 1000)


def formato(valor):
    """3.6 -> '3,60' (formato español)."""
    return f"{valor:.2f}".replace(".", ",")


def main():
    print("COMPARADOR DE PRECIOS POR KILO")
    nombre_a, precio_a, gramos_a = pedir_producto("Producto A")
    nombre_b, precio_b, gramos_b = pedir_producto("Producto B")

    pk_a = precio_por_kilo(precio_a, gramos_a)
    pk_b = precio_por_kilo(precio_b, gramos_b)

    print("\n--- RESULTADO ---")
    for nombre, pk in ((nombre_a, pk_a), (nombre_b, pk_b)):
        if pk is None:
            print(f"{nombre}: cantidad no válida (debe ser mayor que 0 gramos).")
        else:
            print(f"{nombre}: {formato(pk)} EUR/kg")

    if pk_a is None or pk_b is None:
        print("\nNo se puede comparar: revisa las cantidades introducidas.")
        return

    diferencia = abs(pk_a - pk_b)
    if round(diferencia, 2) == 0:
        print("\nLos dos productos cuestan lo mismo por kilo.")
    elif pk_a < pk_b:
        print(f"\n{nombre_a} es {formato(diferencia)} EUR/kg más barato.")
    else:
        print(f"\n{nombre_b} es {formato(diferencia)} EUR/kg más barato.")


if __name__ == "__main__":
    main()
