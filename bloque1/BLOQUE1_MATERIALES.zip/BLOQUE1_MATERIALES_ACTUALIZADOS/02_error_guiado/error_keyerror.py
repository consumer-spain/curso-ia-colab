from __future__ import annotations

from pathlib import Path

import pandas as pd


def main() -> None:
    """Script deliberadamente defectuoso para practicar la reparación con IA."""
    carpeta_script = Path(__file__).resolve().parent
    ruta_excel = carpeta_script / "registro_imagenes.xlsx"

    datos = pd.read_excel(ruta_excel)

    # Error intencionado para practicar la reparación con IA.
    nombres = datos["nombre_imagen"].dropna().tolist()

    print(f"El Excel contiene {len(nombres)} nombres de archivo.")


if __name__ == "__main__":
    main()
