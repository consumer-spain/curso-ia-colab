# Materiales del Bloque 1 · Qué es programar con IA (v5)

El bloque se organiza en cinco **Misiones del Bloque 1**:
EJECUTAR · CREAR · REPARAR · CONCRETAR · MEJORAR.

El método del curso sigue siendo uno solo:
OBJETIVO → DIAGNÓSTICO → INFORMACIÓN PARA LA IA → SOLUCIÓN → COMPROBACIÓN.

## Antes de empezar (al principio de la sesión)

1. Descarga el ZIP.
2. **Descomprímelo** (en Windows: clic derecho → Extraer todo). No trabajes "dentro" del ZIP.
3. Doble clic en **`COMPROBAR_BLOQUE1.bat`** (en esta carpeta raíz).
4. Si aparece **TODO LISTO**, continúa.
5. Si aparece **HAY ALGO QUE REVISAR**, levanta la mano.

El comprobador indica también qué comando de Python funciona en tu equipo
(`py -3` o `python`): es el que usarás en la terminal.

Comprueba: Python, pandas, openpyxl, que el material está descomprimido y
completo, que se puede escribir en la carpeta de trabajo y que el Excel de
prácticas se abre. **No revela nada de los ejercicios.**

Si falta un paquete, desde esta carpeta:

    py -3 -m pip install -r requirements.txt
    (o bien)  python -m pip install -r requirements.txt

## Estructura

| Carpeta / archivo | Misión | Para qué sirve |
|---|---|---|
| `COMPROBAR_BLOQUE1.bat` | inicio | Comprobación inicial con doble clic |
| `00_comprobacion/comprobador_b1.py` | inicio | El comprobador que lanza el `.bat` |
| `01_ejecucion_comun/` | 1 · Ejecutar | `contar_imagenes.py`, `EJECUTAR_CONTADOR.bat`, `imagenes_demo/` |
| `01_ejecucion_comun/` (mismo sitio) | 2 · Crear | Aquí se guarda `mi_contador.py`, que crea `mi_conteo.txt` |
| `02_error_guiado/` | 3 · Reparar | `error_keyerror.py` (falla a propósito) y `registro_imagenes.xlsx` |
| `03_minipracticas/CIRUGIA_MAL_ENCARGO.txt` | 4 · Concretar | Situación, mal encargo y qué le falta |
| `03_minipracticas/PEDIR_A_LA_IA_QUE_PREGUNTE.txt` | 4 · Concretar | Pedir a la IA que pregunte; preguntas, respuestas y encargo final |
| `05_mision4_concretar/` | 4 · Concretar | Programa resultante (referencia) y encargo autocontenido |
| `03_minipracticas/RETOS_INICIALES.md` | 5 · Mejorar | Seis retos · Versión 1 · 20 min |
| `03_minipracticas/IDEAS_DE_MEJORA.md` | 5 · Mejorar | Ideas de mejora · Versión 2 · 10 min |
| `04_web/prompts_para_la_web.md` | todas | Textos que la web ofrece para copiar |
| `AYUDAS_Y_REFERENCIAS/` | docente | Referencias de recuperación |

## Misión 1 · Ejecutar
Tres puertas para el mismo script: doble clic en `EJECUTAR_CONTADOR.bat`, VS Code
(abrir `contar_imagenes.py` → ▶) o la terminal (`py -3 contar_imagenes.py` o
`python contar_imagenes.py`). `resultado_conteo.txt` NO viene pregenerado: aparece
al ejecutar. Después se comprueba a mano contra `imagenes_demo`.

`EJECUTAR_CONTADOR.bat` prueba de verdad `py -3 --version` y, si no funciona,
`python --version`; usa el primero que responda y muestra cuál ha usado.

## Misión 3 · Reparar
1. Ejecutar `error_keyerror.py` → `KeyError: 'nombre_imagen'` (deliberado).
2. Pedir a la IA **solo un diagnóstico** (script + Excel + traceback completo).
3. Comprobar la hipótesis abriendo el Excel (columnas `expediente`, `nombre_archivo`).
4. Cambio mínimo en **el mismo** `error_keyerror.py`: `nombre_imagen` → `nombre_archivo`.
5. Volver a ejecutar ese mismo archivo → `El Excel contiene 3 nombres de archivo.`
6. Comprobar por qué 3 es correcto (4 expedientes, 3 con nombre).

`AYUDAS_Y_REFERENCIAS/solucion_error_keyerror.py` es solo un recurso del docente por
si alguien deja el archivo inservible. No es el camino de la práctica.

## Misión 4 · Concretar
Necesidad real (¿cuál de dos productos sale más barato?) → mal encargo
("Hazme un programa para comparar precios.") → qué falta → la IA pregunta →
nuestras respuestas → ya sabemos qué debe hacer el programa → programa real.

- `comparador_precios_referencia.py`: lo que una IA puede construir con ese encargo.
  Solo Python estándar. Caso de control: A 3,60 € · 600 g → 6,00 €/kg;
  B 5,20 € · 1.000 g → 5,20 €/kg; B es 0,80 €/kg más barato.
- `PROMPT_FINAL_COMPARADOR.txt`: versión autocontenida del encargo (referencia,
  fallback o punto de partida para una conversación nueva). No es un «prompt
  perfecto» que el alumnado tenga que redactar después de la conversación: en clase,
  las respuestas a las preguntas de la IA ya definen el problema.

## Misión 5 · Mejorar
Elegir uno de seis retos → decidir tres condiciones para la V1 → **Versión 1 · 20 min**
→ comprobar → elegir una mejora que aporte algo → **Versión 2 · 10 min** → volver a probar.

`AYUDAS_Y_REFERENCIAS/retos_basicos/` contiene una versión básica de cada reto
(recuperación y referencia, no "la respuesta correcta"). Todas usan solo Python estándar.

## Python en Windows
Funciona `py -3 archivo.py` o `python archivo.py`, según el equipo. Usa el que indicó
`COMPROBAR_BLOQUE1.bat`. Si ninguno funciona: Plan B en
`curso-ia-consumo.onrender.com/ayuda-python` (Google Colab o Python portable).
