from __future__ import annotations

from collections import Counter
from pathlib import Path


EXTENSIONES_IMAGEN = {".jpg", ".jpeg", ".png", ".webp"}


def main() -> None:
    """Cuenta las imágenes de una carpeta de demostración y genera un informe."""
    carpeta_script = Path(__file__).resolve().parent
    carpeta_imagenes = carpeta_script / "imagenes_demo"
    ruta_informe = carpeta_script / "resultado_conteo.txt"

    if not carpeta_imagenes.exists():
        raise FileNotFoundError(
            f"No se encuentra la carpeta de imágenes: {carpeta_imagenes}"
        )

    imagenes = sorted(
        ruta
        for ruta in carpeta_imagenes.rglob("*")
        if ruta.is_file() and ruta.suffix.lower() in EXTENSIONES_IMAGEN
    )

    conteo_extensiones = Counter(ruta.suffix.lower() for ruta in imagenes)

    lineas = [
        "RESULTADO DEL CONTEO",
        "====================",
        f"Carpeta analizada: {carpeta_imagenes}",
        f"Número total de imágenes: {len(imagenes)}",
        "",
        "Por extensión:",
    ]

    if conteo_extensiones:
        for extension, cantidad in sorted(conteo_extensiones.items()):
            lineas.append(f"- {extension}: {cantidad}")
    else:
        lineas.append("- No se encontraron imágenes.")

    lineas.extend(["", "Archivos encontrados:"])
    lineas.extend(f"- {ruta.name}" for ruta in imagenes)

    ruta_informe.write_text("\n".join(lineas), encoding="utf-8")

    print(f"Imágenes encontradas: {len(imagenes)}")
    print(f"Informe generado en: {ruta_informe}")


if __name__ == "__main__":
    main()
