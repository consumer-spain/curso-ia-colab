# Misión 5 · Mejorar · Versión 2 · 10 min

V1 funciona. Ahora mejórala.

No añadas cosas por añadir. Pregúntate:
**¿qué cambio la haría más útil, cómoda o divertida?**

V1 FUNCIONA → ELIGE UNA MEJORA → PÍDESELA A LA IA → V2 → VUELVE A PROBAR

Elige UNA sola idea (no varias a la vez). No son requisitos: son ideas.

## Quiz interactivo
- Respuestas mediante botones.
- Categorías o niveles.
- Preguntas aleatorias.
- Guardar la puntuación.

## Analizador de texto
- Cuadro grande para pegar texto.
- Abrir un archivo `.txt`.
- Mostrar un top 10.
- Guardar el análisis.

## Lista de tareas
- Prioridades.
- Filtro de pendientes/completadas.
- Guardar las tareas al cerrar.
- Interfaz con botones.

## Piedra · papel · tijera
- Selección gráfica de piedra / papel / tijera.
- No tener que escribir la opción.
- Marcador.
- Mejor de 3 o de 5.

## Adivina el número
- Niveles de dificultad.
- Contador de intentos.
- Historial de pistas.
- Botón para otra partida.

## Generador de contraseñas DE PRUEBA
- Controles para longitud y tipos de caracteres.
- Botón Copiar.
- Generar varias.
- Guardar una contraseña DE PRUEBA en un `.txt`.

> No utilices este ejercicio para guardar contraseñas reales en texto plano.

**¿Has acabado? Prueba otro reto.**
