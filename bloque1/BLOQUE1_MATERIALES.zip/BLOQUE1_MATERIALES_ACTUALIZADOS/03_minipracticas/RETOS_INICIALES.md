# Misión 5 · Mejorar · Reto final

## Versión 1 · 20 min

Elige uno de los seis retos. No hay un único prompt correcto.

### 1. Quiz interactivo
Crea un quiz de 5 preguntas sobre el tema que quieras. Debe corregir las
respuestas, llevar la puntuación y mostrar el resultado final.

### 2. Analizador de texto
Pega un texto y obtén información útil: número de palabras, frases, términos
más repetidos y palabra más larga.

### 3. Lista de tareas
Permite añadir tareas, ver la lista, marcar tareas como terminadas y
eliminarlas.

### 4. Piedra · papel · tijera
Juega contra el ordenador, permite varias rondas y lleva el marcador.

### 5. Adivina el número
El ordenador piensa un número y da pistas para indicar si hay que subir o
bajar.

### 6. Generador de contraseñas DE PRUEBA
Permite elegir longitud y características y genera una contraseña aleatoria
de prueba.

## Antes de pedir código: decide tres cosas sobre tu V1

1. ¿Qué tiene que poder hacer?
2. ¿Qué tiene que pedir o recibir?
3. ¿Qué tiene que mostrar o guardar?

Escribe tres condiciones simples. Esas serán tus primeras pruebas.
(No hay que entregarlas: son para ti.)

## Mientras trabajas

CONCRETAR → PEDIR CÓDIGO → GUARDAR → EJECUTAR → PROBAR TUS 3 CONDICIONES

¿Cumple ya lo básico que decidiste?

- **No:** corrige o vuelve a pedirle a la IA lo que falla.
- **Sí:** prueba un caso distinto y piensa una posible mejora.

Para mejorar algo, primero necesitamos una primera versión. La mejora
(Versión 2 · 10 min) llega después: ver `IDEAS_DE_MEJORA.md`.
