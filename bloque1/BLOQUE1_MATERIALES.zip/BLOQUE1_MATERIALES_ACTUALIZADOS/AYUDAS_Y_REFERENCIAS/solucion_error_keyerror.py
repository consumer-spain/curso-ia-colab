from __future__ import annotations

from pathlib import Path

import pandas as pd


def main() -> None:
    """Versión corregida del ejercicio de KeyError."""
    carpeta_script = Path(__file__).resolve().parent
    # Si se ejecuta desde AYUDAS_Y_REFERENCIAS, busca el Excel en 02_error_guiado.
    ruta_excel = carpeta_script.parent / "02_error_guiado" / "registro_imagenes.xlsx"

    datos = pd.read_excel(ruta_excel)
    nombres = datos["nombre_archivo"].dropna().tolist()

    print(f"El Excel contiene {len(nombres)} nombres de archivo.")


if __name__ == "__main__":
    main()
