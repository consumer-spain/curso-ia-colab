import random

secreto = random.randint(1, 100)
intentos = 0

print("He pensado un número entre 1 y 100.")

while True:
    try:
        numero = int(input("Tu intento: "))
    except ValueError:
        print("Escribe un número entero.")
        continue

    intentos += 1

    if numero < secreto:
        print("Más alto.")
    elif numero > secreto:
        print("Más bajo.")
    else:
        print(f"¡Correcto! Lo has conseguido en {intentos} intentos.")
        break
