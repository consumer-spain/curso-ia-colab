# Referencias básicas de los seis retos

Estas soluciones son **ejemplos básicos**, no «la respuesta correcta».

Su finalidad es:
- servir de recuperación si alguien se bloquea;
- permitir al docente mostrar que pueden existir implementaciones distintas;
- y ofrecer un punto de partida para una mejora.

No es necesario que el alumnado las abra antes de intentar su propio reto.
Todas utilizan únicamente la librería estándar de Python.
