import random

opciones = ["piedra", "papel", "tijera"]
usuario = 0
ordenador = 0

while True:
    eleccion = input("\nPiedra, papel, tijera o salir: ").strip().lower()
    if eleccion == "salir":
        break
    if eleccion not in opciones:
        print("Opción no válida.")
        continue

    rival = random.choice(opciones)
    print(f"Ordenador: {rival}")

    if eleccion == rival:
        print("Empate.")
    elif (
        (eleccion == "piedra" and rival == "tijera")
        or (eleccion == "papel" and rival == "piedra")
        or (eleccion == "tijera" and rival == "papel")
    ):
        print("Ganas.")
        usuario += 1
    else:
        print("Gana el ordenador.")
        ordenador += 1

    print(f"Marcador: tú {usuario} - {ordenador} ordenador")
