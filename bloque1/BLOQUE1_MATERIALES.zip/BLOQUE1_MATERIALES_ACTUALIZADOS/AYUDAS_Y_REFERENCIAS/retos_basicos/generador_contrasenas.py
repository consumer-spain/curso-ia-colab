import secrets
import string

try:
    longitud = int(input("Longitud de la contraseña: "))
except ValueError:
    raise SystemExit("La longitud debe ser un número entero.")

if longitud < 4:
    raise SystemExit("Utiliza una longitud de al menos 4 caracteres para esta demostración.")

usar_mayusculas = input("¿Incluir mayúsculas? (s/n): ").strip().lower() == "s"
usar_numeros = input("¿Incluir números? (s/n): ").strip().lower() == "s"
usar_simbolos = input("¿Incluir símbolos? (s/n): ").strip().lower() == "s"

alfabeto = string.ascii_lowercase
if usar_mayusculas:
    alfabeto += string.ascii_uppercase
if usar_numeros:
    alfabeto += string.digits
if usar_simbolos:
    alfabeto += "!@#$%&*+-_"

contrasena = "".join(secrets.choice(alfabeto) for _ in range(longitud))
print(f"\nContraseña generada: {contrasena}")
print("Ejercicio didáctico: no guardes contraseñas reales en texto plano.")
