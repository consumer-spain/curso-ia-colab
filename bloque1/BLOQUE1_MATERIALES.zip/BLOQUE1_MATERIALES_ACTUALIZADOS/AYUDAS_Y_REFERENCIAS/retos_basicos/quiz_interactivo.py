preguntas = [
    ("¿Cuál es la capital de Francia?", "paris"),
    ("¿Cuánto es 7 x 8?", "56"),
    ("¿Qué planeta es conocido como el planeta rojo?", "marte"),
    ("¿Cuántos días tiene una semana?", "7"),
    ("¿Qué océano separa Europa de América?", "atlantico"),
]

puntos = 0

for pregunta, respuesta_correcta in preguntas:
    respuesta = input(pregunta + " ").strip().lower()
    if respuesta == respuesta_correcta:
        print("Correcto.")
        puntos += 1
    else:
        print(f"No. La respuesta era: {respuesta_correcta}")

print(f"\nResultado final: {puntos}/{len(preguntas)}")
