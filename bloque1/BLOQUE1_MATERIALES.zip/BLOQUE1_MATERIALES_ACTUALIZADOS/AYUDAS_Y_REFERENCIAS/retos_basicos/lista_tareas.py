tareas = []

def mostrar():
    if not tareas:
        print("\nNo hay tareas.")
        return
    print()
    for i, tarea in enumerate(tareas, start=1):
        marca = "✓" if tarea["hecha"] else " "
        print(f"{i}. [{marca}] {tarea['texto']}")

while True:
    print("\n1 Añadir · 2 Ver · 3 Completar · 4 Eliminar · 5 Salir")
    opcion = input("Elige: ").strip()

    if opcion == "1":
        texto = input("Nueva tarea: ").strip()
        if texto:
            tareas.append({"texto": texto, "hecha": False})
    elif opcion == "2":
        mostrar()
    elif opcion == "3":
        mostrar()
        try:
            n = int(input("Número de tarea completada: "))
            tareas[n - 1]["hecha"] = True
        except (ValueError, IndexError):
            print("Número no válido.")
    elif opcion == "4":
        mostrar()
        try:
            n = int(input("Número de tarea a eliminar: "))
            tareas.pop(n - 1)
        except (ValueError, IndexError):
            print("Número no válido.")
    elif opcion == "5":
        break
    else:
        print("Opción no válida.")
