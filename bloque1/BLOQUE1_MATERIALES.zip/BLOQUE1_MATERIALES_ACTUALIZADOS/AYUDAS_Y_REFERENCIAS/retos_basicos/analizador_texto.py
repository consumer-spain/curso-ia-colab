import re
from collections import Counter

texto = input("Pega un texto y pulsa Intro:\n").strip()

palabras = re.findall(r"\b[\wáéíóúüñÁÉÍÓÚÜÑ]+\b", texto.lower())
frases = [f for f in re.split(r"[.!?]+", texto) if f.strip()]

print(f"\nPalabras: {len(palabras)}")
print(f"Frases: {len(frases)}")

if palabras:
    frecuentes = Counter(palabras).most_common(5)
    print("Palabras más frecuentes:")
    for palabra, cantidad in frecuentes:
        print(f"- {palabra}: {cantidad}")
    print(f"Palabra más larga: {max(palabras, key=len)}")
