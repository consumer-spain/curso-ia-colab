@echo off
setlocal
cd /d "%~dp0"

rem Detecta un Python que funcione de verdad (no basta con que el comando exista).
set "PYCMD="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3"
if defined PYCMD goto :python_ok

python --version >nul 2>&1
if not errorlevel 1 set "PYCMD=python"
if defined PYCMD goto :python_ok

echo [REVISAR] Python: no se ha encontrado un Python que funcione.
echo           Se ha probado "py -3" y "python".
echo.
echo HAY ALGO QUE REVISAR. Levanta la mano y muestra esta ventana al docente.
echo Plan B: curso-ia-consumo.onrender.com/ayuda-python
goto :fin

:python_ok
echo Comando de Python que funciona en este equipo: %PYCMD%
echo (es el comando que debes usar en la terminal)
echo.
%PYCMD% "00_comprobacion\comprobador_b1.py"

:fin
echo.
pause
