# Prompts y textos reutilizables del Bloque 1

## Antes de empezar · comprobación inicial
1. Descarga los materiales.
2. Descomprime el ZIP (no trabajes "dentro" del ZIP).
3. Doble clic en `COMPROBAR_BLOQUE1.bat`.
4. Si aparece **TODO LISTO**, continúa.
5. Si aparece **HAY ALGO QUE REVISAR**, levanta la mano.

## Misión 2 · Crear el primer contador
Tengo una carpeta llamada `imagenes_demo` situada junto al script.

Quiero un programa de Python que cuente las imágenes `.jpg` y cree un archivo
`mi_conteo.txt` con:
- el número total de imágenes;
- y la lista de nombres.

Guárdalo como `mi_contador.py`, en la misma carpeta donde está `imagenes_demo`.
No muevas ni modifiques los archivos originales.
No quiero instalar paquetes adicionales.

Indícame cómo ejecutarlo utilizando el comando de Python que funcione en mi
equipo (`py -3` o `python`).

## Misión 3 · Reparar · primer mensaje: pedir DIAGNÓSTICO (no la solución)
Adjunta o pega: el script, el Excel (o sus columnas) y el traceback completo.

He ejecutado este script sobre este Excel y aparece este traceback.

Todavía no quiero que lo corrijas.

Explícame de forma sencilla qué crees que está ocurriendo y dime qué debería
comprobar para confirmar el diagnóstico.

Código:
[pegar código completo]

Error completo:
[pegar traceback completo]

### Después del diagnóstico
1. Comprueba tú mismo lo que te ha dicho la IA (por ejemplo, abre el Excel y
   mira el nombre real de las columnas).
2. Si la hipótesis se confirma, haz el cambio mínimo en el MISMO script.
3. Vuelve a ejecutar ese mismo script.
4. Comprueba que el resultado es correcto.

## Misión 4 · Concretar · pedirle a la IA que haga preguntas

Versión mínima:

Antes de programar, hazme las preguntas que necesites.

Versión completa (plantilla):

Quiero hacer un programa para ________________________________.

Todavía no tengo bien definidos todos los requisitos.
Antes de programar, hazme las preguntas necesarias, de una en una,
para definir bien qué debe hacer el programa.

No escribas código hasta que hayamos concretado suficientemente el encargo.

### El caso de clase: comparar precios
Situación: quieres saber cuál de dos productos sale realmente más barato
(precios y cantidades distintos).

Mensaje inicial:

Hazme un programa para comparar precios.
Antes de programar, hazme las preguntas que necesites.

Preguntas que puede hacer la IA (ejemplo orientativo; la conversación real
puede variar):
1. ¿Qué datos vas a introducir de cada producto?
2. ¿Cómo quieres compararlos?
3. ¿Qué quieres que muestre el resultado?
4. ¿Qué debe ocurrir si una cantidad es cero o negativa?

Nuestras respuestas:
- Datos: nombre, precio y gramos de dos productos.
- Comparación: precio por kilogramo.
- Resultado: mostrar el €/kg de ambos, cuál es más barato y la diferencia.
- Error: si la cantidad es 0 o negativa, avisar y no comparar.

Ya sabemos que el programa debe:
- pedir nombre, precio y gramos de dos productos;
- calcular el precio por kilogramo;
- mostrar el €/kg de ambos, cuál es más barato y la diferencia;
- avisar y no comparar si una cantidad no es válida.

La conversación continúa simplemente con:

Perfecto. Ahora genera el programa con lo que hemos definido.

No hace falta volver a escribir todo como "el prompt perfecto": la
conversación ya ha definido el problema.

## Misión 5 · Mejorar · antes de pedir código
Decide tres cosas sobre tu V1:
1. ¿Qué tiene que poder hacer?
2. ¿Qué tiene que pedir o recibir?
3. ¿Qué tiene que mostrar o guardar?

Escribe tres condiciones simples. Esas serán tus primeras pruebas.
