@echo off
chcp 65001 >nul
title Laboratorio web - Bloque 3
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && python --version >nul 2>nul && set "PY=python"
if not defined PY where python3 >nul 2>nul && set "PY=python3"
if not defined PY (
  echo No se encuentra Python en este equipo. Trabaja en pareja o avisa al docente.
  pause
  exit /b 1
)
echo.
echo  LABORATORIO WEB - BLOQUE 3
echo  ===========================
echo  Servidor local en http://localhost:8765  (usando %PY%)
echo  NO cierres esta ventana mientras uses el laboratorio.
echo.
start "" /b cmd /c "timeout /t 2 /nobreak >nul & start "" http://localhost:8765/index.html"
%PY% -m http.server 8765 --bind 127.0.0.1
echo.
echo  El servidor se ha detenido. Si no llego a arrancar, puede que el puerto 8765 este ocupado: cierra otras ventanas negras del laboratorio y vuelve a intentarlo.
pause
