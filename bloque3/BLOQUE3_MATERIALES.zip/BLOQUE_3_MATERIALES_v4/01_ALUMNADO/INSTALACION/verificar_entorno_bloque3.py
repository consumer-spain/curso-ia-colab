from __future__ import annotations

import importlib
import sys

MODULOS = {
    "requests": "requests",
    "beautifulsoup4": "bs4",
    "pandas": "pandas",
    "openpyxl": "openpyxl",
}

fallos = []
print("Python:", sys.version.split()[0])
for paquete, modulo in MODULOS.items():
    try:
        importlib.import_module(modulo)
        print(f"OK  {paquete}")
    except Exception as exc:
        fallos.append(paquete)
        print(f"FALTA {paquete}: {exc}")

try:
    import tkinter
    print("OK  tkinter")
except Exception as exc:
    print("AVISO tkinter no disponible:", exc)

if fallos:
    print("\nInstale lo necesario con:")
    print("python -m pip install " + " ".join(fallos))
    raise SystemExit(1)
print("\nEntorno preparado para el bloque 3.")
