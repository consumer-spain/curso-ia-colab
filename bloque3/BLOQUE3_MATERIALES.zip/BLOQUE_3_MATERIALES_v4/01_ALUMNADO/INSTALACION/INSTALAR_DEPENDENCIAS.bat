@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && python --version >nul 2>nul && set "PY=python"
if not defined PY where python3 >nul 2>nul && set "PY=python3"
if not defined PY (
  echo No se encuentra Python. Instalalo o avisa al docente.
  pause
  exit /b 1
)
echo Usando: %PY%
%PY% -m pip install -r requirements.txt
%PY% verificar_entorno_bloque3.py
pause
