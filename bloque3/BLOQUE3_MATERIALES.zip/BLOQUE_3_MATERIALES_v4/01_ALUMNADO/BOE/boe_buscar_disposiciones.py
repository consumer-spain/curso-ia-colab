"""
boe_buscar_disposiciones.py · Bloque 3 · BOLA EXTRA BOE (solución de referencia)

Para un intervalo de fechas, recorre el SUMARIO OFICIAL DEL BOE de cada día y
localiza las disposiciones cuyo TÍTULO contiene una o varias palabras
(por defecto: «consumidor»). Genera un Excel con:

  Fecha · Identificador · Título · Departamento · Sección · Enlace · PDF

y una hoja «Control» con lo ocurrido cada día (publicado / sin sumario / error).

Fuente oficial (servicio de datos abiertos del BOE):
  https://boe.es/datosabiertos/api/boe/sumario/AAAAMMDD

Uso:
  python boe_buscar_disposiciones.py
      -> pregunta fechas y palabras por pantalla
  python boe_buscar_disposiciones.py --desde 20261001 --hasta 20261017 --palabra consumidor --palabra consumo
  python boe_buscar_disposiciones.py --respaldo RESPALDO_BOE --palabra consumidor
      -> SIN Internet: usa sumarios reales guardados (sumario_AAAAMMDD.json o .xml)

Opciones:
  --campo titulo   (por defecto) busca solo en el título
  --campo todo     busca en título y en el nombre del departamento

Requisitos: pip install requests pandas openpyxl
"""

import json
import sys
import time
import unicodedata
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd

URL = "https://boe.es/datosabiertos/api/boe/sumario/{fecha}"


def normaliza(t):
    t = unicodedata.normalize("NFD", str(t or "").lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def barra(i, total, texto):
    h = int(30 * i / total) if total else 30
    print(f"\r[{'#' * h}{'.' * (30 - h)}] {i}/{total} {texto:<34}", end="", flush=True)


def a_lista(x):
    return x if isinstance(x, list) else ([] if x is None else [x])


def items_json(datos):
    """Devuelve (seccion, departamento, item) de un sumario en JSON."""
    sumario = datos.get("data", {}).get("sumario", {})
    for diario in a_lista(sumario.get("diario")):
        for sec in a_lista(diario.get("seccion")):
            for dep in a_lista(sec.get("departamento")):
                for it in a_lista(dep.get("item")):
                    yield sec.get("nombre", ""), dep.get("nombre", ""), it
                for epi in a_lista(dep.get("epigrafe")):
                    for it in a_lista(epi.get("item")):
                        yield sec.get("nombre", ""), dep.get("nombre", ""), it


def items_xml(texto):
    """Devuelve (seccion, departamento, item) de un sumario en XML."""
    raiz = ET.fromstring(texto)
    for sec in raiz.iter("seccion"):
        for dep in sec.iter("departamento"):
            for it in dep.iter("item"):
                d = {h.tag: (h.text or "").strip() for h in it}
                d["url_pdf"] = {"texto": d.get("url_pdf", "")}
                yield sec.get("nombre", ""), dep.get("nombre", ""), d


def descargar(fecha_txt, intentos=3):
    import requests
    for n in range(1, intentos + 1):
        try:
            r = requests.get(URL.format(fecha=fecha_txt), headers={"Accept": "application/json"}, timeout=60)
            if r.status_code == 404:
                return None, "sin sumario (no se publicó BOE ese día)"
            r.raise_for_status()
            return ("json", r.json()), "publicado"
        except Exception as e:
            if n == intentos:
                return None, f"ERROR: {str(e)[:90]}"
            time.sleep(2 * n)


def leer_respaldo(carpeta, fecha_txt):
    p_json, p_xml = Path(carpeta) / f"sumario_{fecha_txt}.json", Path(carpeta) / f"sumario_{fecha_txt}.xml"
    if p_json.exists():
        return ("json", json.loads(p_json.read_text(encoding="utf-8"))), "publicado (respaldo)"
    if p_xml.exists():
        return ("xml", p_xml.read_text(encoding="utf-8")), "publicado (respaldo)"
    return None, "sin sumario en el respaldo"


def argumento(args, nombre, multiple=False):
    vals = [args[i + 1] for i, a in enumerate(args) if a == nombre and i + 1 < len(args)]
    return vals if multiple else (vals[0] if vals else None)


def main():
    a = sys.argv[1:]
    respaldo = argumento(a, "--respaldo")
    palabras = argumento(a, "--palabra", multiple=True)
    campo = argumento(a, "--campo") or "titulo"
    desde, hasta = argumento(a, "--desde"), argumento(a, "--hasta")

    if respaldo and not (desde and hasta):
        fechas_disp = sorted(p.stem.split("_")[1] for p in Path(respaldo).glob("sumario_*.*"))
        desde, hasta = (fechas_disp[0], fechas_disp[-1]) if fechas_disp else (None, None)
    if not (desde and hasta):
        desde = input("Fecha inicial (AAAAMMDD): ").strip()
        hasta = input("Fecha final   (AAAAMMDD): ").strip()
    if not palabras:
        txt = input("Palabras a buscar en el título, separadas por comas (Intro = consumidor): ").strip()
        palabras = [p.strip() for p in txt.split(",") if p.strip()] or ["consumidor"]

    d0, d1 = datetime.strptime(desde, "%Y%m%d").date(), datetime.strptime(hasta, "%Y%m%d").date()
    dias = [(d0 + timedelta(days=i)) for i in range((d1 - d0).days + 1)]
    claves = [normaliza(p) for p in palabras]
    print(f"Buscando {palabras} en {campo} · {len(dias)} días · {'RESPALDO' if respaldo else 'en vivo'}")

    filas, control = [], []
    for n, dia in enumerate(dias, start=1):
        f = dia.strftime("%Y%m%d")
        barra(n - 1, len(dias), f"leyendo {f}")
        contenido, estado = leer_respaldo(respaldo, f) if respaldo else descargar(f)
        total = coincid = 0
        if contenido:
            tipo, datos = contenido
            for sec, dep, it in (items_json(datos) if tipo == "json" else items_xml(datos)):
                total += 1
                donde = normaliza(it.get("titulo")) + (" " + normaliza(dep) if campo == "todo" else "")
                if any(k in donde for k in claves):
                    coincid += 1
                    pdf = it.get("url_pdf")
                    filas.append({
                        "Fecha": dia.strftime("%d/%m/%Y"), "Identificador": it.get("identificador"),
                        "Título": it.get("titulo"), "Departamento": dep, "Sección": sec,
                        "Enlace": it.get("url_html"), "PDF": pdf.get("texto") if isinstance(pdf, dict) else pdf,
                    })
        control.append({"Fecha": dia.strftime("%d/%m/%Y"), "Estado": estado, "Disposiciones del día": total, "Coincidencias": coincid})
        if not respaldo:
            time.sleep(0.4)  # cortesía con el servicio
    barra(len(dias), len(dias), "terminado")
    print()

    sufijo = "_RESPALDO" if respaldo else ""
    destino = Path(f"BOE_{'_'.join(palabras)}_{desde}_{hasta}{sufijo}.xlsx".replace(" ", "-"))
    columnas = ["Fecha", "Identificador", "Título", "Departamento", "Sección", "Enlace", "PDF"]
    with pd.ExcelWriter(destino, engine="openpyxl") as xw:
        pd.DataFrame(filas, columns=columnas).to_excel(xw, sheet_name="Disposiciones", index=False)
        pd.DataFrame(control).to_excel(xw, sheet_name="Control", index=False)
    errores = [c for c in control if c["Estado"].startswith("ERROR")]
    print(f"Guardado: {destino} · {len(filas)} disposiciones encontradas en {len(dias)} días")
    if errores:
        print(f"ATENCIÓN: {len(errores)} días con error. Revisa la hoja Control antes de dar el resultado por bueno.")


if __name__ == "__main__":
    main()
