"""
boe_legislacion_consumidores.py · Bloque 3 · BOLA EXTRA BOE (solución de referencia)

Busca en la LEGISLACIÓN CONSOLIDADA del BOE las normas cuyo TÍTULO contiene una
palabra (por defecto «consumidores»), publicadas en un intervalo de fechas, y
genera un Excel con:

  Fecha de publicación · Identificador · Rango · Título · Departamento · Enlace

Fuente oficial (API de datos abiertos del BOE, documentada en
https://www.boe.es/datosabiertos/documentos/APIconsolidada.pdf):
  https://boe.es/datosabiertos/api/legislacion-consolidada
  parámetro query = JSON, por ejemplo:
  {"query": {"query_string": {"query": "titulo:consumidores"},
             "range": {"fecha_publicacion": {"gte": "20200101", "lte": "20261017"}}},
   "sort": [{"fecha_publicacion": "desc"}]}

Uso:
  python boe_legislacion_consumidores.py
      -> pregunta palabra y fechas
  python boe_legislacion_consumidores.py --palabra consumidores --desde 20200101 --hasta 20261017
  python boe_legislacion_consumidores.py --respaldo RESPALDO_BOE/consolidada_consumidores_2020_2026.json
      -> SIN Internet: usa una respuesta real guardada

Requisitos: pip install requests pandas openpyxl
"""

import json
import sys
import time
from datetime import datetime
from pathlib import Path

import pandas as pd

URL = "https://boe.es/datosabiertos/api/legislacion-consolidada"


def arg(a, nombre, defecto=None):
    return a[a.index(nombre) + 1] if nombre in a and a.index(nombre) + 1 < len(a) else defecto


def fecha_legible(f):
    try:
        return datetime.strptime(str(f)[:8], "%Y%m%d").strftime("%d/%m/%Y")
    except ValueError:
        return f


def consultar(palabra, desde, hasta, intentos=3):
    import requests
    consulta = {"query": {"query_string": {"query": f"titulo:{palabra}"},
                          "range": {"fecha_publicacion": {"gte": desde, "lte": hasta}}},
                "sort": [{"fecha_publicacion": "desc"}]}
    for n in range(1, intentos + 1):
        try:
            print(f"[{'#' * (10 * n)}{'.' * (30 - 10 * n)}] consultando la API (intento {n})...", flush=True)
            r = requests.get(URL, params={"query": json.dumps(consulta), "limit": -1},
                             headers={"Accept": "application/json"}, timeout=60)
            if r.status_code == 400:
                raise SystemExit("La API rechaza la consulta (400). Revisa el formato del parámetro query.\n" + r.text[:300])
            r.raise_for_status()
            return r.json()
        except SystemExit:
            raise
        except Exception as e:
            if n == intentos:
                raise
            print(f"   reintento por: {str(e)[:80]}")
            time.sleep(3 * n)


def main():
    a = sys.argv[1:]
    respaldo = arg(a, "--respaldo")
    palabra = arg(a, "--palabra")
    desde, hasta = arg(a, "--desde"), arg(a, "--hasta")
    if respaldo:
        datos = json.loads(Path(respaldo).read_text(encoding="utf-8"))
        palabra = palabra or "consumidores"
        origen = f"respaldo {Path(respaldo).name}"
    else:
        palabra = palabra or input("Palabra que debe aparecer en el título (Intro = consumidores): ").strip() or "consumidores"
        desde = desde or input("Publicadas desde (AAAAMMDD): ").strip()
        hasta = hasta or input("Publicadas hasta (AAAAMMDD): ").strip()
        datos = consultar(palabra, desde, hasta)
        origen = "API en vivo"

    items = datos.get("data") or []
    if isinstance(items, dict):  # sin resultados la API devuelve "data": {}
        items = []
    filas = [{
        "Fecha de publicación": fecha_legible(it.get("fecha_publicacion")),
        "Identificador": it.get("identificador"),
        "Rango": (it.get("rango") or {}).get("texto"),
        "Título": it.get("titulo"),
        "Departamento": (it.get("departamento") or {}).get("texto"),
        "Enlace": it.get("url_html_consolidada"),
    } for it in items]

    df = pd.DataFrame(filas, columns=["Fecha de publicación", "Identificador", "Rango", "Título", "Departamento", "Enlace"])
    sin_palabra = df[~df["Título"].fillna("").str.lower().str.contains(palabra.lower()[:-1])] if len(df) else df
    control = pd.DataFrame([
        {"Comprobación": "Origen de los datos", "Resultado": origen},
        {"Comprobación": "Normas encontradas", "Resultado": len(df)},
        {"Comprobación": "Identificadores repetidos", "Resultado": int(df["Identificador"].duplicated().sum()) if len(df) else 0},
        {"Comprobación": f"Títulos sin «{palabra}» (revisar)", "Resultado": len(sin_palabra)},
    ])
    destino = Path(f"BOE_legislacion_{palabra}_{desde}_{hasta}.xlsx" if not respaldo else f"BOE_legislacion_{palabra}_RESPALDO.xlsx")
    with pd.ExcelWriter(destino, engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="Normas", index=False)
        control.to_excel(xw, sheet_name="Control", index=False)
    print(f"[{'#' * 30}] Guardado: {destino} · {len(df)} normas")
    if len(df) == 0:
        print("0 resultados: no tiene por qué ser un error. Comprueba la palabra, el intervalo y la fuente elegida.")


if __name__ == "__main__":
    main()
