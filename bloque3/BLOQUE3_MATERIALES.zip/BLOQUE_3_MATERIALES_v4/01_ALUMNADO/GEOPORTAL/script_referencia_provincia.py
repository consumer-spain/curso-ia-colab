"""
script_referencia_provincia.py · Bloque 3 · práctica principal (RECUPERACIÓN)

Script de referencia para quien no haya conseguido una herramienta propia.
Descarga los precios históricos de las gasolineras de UNA provincia para
varias fechas y los reúne en un único Excel, con la fecha en cada fila.

Fuente (API oficial del Ministerio, ruta canónica):
  https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/
      EstacionesTerrestresHist/FiltroProvincia/{DD-MM-AAAA}/{IDPROVINCIA}

Uso:
  python script_referencia_provincia.py
      -> pregunta fechas y provincia por pantalla

  python script_referencia_provincia.py 12-10-2026 13-10-2026 14-10-2026 --provincia 28

  python script_referencia_provincia.py --respaldo RESPALDO_API
      -> SIN Internet: usa las respuestas reales guardadas en la carpeta RESPALDO_API
         (ficheros hist_prov28_DD-MM-AAAA.json). El Excel lo indica en su nombre.

Requisitos: pip install requests pandas openpyxl
"""

import json
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

URL = "https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/EstacionesTerrestresHist/FiltroProvincia/{fecha}/{prov}"
COLUMNAS = ["Fecha consulta", "Provincia", "Municipio", "Localidad", "Dirección", "C.P.", "Rótulo",
            "Precio Gasolina 95 E5", "Precio Gasoleo A", "Latitud", "Longitud (WGS84)", "IDEESS"]


def barra(i, total, texto):
    hechos = int(30 * i / total)
    print(f"\r[{'#' * hechos}{'.' * (30 - hechos)}] {i}/{total} {texto:<40}", end="", flush=True)


def validar_fecha(t):
    return datetime.strptime(t.strip(), "%d-%m-%Y").strftime("%d-%m-%Y")


def a_numero(v):
    try:
        return float(str(v).replace(",", ".")) if str(v).strip() else None
    except ValueError:
        return None


def estaciones_de_xml(texto):
    """El servicio también puede responder en XML (por ejemplo, al abrirlo en el navegador)."""
    import re
    import xml.etree.ElementTree as ET
    limpio = lambda t: re.sub(r"_x([0-9A-Fa-f]{4})_", lambda m: chr(int(m.group(1), 16)), t.split("}")[-1])
    raiz = ET.fromstring(texto)
    return [{limpio(h.tag): (h.text or "") for h in nodo} for nodo in raiz.iter() if limpio(nodo.tag) == "EESSPrecio"]


def leer_fecha(fecha, prov, carpeta_respaldo, intentos=3):
    """Devuelve la lista de estaciones de una fecha (de Internet o del respaldo)."""
    if carpeta_respaldo:
        base = Path(carpeta_respaldo) / f"hist_prov{prov}_{fecha}"
        if base.with_suffix(".json").exists():
            return json.loads(base.with_suffix(".json").read_text(encoding="utf-8")).get("ListaEESSPrecio", [])
        return estaciones_de_xml(base.with_suffix(".xml").read_bytes())
    import time
    import requests
    for n in range(1, intentos + 1):
        try:
            r = requests.get(URL.format(fecha=fecha, prov=prov), headers={"Accept": "application/json"}, timeout=120)
            r.raise_for_status()
            if r.text.lstrip().startswith("<"):
                return estaciones_de_xml(r.content)
            return r.json().get("ListaEESSPrecio", [])
        except Exception:
            if n == intentos:
                raise
            time.sleep(3 * n)  # reintento: el servicio a veces corta la conexión


def main():
    args = [a for a in sys.argv[1:]]
    respaldo = None
    if "--respaldo" in args:
        i = args.index("--respaldo")
        respaldo = args[i + 1] if i + 1 < len(args) else "RESPALDO_API"
        del args[i:i + 2]
    prov = "28"
    if "--provincia" in args:
        i = args.index("--provincia")
        prov = args[i + 1].zfill(2)
        del args[i:i + 2]

    if respaldo:
        disponibles = sorted(Path(respaldo).glob(f"hist_prov{prov}_*.*"))
        fechas = sorted((p.stem.split("_")[-1] for p in disponibles),
                        key=lambda f: datetime.strptime(f, "%d-%m-%Y"))
        print(f"MODO RESPALDO: respuestas reales guardadas en '{respaldo}' ({len(fechas)} fechas)")
    elif args:
        fechas = [validar_fecha(a) for a in args]
    else:
        fechas = [validar_fecha(f) for f in input("Fechas (DD-MM-AAAA, separadas por comas): ").split(",") if f.strip()]
        prov = (input("Provincia (código de 2 cifras, Intro = 28 Madrid): ").strip() or "28").zfill(2)

    if not fechas:
        print("No hay fechas que consultar.")
        return

    filas, fallidas = [], []
    for n, fecha in enumerate(fechas, start=1):
        barra(n - 1, len(fechas), f"consultando {fecha}...")
        try:
            estaciones = leer_fecha(fecha, prov, respaldo)
            if not estaciones:
                raise ValueError("respuesta sin estaciones")
            for e in estaciones:
                fila = {"Fecha consulta": fecha}
                fila.update({c: e.get(c) for c in COLUMNAS[1:]})
                filas.append(fila)
        except Exception as ex:
            fallidas.append((fecha, str(ex)[:120]))
        barra(n, len(fechas), f"{fecha} listo")
    print()

    if not filas:
        print("No se ha obtenido ningún dato. Fechas fallidas:", fallidas)
        return

    df = pd.DataFrame(filas, columns=COLUMNAS)
    for c in ("Precio Gasolina 95 E5", "Precio Gasoleo A", "Latitud", "Longitud (WGS84)"):
        df[c] = df[c].map(a_numero)

    sufijo = "_RESPALDO" if respaldo else ""
    destino = Path(f"historico_prov{prov}_{fechas[0]}_a_{fechas[-1]}{sufijo}.xlsx")
    resumen = pd.DataFrame(
        [{"Fecha": f, "Estaciones": int((df["Fecha consulta"] == f).sum()), "Estado": "OK"} for f in fechas if f not in dict(fallidas)]
        + [{"Fecha": f, "Estaciones": 0, "Estado": "FALLIDA: " + m} for f, m in fallidas])
    with pd.ExcelWriter(destino, engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="Datos", index=False)
        resumen.to_excel(xw, sheet_name="Control", index=False)

    print(f"Guardado: {destino}  ({len(df)} filas)")
    print(resumen.to_string(index=False))
    if fallidas:
        print("ATENCIÓN: hay fechas fallidas. No las des por buenas sin revisarlas.")


if __name__ == "__main__":
    main()
