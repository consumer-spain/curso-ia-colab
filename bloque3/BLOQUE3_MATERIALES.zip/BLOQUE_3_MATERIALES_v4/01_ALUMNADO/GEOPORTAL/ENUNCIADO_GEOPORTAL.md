# Práctica Geoportal

## Parte A · Descarga (sin programar)
1. https://geoportalgasolineras.es/geoportal-instalaciones/DescargarFicheros
2. «Información actualizada de precios» → abre el fichero.
3. Comprueba: fecha, ámbito, columnas, precios.

## Parte B · Reto
Obtener los precios de las gasolineras de una provincia para 2 o 3 fechas, en un único Excel.

1. Abre tu IA y copia `PROMPTS/02_PROMPT_PRACTICA_GEOPORTAL.txt`.
2. Completa fechas y provincia (28 Madrid, 46 Valencia, 08 Barcelona, 41 Sevilla…).
3. Deja que la IA pregunte. Genera el script, guárdalo (.py) y ejecútalo (`py -3 nombre.py` o `python nombre.py`).
4. Si falla: código + error completo → `PROMPTS/05_PROMPT_CORREGIR_ERROR.txt`.

### Recuperación
- `py -3 GEOPORTAL/script_referencia_provincia.py`
- Sin Internet: `py -3 GEOPORTAL/script_referencia_provincia.py --respaldo GEOPORTAL/RESPALDO_API`

## Comprobación mínima
- Un único Excel; una fila por estación y fecha; columna con la fecha.
- Todas las fechas pedidas, o aviso de cuál falló.
- Precios con valores; solo la provincia pedida.
