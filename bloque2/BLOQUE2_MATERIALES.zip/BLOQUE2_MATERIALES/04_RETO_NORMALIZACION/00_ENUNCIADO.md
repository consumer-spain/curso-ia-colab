# Reto 4 · Normalizar cinco formatos

**Tolerar estructuras distintas:** cinco archivos que significan lo mismo, pero no lo presentan igual.

## Situación

Para la campaña estatal tenemos un libro con 12 CCAA ya integradas y cinco archivos pendientes. Los cinco pretenden representar lo mismo (25 preguntas; Pregunta · Sí · No · No procede), pero no todos lo presentan exactamente de la misma forma. Antes de escalar, los llevamos a una estructura común.

Trabaja con los cinco archivos de `01_ENTRADAS/`:

- `ARAGON.xlsx`
- `ASTURIAS.xlsx`
- `GALICIA.xlsx`
- `MURCIA.xlsx`
- `COMUNITAT_VALENCIANA.xlsx`

## Busca significado, no coordenadas

Crea copias nuevas con la estructura común `Pregunta | Sí | No | No procede` (25 preguntas por archivo). El script debe:

- localizar la tabla por sus encabezados, no por coordenadas fijas;
- identificar las columnas por nombre, no por posición;
- localizar las preguntas 1–25 aunque haya filas vacías;
- ignorar filas, hojas o elementos que no pertenezcan a esa estructura;
- crear las copias normalizadas en `02_TRABAJO/NORMALIZADOS/`;
- conservar exactamente los valores originales, con su tipo: **no convierte tipos ni corrige valores**;
- no modificar los originales.

Normalizar resuelve la **estructura**. No valida ni corrige el **contenido**. No generes todavía estadísticas, consolidado ni gráficas.

Prompt: `03_RESUELTO/PROMPT_REFERENCIA.txt`. Referencia: `03_RESUELTO/normalizar_entradas.py`.

## ¿Hemos perdido o cambiado algo al normalizar?

Lo que comprobaríamos: 5 archivos de salida · 25 preguntas por archivo · preguntas 1–25 una sola vez · mismos textos · mismos valores · mismos tipos · mismos totales por pregunta · originales intactos.

No hace falta construir otro programa: el resultado del comprobador de referencia está en `03_RESUELTO/CONTROL_NORMALIZACION.xlsx` — **5 archivos, 5 OK**, incluida Comunitat Valenciana.

Un OK en este control significa que la normalización **no ha perdido ni alterado datos**. Normalizar estructura no significa alterar datos.

**Referencia / ampliación (opcional):** `03_RESUELTO/comprobar_normalizacion.py` y su prompt `03_RESUELTO/PROMPT_COMPROBADOR.txt`. Para repetir el control sobre tus salidas:

```bash
python 03_RESUELTO/normalizar_entradas.py          # → 02_TRABAJO/NORMALIZADOS/
python 03_RESUELTO/comprobar_normalizacion.py      # → 02_TRABAJO/CONTROL_NORMALIZACION.xlsx
```

## Carpetas

- `01_ENTRADAS/` — los cinco pendientes (no los modifiques).
- `02_TRABAJO/` — tu script y tus salidas.
- `03_RESUELTO/` — `PROMPT_REFERENCIA.txt`, `normalizar_entradas.py`, `NORMALIZADOS/` (5 archivos de referencia), `CONTROL_NORMALIZACION.xlsx` y, como ampliación, `comprobar_normalizacion.py` + `PROMPT_COMPROBADOR.txt`.
