#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Comprobador independiente de la normalización.

Compara cada archivo original con su versión normalizada y responde a UNA
pregunta: ¿la normalización estructural ha conservado correctamente los datos?

No convierte tipos ni evalúa si los valores son numéricos: eso es otra
pregunta (tipo / interpretación) que se responde más adelante.
"""
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill

ARCHIVOS = ["ARAGON.xlsx", "ASTURIAS.xlsx", "GALICIA.xlsx", "MURCIA.xlsx", "COMUNITAT_VALENCIANA.xlsx"]
OBJETIVOS = {"pregunta", "si", "no", "no procede"}


def norm(v: Any) -> str:
    return "" if v is None else str(v).strip().lower().replace("í", "i")


def numero(v: Any) -> Optional[int]:
    if v is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(v))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def cabecera(ws) -> Optional[Tuple[int, Dict[str, int]]]:
    for row in ws.iter_rows():
        cols: Dict[str, int] = {}
        for c in row:
            n = norm(c.value)
            if n in OBJETIVOS:
                cols[n] = c.column
        if OBJETIVOS.issubset(cols):
            return row[0].row, cols
    return None


def leer_original(path: Path) -> Dict[int, tuple]:
    wb = load_workbook(path, data_only=True)
    tablas = []
    for ws in wb.worksheets:
        h = cabecera(ws)
        if h is None:
            continue
        r0, cols = h
        d = {}
        for r in range(r0 + 1, ws.max_row + 1):
            t = ws.cell(r, cols["pregunta"]).value
            n = numero(t)
            if n is None:
                continue
            if n in d:
                raise ValueError(f"{path.name}: pregunta {n} duplicada")
            d[n] = (str(t), ws.cell(r, cols["si"]).value, ws.cell(r, cols["no"]).value, ws.cell(r, cols["no procede"]).value)
        if d:
            tablas.append(d)
    if len(tablas) != 1:
        raise ValueError(f"{path.name}: {len(tablas)} tablas de datos")
    return tablas[0]


def leer_normalizado(path: Path) -> tuple[Dict[int, tuple], int, Optional[str]]:
    wb = load_workbook(path, data_only=True)
    ws = wb["DATOS"]
    out: Dict[int, tuple] = {}
    filas = 0
    for r in range(2, ws.max_row + 1):
        t = ws.cell(r, 1).value
        if t is None:
            continue
        filas += 1
        n = numero(t)
        if n is None or n in out:
            continue
        out[n] = (str(t), ws.cell(r, 2).value, ws.cell(r, 3).value, ws.cell(r, 4).value)
    huella = None
    if "CONTROL" in wb.sheetnames:
        for campo, valor in wb["CONTROL"].iter_rows(min_row=2, values_only=True):
            if campo == "huella_original_sha256":
                huella = valor
    return out, filas, huella


def es_numero(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def identico(a: Any, b: Any) -> bool:
    """Mismo valor y mismo tipo: '12' (texto) no es igual a 12 (número)."""
    return type(a) is type(b) and a == b


def total_conservado(o: tuple, s: tuple) -> bool:
    """Sin convertir tipos: si los tres valores son números se comparan las sumas;
    si no, el total solo se conserva si los tres valores son idénticos."""
    if all(es_numero(v) for v in o[1:] + s[1:]):
        return sum(o[1:]) == sum(s[1:])
    return all(identico(a, b) for a, b in zip(o[1:], s[1:]))


def main() -> None:
    reto = Path(__file__).resolve().parents[1]  # 04_RETO_NORMALIZACION
    parser = argparse.ArgumentParser(description="Comprueba que la normalización no ha perdido ni alterado datos.")
    parser.add_argument("--originales", type=Path, default=reto / "01_ENTRADAS")
    parser.add_argument("--normalizados", type=Path, default=reto / "02_TRABAJO" / "NORMALIZADOS")
    parser.add_argument("--salida", type=Path, default=reto / "02_TRABAJO" / "CONTROL_NORMALIZACION.xlsx")
    args = parser.parse_args()

    filas = []
    ok_global = True
    for nombre in ARCHIVOS:
        src = args.originales / nombre
        norm_path = args.normalizados / f"{Path(nombre).stem}_NORMALIZADO.xlsx"
        if not norm_path.exists():
            filas.append([nombre, None, None, False, False, False, False, False, False, "REVISAR", "falta el archivo normalizado"])
            ok_global = False
            print(f"{nombre}: REVISAR (falta la salida)")
            continue
        orig = leer_original(src)
        normd, n_filas, huella = leer_normalizado(norm_path)
        r = range(1, 26)
        preguntas_ok = set(orig) == set(r) and set(normd) == set(r) and n_filas == 25
        textos_ok = preguntas_ok and all(orig[n][0] == normd[n][0] for n in r)
        valores_ok = preguntas_ok and all(orig[n][i] == normd[n][i] for n in r for i in (1, 2, 3))
        tipos_ok = preguntas_ok and all(type(orig[n][i]) is type(normd[n][i]) for n in r for i in (1, 2, 3))
        totales_ok = preguntas_ok and all(total_conservado(orig[n], normd[n]) for n in r)
        intacto = huella is not None and hashlib.sha256(src.read_bytes()).hexdigest() == huella
        ok = all([preguntas_ok, textos_ok, valores_ok, tipos_ok, totales_ok, intacto])
        estado = "OK" if ok else "REVISAR"
        ok_global &= ok
        obs = "" if ok else "; ".join(t for t, c in [("preguntas", preguntas_ok), ("textos", textos_ok), ("valores", valores_ok), ("tipos", tipos_ok), ("totales", totales_ok), ("original", intacto)] if not c) + " no coinciden"
        filas.append([nombre, len(orig), n_filas, preguntas_ok, textos_ok, valores_ok, tipos_ok, totales_ok, intacto, estado, obs])
        print(f"{nombre}: {estado}")

    wb = Workbook(); ws = wb.active; ws.title = "CONTROL_NORMALIZACION"
    ws.append(["archivo", "preguntas_origen", "preguntas_salida", "1_25_una_vez", "textos_iguales", "valores_iguales", "tipos_conservados", "totales_conservados", "original_intacto", "estado", "observacion"])
    for row in filas:
        ws.append(row)
    for c in ws[1]:
        c.font = Font(bold=True); c.fill = PatternFill("solid", fgColor="D9EAF7")
    for col, width in {"A": 30, "B": 17, "C": 17, "D": 14, "E": 15, "F": 15, "G": 18, "H": 19, "I": 16, "J": 10, "K": 40}.items():
        ws.column_dimensions[col].width = width
    args.salida.parent.mkdir(parents=True, exist_ok=True); wb.save(args.salida)
    print("Pregunta que responde: ¿la normalización ha conservado los datos? (no evalúa si son numéricos)")
    print(f"Control creado: {args.salida}")
    if not ok_global:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
