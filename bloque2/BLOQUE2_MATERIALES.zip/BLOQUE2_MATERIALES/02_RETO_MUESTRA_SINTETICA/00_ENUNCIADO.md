# Reto 2 · Crear una muestra sintética

**Transformar una fuente:** crear datos ficticios que conserven las propiedades que necesita la tarea.

## Situación

Para pedir ayuda a una IA necesitamos describirle los datos, pero que tengamos el archivo no significa que podamos enviarlo tal cual a cualquier servicio. En lugar de compartir los recuentos reales, generamos una muestra sintética con la misma forma.

Partimos de `01_ENTRADAS/00_MADRID_SIMULADO_PARA_MUESTRA.xlsx`.

## La muestra debe

- conservar las mismas 25 preguntas;
- conservar los encabezados y la estructura útil;
- usar cifras ficticias nuevas;
- usar enteros no negativos;
- mantener el mismo total por pregunta (Sí + No + No procede);
- ser un archivo **nuevo**: el original no se modifica.

## Prompt mínimo orientativo

> Tengo el archivo 00_MADRID_SIMULADO_PARA_MUESTRA.xlsx, con 25 preguntas y recuentos Sí / No / No procede. Escribe un script en Python que cree una COPIA nueva del archivo en la que: se conserven las 25 preguntas y la misma estructura de columnas; los recuentos se sustituyan por enteros no negativos generados al azar; el total Sí + No + No procede de cada pregunta sea el mismo que en el original. No modifiques el archivo original.

## Comprueba la muestra antes de utilizarla

25 preguntas · misma estructura · recuentos cambiados · total conservado en cada pregunta · archivo nuevo · original intacto.

Que el script termine no significa que la muestra sea correcta.

## Carpetas

- `01_ENTRADAS/` — el Excel de Madrid (no lo modifiques).
- `02_TRABAJO/` — tu script y tu muestra.
- `03_RESUELTO/` — `PROMPT_REFERENCIA.txt`, `generar_muestra_sintetica.py` (semilla 42; escribe `02_TRABAJO/MUESTRA_MADRID_PARA_IA.xlsx`) y `MUESTRA_MADRID_PARA_IA.xlsx` (salida esperada con esa semilla).
