# Reto 1 · Reconciliar documentación

**Dos fuentes:** un Excel que dice qué archivos deberían existir y una carpeta con los archivos que existen realmente.

## Situación

Una unidad de vigilancia de mercado necesita saber si la documentación de un expediente está completa. Tienes:

- un Excel con la documentación que debería existir;
- una carpeta con los archivos que existen realmente;
- y puede haber subcarpetas.

El objetivo es construir una herramienta que compare ambas fuentes y genere un Excel nuevo con el resultado.

## Criterios de aceptación (se definen antes de programar)

Para cada fila del Excel debe indicar:

- `Encontrado` — el archivo existe;
- `No encontrado` — debería existir, pero no está;
- `Sin nombre indicado` — la fila no especifica un archivo.

Además debe:

- buscar también dentro de subcarpetas;
- detectar archivos presentes en la carpeta pero no registrados en el Excel;
- crear una hoja `Sin registrar`;
- generar un Excel nuevo;
- preservar el Excel y las imágenes originales.

## Carpetas

- `01_ENTRADAS/` — `listado_inspeccion.xlsx` (hoja `Documentacion`, columna `nombre_archivo`) e `imagenes/` (con una subcarpeta). No modifiques nada aquí.
- `02_TRABAJO/` — guarda aquí tu script y tus salidas.
- `03_RESUELTO/` — vía de desbloqueo:
  - `PROMPT_REFERENCIA.txt` — cómo describir el problema a una IA (prompt completo, ampliación de interfaz y comparación con una referencia);
  - `solucion_nivel1.py` — solución de referencia (escribe `02_TRABAJO/resultado_comprobacion.xlsx`);
  - `solucion_nivel2.py` / `solucion_nivel2.pyw` — ampliación opcional con interfaz gráfica (tkinter);
  - `resultado_referencia.xlsx` — salida esperada.

## Resultado esperado

21 encontrados · 3 no encontrados · 1 sin nombre indicado · 2 sin registrar. `CAPTURA_007.jpg` está dentro de una subcarpeta.

La interfaz gráfica es una ampliación opcional: no es necesaria para completar el reto.
