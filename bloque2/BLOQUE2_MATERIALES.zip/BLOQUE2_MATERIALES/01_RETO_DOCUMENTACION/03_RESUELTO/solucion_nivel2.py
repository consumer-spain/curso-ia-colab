from __future__ import annotations

from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import pandas as pd


EXTENSIONES_ADMITIDAS = {".jpg", ".jpeg", ".png", ".webp"}


def normalizar_nombre(valor: object) -> str | None:
    if pd.isna(valor):
        return None
    nombre = str(valor).strip()
    return nombre or None


def indexar_archivos(carpeta: Path) -> tuple[dict[str, list[Path]], list[Path]]:
    todos = sorted(
        ruta
        for ruta in carpeta.rglob("*")
        if ruta.is_file() and ruta.suffix.lower() in EXTENSIONES_ADMITIDAS
    )
    indice: dict[str, list[Path]] = {}
    for ruta in todos:
        indice.setdefault(ruta.name.casefold(), []).append(ruta)
    return indice, todos


def comprobar_documentacion(excel: Path, carpeta: Path, salida: Path) -> dict[str, int]:
    datos = pd.read_excel(excel, sheet_name="Documentacion")
    columna = "nombre_archivo"
    if columna not in datos.columns:
        raise KeyError(
            f"El Excel debe contener la columna '{columna}'.\n"
            f"Columnas disponibles: {', '.join(map(str, datos.columns))}"
        )

    indice, archivos_carpeta = indexar_archivos(carpeta)
    nombres_registrados: set[str] = set()
    estados: list[str] = []
    rutas: list[str] = []

    for valor in datos[columna]:
        nombre = normalizar_nombre(valor)
        if nombre is None:
            estados.append("Sin nombre indicado")
            rutas.append("")
            continue

        clave = nombre.casefold()
        nombres_registrados.add(clave)
        coincidencias = indice.get(clave, [])
        if coincidencias:
            estados.append("Encontrado")
            rutas.append(str(coincidencias[0].relative_to(carpeta)))
        else:
            estados.append("No encontrado")
            rutas.append("")

    resultado = datos.copy()
    resultado["estado"] = estados
    resultado["ruta_encontrada"] = rutas

    sin_registrar = [
        {"nombre_archivo": ruta.name, "ruta": str(ruta.relative_to(carpeta))}
        for ruta in archivos_carpeta
        if ruta.name.casefold() not in nombres_registrados
    ]

    salida.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(salida, engine="openpyxl") as escritor:
        resultado.to_excel(escritor, sheet_name="Comprobacion", index=False)
        pd.DataFrame(sin_registrar, columns=["nombre_archivo", "ruta"]).to_excel(
            escritor, sheet_name="Sin registrar", index=False
        )

    return {
        "encontrados": estados.count("Encontrado"),
        "no_encontrados": estados.count("No encontrado"),
        "sin_nombre": estados.count("Sin nombre indicado"),
        "sin_registrar": len(sin_registrar),
    }


class Aplicacion(ttk.Frame):
    def __init__(self, master: tk.Tk) -> None:
        super().__init__(master, padding=16)
        self.pack(fill="both", expand=True)

        self.excel = tk.StringVar()
        self.carpeta = tk.StringVar()
        self.salida = tk.StringVar()

        self._crear_fila("Excel de referencia", self.excel, self._elegir_excel, 0)
        self._crear_fila("Carpeta de archivos", self.carpeta, self._elegir_carpeta, 1)
        self._crear_fila("Excel de salida", self.salida, self._elegir_salida, 2)

        ttk.Button(
            self,
            text="Comprobar documentación",
            command=self._ejecutar,
        ).grid(row=3, column=0, columnspan=3, pady=(18, 8), sticky="ew")

        ttk.Label(
            self,
            text="Los archivos originales no se modifican.",
        ).grid(row=4, column=0, columnspan=3, sticky="w")

        self.columnconfigure(1, weight=1)

    def _crear_fila(
        self,
        texto: str,
        variable: tk.StringVar,
        comando,
        fila: int,
    ) -> None:
        ttk.Label(self, text=texto).grid(row=fila, column=0, padx=(0, 8), pady=6, sticky="w")
        ttk.Entry(self, textvariable=variable).grid(row=fila, column=1, pady=6, sticky="ew")
        ttk.Button(self, text="Seleccionar…", command=comando).grid(
            row=fila, column=2, padx=(8, 0), pady=6
        )

    def _elegir_excel(self) -> None:
        ruta = filedialog.askopenfilename(
            title="Selecciona el Excel",
            filetypes=[("Archivos Excel", "*.xlsx")],
        )
        if ruta:
            self.excel.set(ruta)
            if not self.salida.get():
                self.salida.set(str(Path(ruta).with_name("resultado_comprobacion.xlsx")))

    def _elegir_carpeta(self) -> None:
        ruta = filedialog.askdirectory(title="Selecciona la carpeta de archivos")
        if ruta:
            self.carpeta.set(ruta)

    def _elegir_salida(self) -> None:
        ruta = filedialog.asksaveasfilename(
            title="Guarda el resultado",
            defaultextension=".xlsx",
            filetypes=[("Archivos Excel", "*.xlsx")],
        )
        if ruta:
            self.salida.set(ruta)

    def _ejecutar(self) -> None:
        try:
            excel = Path(self.excel.get())
            carpeta = Path(self.carpeta.get())
            salida = Path(self.salida.get())

            if not self.excel.get() or not excel.is_file():
                raise FileNotFoundError("Selecciona un Excel válido.")
            if not self.carpeta.get() or not carpeta.is_dir():
                raise NotADirectoryError("Selecciona una carpeta válida.")
            if not self.salida.get():
                raise ValueError("Selecciona dónde guardar el resultado.")

            resumen = comprobar_documentacion(excel, carpeta, salida)
            messagebox.showinfo(
                "Proceso completado",
                "Resultado guardado en:\n"
                f"{salida}\n\n"
                f"Encontrados: {resumen['encontrados']}\n"
                f"No encontrados: {resumen['no_encontrados']}\n"
                f"Sin nombre indicado: {resumen['sin_nombre']}\n"
                f"Archivos sin registrar: {resumen['sin_registrar']}",
            )
        except Exception as exc:
            messagebox.showerror("No se pudo completar el proceso", str(exc))


def main() -> None:
    ventana = tk.Tk()
    ventana.title("Comprobador de documentación")
    ventana.geometry("760x250")
    ventana.minsize(650, 230)
    Aplicacion(ventana)
    ventana.mainloop()


if __name__ == "__main__":
    main()
