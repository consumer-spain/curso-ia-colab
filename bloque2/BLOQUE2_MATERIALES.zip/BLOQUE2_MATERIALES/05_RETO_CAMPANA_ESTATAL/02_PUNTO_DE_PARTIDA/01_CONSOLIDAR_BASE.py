#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bloque 2 · Reto 5 · Primer hito (punto de partida): base de consolidación y control

Localiza las tablas por sus encabezados, extrae las preguntas 1–25, conserva la
trazabilidad de archivo/hoja y genera DATOS_CONSOLIDADOS y CONTROL_CARGA.
Es una primera iteración deliberadamente limitada: conviene revisar CONTROL_CARGA
antes de ampliar la herramienta con estadísticas y gráficas.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.worksheet.worksheet import Worksheet

RESPUESTAS = {"pregunta", "si", "no", "no procede"}


def norm(text: Any) -> str:
    s = "" if text is None else str(text)
    return s.strip().lower().replace("í", "i").replace("  ", " ")


def numero_pregunta(texto: Any) -> Optional[int]:
    if texto is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(texto))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def bloque_de_pregunta(n: int) -> str:
    if 1 <= n <= 5:
        return "Información necesaria en la oferta comercial"
    if 6 <= n <= 14:
        return "Información previa al contrato"
    if 15 <= n <= 25:
        return "Contratación, facturación y cláusulas abusivas"
    return ""


def comunidad_desde_hoja(ws: Worksheet) -> str:
    # Preferimos el título de la primera línea si contiene el guion largo con la comunidad.
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 5), values_only=True):
        for val in row:
            if isinstance(val, str) and "—" in val:
                return val.split("—")[-1].strip()
    return ws.title


def encontrar_cabecera(ws: Worksheet) -> Optional[Tuple[int, Dict[str, int]]]:
    for row in ws.iter_rows():
        cols: Dict[str, int] = {}
        for cell in row:
            n = norm(cell.value)
            if n in RESPUESTAS:
                cols[n] = cell.column
        if {"pregunta", "si", "no", "no procede"}.issubset(cols.keys()):
            return row[0].row, cols
    return None


def es_numero_excel(valor: Any) -> bool:
    return isinstance(valor, (int, float)) and not isinstance(valor, bool)


def extraer_tabla(ws: Worksheet, archivo: Path) -> Tuple[List[dict], dict]:
    header = encontrar_cabecera(ws)
    comunidad = comunidad_desde_hoja(ws)
    if header is None:
        return [], {
            "comunidad_autonoma": comunidad,
            "archivo_origen": archivo.name,
            "hoja_origen": ws.title,
            "preguntas_detectadas": 0,
            "preguntas_numericas_validas": 0,
            "controles_realizados": None,
            "preguntas_suma_correcta": 0,
            "estado": "DESCARTADA",
            "observacion": "No se encontró cabecera Pregunta/Sí/No/No procede",
        }
    header_row, cols = header
    registros: List[dict] = []
    validas = 0
    suma_correcta = 0
    realizados_vals = []
    preguntas_detectadas = 0
    for r in range(header_row + 1, ws.max_row + 1):
        pregunta = ws.cell(r, cols["pregunta"]).value
        n = numero_pregunta(pregunta)
        if n is None:
            continue
        preguntas_detectadas += 1
        si = ws.cell(r, cols["si"]).value
        no = ws.cell(r, cols["no"]).value
        no_proc = ws.cell(r, cols["no procede"]).value
        numeric_ok = all(es_numero_excel(v) for v in (si, no, no_proc))
        total = None
        if numeric_ok:
            validas += 1
            total = int(si) + int(no) + int(no_proc)
            realizados_vals.append(total)
        registros.append({
            "comunidad_autonoma": comunidad,
            "numero_pregunta": n,
            "bloque": bloque_de_pregunta(n),
            "pregunta": str(pregunta),
            "si": si,
            "no": no,
            "no_procede": no_proc,
            "realizados": total,
            "archivo_origen": archivo.name,
            "hoja_origen": ws.title,
            "valores_numericos_validos": numeric_ok,
        })
    controles_realizados = max(set(realizados_vals), key=realizados_vals.count) if realizados_vals else None
    # Coherencia: cada pregunta debe sumar los controles realizados por la CCAA (el valor más frecuente).
    suma_correcta = sum(1 for t in realizados_vals if t == controles_realizados)
    estado = "OK" if preguntas_detectadas == 25 and validas == 25 and suma_correcta == 25 else "REVISAR"
    observacion = ""
    if preguntas_detectadas != 25:
        observacion = f"Preguntas detectadas: {preguntas_detectadas}"
    elif validas != 25:
        observacion = "Hay preguntas detectadas cuyos recuentos no son numéricamente válidos"
    return registros, {
        "comunidad_autonoma": comunidad,
        "archivo_origen": archivo.name,
        "hoja_origen": ws.title,
        "preguntas_detectadas": preguntas_detectadas,
        "preguntas_numericas_validas": validas,
        "controles_realizados": controles_realizados,
        "preguntas_suma_correcta": suma_correcta,
        "estado": estado,
        "observacion": observacion,
    }


def libros_de_entrada(base_12: Path, pendientes: Path) -> List[Path]:
    return [base_12] + sorted(pendientes.glob("*.xlsx"))


def consolidar(base_12: Path, pendientes: Path, salida: Path) -> None:
    todos_registros: List[dict] = []
    controles: List[dict] = []
    hojas_descartadas: List[dict] = []
    for libro in libros_de_entrada(base_12, pendientes):
        wb = load_workbook(libro, data_only=True)
        for ws in wb.worksheets:
            registros, control = extraer_tabla(ws, libro)
            if registros:
                todos_registros.extend(registros)
                controles.append(control)
            else:
                hojas_descartadas.append(control)
    crear_excel(salida, todos_registros, controles, hojas_descartadas)
    incidencias = sum(1 for c in controles if c["estado"] != "OK")
    print("Proceso completado.")
    print(f"Comunidades detectadas: {len(controles)}")
    print(f"Registros consolidados: {len(todos_registros)}")
    print(f"Comunidades con incidencias: {incidencias}")
    print("Revisa la hoja CONTROL_CARGA antes de continuar.")
    print(f"Archivo creado: {salida}")


def crear_excel(salida: Path, registros: List[dict], controles: List[dict], descartadas: List[dict]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "DATOS_CONSOLIDADOS"
    headers = ["comunidad_autonoma", "numero_pregunta", "bloque", "pregunta", "si", "no", "no_procede", "realizados", "archivo_origen", "hoja_origen", "valores_numericos_validos"]
    ws.append(headers)
    for reg in sorted(registros, key=lambda x: (x["comunidad_autonoma"], x["numero_pregunta"])):
        ws.append([reg.get(h) for h in headers])
    ctrl = wb.create_sheet("CONTROL_CARGA")
    ctrl_headers = ["comunidad_autonoma", "archivo_origen", "hoja_origen", "preguntas_detectadas", "preguntas_numericas_validas", "controles_realizados", "preguntas_suma_correcta", "estado", "observacion"]
    ctrl.append(ctrl_headers)
    for c in sorted(controles, key=lambda x: x["comunidad_autonoma"]):
        ctrl.append([c.get(h) for h in ctrl_headers])
    desc = wb.create_sheet("HOJAS_DESCARTADAS")
    desc.append(ctrl_headers)
    for c in descartadas:
        desc.append([c.get(h) for h in ctrl_headers])
    instrucciones = wb.create_sheet("INSTRUCCIONES", 0)
    instrucciones.append(["Bloque 2 · Base de consolidación"])
    instrucciones.append(["Esta versión localiza las tablas y genera un control de carga. No genera estadísticas ni gráficas."])
    instrucciones.append(["Revisa CONTROL_CARGA antes de continuar. Encontrar preguntas no equivale a utilizar correctamente sus valores."])
    aplicar_formato(wb)
    salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(salida)


def aplicar_formato(wb: Workbook) -> None:
    fill = PatternFill("solid", fgColor="D9EAF7")
    thin = Side(style="thin", color="BFBFBF")
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = fill
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin)
        for col in ws.columns:
            letter = col[0].column_letter
            max_len = min(max(len(str(c.value)) if c.value is not None else 0 for c in col) + 2, 55)
            ws.column_dimensions[letter].width = max(10, max_len)


def main() -> None:
    reto = Path(__file__).resolve().parents[1]  # 05_RETO_CAMPANA_ESTATAL
    entradas = reto / "01_ENTRADAS"
    parser = argparse.ArgumentParser(description="Consolida datos autonómicos y genera control de carga.")
    parser.add_argument("--base-12", type=Path, default=entradas / "BASE_12_CCAA.xlsx")
    parser.add_argument("--pendientes", type=Path, default=entradas / "CCAA_PENDIENTES")
    parser.add_argument("--salida", type=Path, default=reto / "03_TRABAJO" / "SALIDAS" / "CONSOLIDADO_BASE.xlsx")
    args = parser.parse_args()
    consolidar(args.base_12, args.pendientes, args.salida)


if __name__ == "__main__":
    main()
