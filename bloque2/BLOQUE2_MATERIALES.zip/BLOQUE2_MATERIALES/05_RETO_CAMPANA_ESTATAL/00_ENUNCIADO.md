# Reto 5 · Campaña estatal

**Escalar a 17 CCAA:** 12 comunidades ya integradas + 5 pendientes → una visión estatal reproducible.

## El encargo y sus 8 piezas

> «Hazme un programa en Python que junte estos Excel, saque estadísticas y gráficas.»

¿Basta con este encargo? ¿Qué decisiones o información necesitaría una IA antes de escribir código? A lo largo del bloque resolvemos ocho piezas. No son una plantilla universal ni un «prompt mágico»: son el mapa de las decisiones que hay que tomar **para este problema**.

1. **Objetivo** — ¿para qué quiero la herramienta?
2. **Estructura** — ¿qué significan mis datos?
3. **Restricciones** — ¿qué puedo hacer o compartir? *(Reto 2)*
4. **Reglas** — ¿cómo debe calcularse? *(Reto 3)*
5. **Controles** — ¿cómo demuestro que funciona? *(Reto 3)*
6. **Resultado** — ¿qué debe entregar exactamente? *(Reto 3)*
7. **Archivos** — ¿qué fuentes concretas procesa? *(Reto 4)*
8. **Variaciones** — ¿qué diferencias debe tolerar? *(Reto 4)*

Las piezas son el mapa de decisiones del problema estatal. Los retos 2, 3 y 4 son los ejercicios con los que las resolvemos. En el Reto 5 las aplicamos todas.

## Entradas (`01_ENTRADAS/`)

- `BASE_12_CCAA.xlsx` — libro con 12 CCAA ya integradas;
- `CCAA_PENDIENTES/` — `ARAGON.xlsx`, `ASTURIAS.xlsx`, `GALICIA.xlsx`, `MURCIA.xlsx`, `COMUNITAT_VALENCIANA.xlsx`.

El modelo de 2 CCAA (`../03_RETO_DOS_CCAA/00_MODELO_MANUAL/MODELO_2_CCAA.xlsx`) es una **referencia**, no una entrada: añadirlo duplicaría Madrid y Castilla y León, que ya están en el libro de 12.

## Primer hito · punto de partida (`02_PUNTO_DE_PARTIDA/`)

Primero demostramos que podemos **leer y reunir**:

- `PROMPT_PRIMER_HITO.txt` — la conversación con la IA (MENSAJES 1–5);
- `01_CONSOLIDAR_BASE.py` — primera versión deliberadamente limitada: lee las 17 CCAA y genera `DATOS_CONSOLIDADOS` + `CONTROL_CARGA` (sin estadísticas ni gráficas). Escribe `03_TRABAJO/SALIDAS/CONSOLIDADO_BASE.xlsx`.

`CONTROL_CARGA` es el recibo de lectura de la herramienta: deja constancia de qué ha leído (comunidad, archivo, hoja), qué ha podido interpretar (preguntas detectadas y preguntas con valores válidos, controles, coherencia) y dónde ha encontrado incidencias (estado y observación). No es otra tabla de estadísticas: es trazabilidad de carga.

## Trabajo autónomo · 20 minutos (`03_TRABAJO/`)

### 1 · GENERA

Un libro con:

- `DATOS_CONSOLIDADOS` — 425 registros;
- `ESTADISTICAS_CCAA`;
- `NACIONAL` por pregunta y resumen por bloques;
- cuatro gráficas nacionales;
- `CONTROL_CARGA`.

Puedes partir de `01_CONSOLIDAR_BASE.py`, de tu código anterior (normalizador, mini-script de 2 CCAA) o de cero: no hay una única arquitectura correcta.

### 2 · COMPRUEBA

Antes de darlo por terminado, comprueba al menos:

- 17 CCAA;
- 25 preguntas por CCAA;
- 425 combinaciones comunidad-pregunta;
- valores numéricamente válidos;
- `Sí + No + No procede = realizados`;
- ninguna comunidad omitida;
- nacional calculado sumando recuentos y recalculando porcentajes.

### 3 · ESCALA · opcional

Solo después de comprobar: gráficas por CCAA, ranking de preguntas, índice, registro de incidencias, controles adicionales.

## Después del programa: revisar la salida

El programa termina. El trabajo, no: revisamos `CONTROL_CARGA` antes de confiar en el resultado. Si algo no cuadra, primero se diagnostica y después se corrige (prompts en `04_RESUELTO/DIAGNOSTICO/`). Después repasamos las cinco preguntas antes de confiar (`CINCO_PREGUNTAS_ANTES_DE_CONFIAR.md`).

## Resuelto (`04_RESUELTO/`)

- `PROMPT_SOLUCION.txt` — el encargo completo para una IA;
- `solucion_completa.py` — solución de referencia (escribe `03_TRABAJO/SALIDAS/SOLUCION_COMPLETA_17_CCAA.xlsx`);
- `SOLUCION_REFERENCIA.xlsx` — salida esperada: 17 CCAA · 425 registros · 425 válidos · 351 controles por pregunta · resumen por bloques · 4 gráficas · `CONTROL_CARGA`;
- `DIAGNOSTICO/` — prompts de diagnóstico y corrección limitada, `diagnosticar_tipos.py` y su salida de referencia;
- `PROMPTS_DE_APOYO.md` — prompts complementarios (comparar con una referencia, entender una solución por bloques…).

## Regla de seguridad

No modifiques, renombres ni sobrescribas los archivos originales. Genera salidas nuevas.
