#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Diagnóstico de tipos en las entradas del reto.

No corrige datos. Solo informa de cuántas celdas de respuesta son numéricas,
texto numérico, otro texto, vacías u otros tipos.
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from openpyxl import load_workbook

OBJETIVOS = {"pregunta", "si", "no", "no procede"}


def norm(v: Any) -> str:
    return "" if v is None else str(v).strip().lower().replace("í", "i").replace("  ", " ")


def numero_pregunta(v: Any) -> Optional[int]:
    if v is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(v))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def cabecera(ws) -> Optional[Tuple[int, Dict[str, int]]]:
    for row in ws.iter_rows():
        cols: Dict[str, int] = {}
        for c in row:
            n = norm(c.value)
            if n in OBJETIVOS:
                cols[n] = c.column
        if OBJETIVOS.issubset(cols):
            return row[0].row, cols
    return None


def comunidad(ws) -> str:
    for row in ws.iter_rows(min_row=1, max_row=min(5, ws.max_row), values_only=True):
        for v in row:
            if isinstance(v, str) and "—" in v:
                return v.split("—")[-1].strip()
    return ws.title


def tipo(v: Any) -> str:
    if v is None:
        return "vacio"
    if isinstance(v, bool):
        return "otro"
    if isinstance(v, (int, float)):
        return "numerico"
    if isinstance(v, str):
        limpio = v.replace("\u00a0", " ").strip()
        if re.fullmatch(r"[+-]?\d+", limpio):
            return "texto_numerico"
        return "texto_no_numerico"
    return "otro"


def analizar_libro(path: Path) -> list[dict]:
    wb = load_workbook(path, data_only=True)
    resultados = []
    for ws in wb.worksheets:
        h = cabecera(ws)
        if h is None:
            continue
        r0, cols = h
        cont = {"numerico":0,"texto_numerico":0,"texto_no_numerico":0,"vacio":0,"otro":0}
        preguntas = 0
        ejemplos = []
        for r in range(r0+1, ws.max_row+1):
            p = ws.cell(r, cols["pregunta"]).value
            n = numero_pregunta(p)
            if n is None:
                continue
            preguntas += 1
            for k in ("si","no","no procede"):
                v = ws.cell(r, cols[k]).value
                t = tipo(v); cont[t] += 1
                if len(ejemplos) < 3:
                    ejemplos.append(f"P{n} {k}={v!r} → {t}")
        if preguntas:
            resultados.append({
                "comunidad": comunidad(ws), "archivo": path.name, "hoja": ws.title,
                "preguntas_detectadas": preguntas, **cont,
                "ejemplo": " | ".join(ejemplos)
            })
    return resultados


def main() -> None:
    reto = Path(__file__).resolve().parents[2]  # 05_RETO_CAMPANA_ESTATAL
    entradas = reto / "01_ENTRADAS"
    parser = argparse.ArgumentParser(description="Diagnostica tipos de dato sin corregirlos.")
    parser.add_argument("--base-12", type=Path, default=entradas / "BASE_12_CCAA.xlsx")
    parser.add_argument("--pendientes", type=Path, default=entradas / "CCAA_PENDIENTES")
    parser.add_argument("--salida", type=Path, default=reto / "03_TRABAJO" / "SALIDAS" / "diagnostico_tipos.csv")
    args = parser.parse_args()

    libros = [args.base_12] + sorted(args.pendientes.glob("*.xlsx"))
    filas = []
    for libro in libros:
        filas.extend(analizar_libro(libro))
    filas.sort(key=lambda x: x["comunidad"])
    if len(filas) != 17:
        print(f"AVISO: se esperaban 17 tablas de CCAA y se han encontrado {len(filas)}")

    campos = ["comunidad","archivo","hoja","preguntas_detectadas","numerico","texto_numerico","texto_no_numerico","vacio","otro","ejemplo"]
    args.salida.parent.mkdir(parents=True, exist_ok=True)
    with args.salida.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=campos)
        w.writeheader(); w.writerows(filas)

    print("comunidad | preguntas | numéricas | texto numérico | otro texto | vacías | otros")
    for x in filas:
        print(f"{x['comunidad']} | {x['preguntas_detectadas']} | {x['numerico']} | {x['texto_numerico']} | {x['texto_no_numerico']} | {x['vacio']} | {x['otro']}")
    print(f"CSV creado: {args.salida}")


if __name__ == "__main__":
    main()
