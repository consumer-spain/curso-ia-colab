# Prompts de apoyo · Reto 5

Prompts complementarios para quien se bloquee en el Reto 5. Los textos exactos que aparecen en la presentación están en `../02_PUNTO_DE_PARTIDA/PROMPT_PRIMER_HITO.txt` (MENSAJES 1–5) y `DIAGNOSTICO/PROMPTS_DIAGNOSTICO_Y_CORRECCION.txt` (PROMPTS 1–2). El encargo completo está en `PROMPT_SOLUCION.txt`. Los prompts de la bola extra están en `../../90_BOLA_EXTRA_AUDITORIA/`.

## 1. Pedir diagnóstico antes de corregir

El programa termina sin error y genera 17 CCAA y 425 registros. Sin embargo, `CONTROL_CARGA` muestra una comunidad con 25 preguntas detectadas pero 0 valores numéricamente válidos. Al abrir el Excel, los valores parecen números.

No modifiques todavía el programa. Indícame qué hipótesis comprobarías, qué comprobación mínima harías y qué evidencia necesitarías para identificar la causa.

## 2. Corregir números almacenados como texto

He comprobado que algunos recuentos están almacenados como texto aunque contienen valores numéricos. Modifica únicamente la lectura para aceptar enteros almacenados como texto, eliminando espacios normales o no separables. Los valores no convertibles deben registrarse como incidencia; no deben convertirse silenciosamente en cero.

## 3. Comparar con una referencia

Compara mi script y su archivo de salida con esta solución de referencia. Comprueba primero los requisitos funcionales: 17 comunidades, 425 filas, 25 preguntas por comunidad, conversión segura de números almacenados como texto, porcentajes recalculados y cuatro gráficas nacionales. Después explícame las diferencias relevantes y propón cambios mínimos. No sustituyas todo mi código por la referencia salvo que sea imprescindible.

## 4. Entender una solución por bloques

Explícame este programa por bloques funcionales, no línea por línea. Identifica: cómo encuentra encabezados; cómo normaliza estructuras; cómo convierte valores; cómo consolida; cómo calcula porcentajes; cómo genera gráficas; y qué controles realiza antes de guardar.
