#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bloque 2 · Reto 5 · Solución completa de referencia (04_RESUELTO)

Lectura robusta + conversión segura de enteros almacenados como texto + estadísticas + gráficas.
No modifica archivos originales.
"""
from __future__ import annotations

import argparse
import math
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.worksheet import Worksheet

RESPUESTAS = {"pregunta", "si", "no", "no procede"}


def norm(text: Any) -> str:
    s = "" if text is None else str(text)
    return s.strip().lower().replace("í", "i").replace("  ", " ")


def numero_pregunta(texto: Any) -> Optional[int]:
    if texto is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(texto))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def bloque_de_pregunta(n: int) -> str:
    if 1 <= n <= 5:
        return "Información necesaria en la oferta comercial"
    if 6 <= n <= 14:
        return "Información previa al contrato"
    if 15 <= n <= 25:
        return "Contratación, facturación y cláusulas abusivas"
    return ""


def comunidad_desde_hoja(ws: Worksheet) -> str:
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 5), values_only=True):
        for val in row:
            if isinstance(val, str) and "—" in val:
                return val.split("—")[-1].strip()
    return ws.title


def encontrar_cabecera(ws: Worksheet) -> Optional[Tuple[int, Dict[str, int]]]:
    for row in ws.iter_rows():
        cols: Dict[str, int] = {}
        for cell in row:
            n = norm(cell.value)
            if n in RESPUESTAS:
                cols[n] = cell.column
        if {"pregunta", "si", "no", "no procede"}.issubset(cols.keys()):
            return row[0].row, cols
    return None


def convertir_entero(valor: Any) -> Tuple[Optional[int], Optional[str]]:
    """Convierte enteros reales o almacenados como texto. No convierte desconocidos en cero."""
    if isinstance(valor, bool) or valor is None:
        return None, "valor vacío o booleano"
    if isinstance(valor, int):
        return valor, None
    if isinstance(valor, float) and valor.is_integer():
        return int(valor), None
    if isinstance(valor, str):
        limpio = valor.replace("\u00a0", " ").strip()
        if re.fullmatch(r"[+-]?\d+", limpio):
            return int(limpio), None
        return None, f"texto no convertible: {valor!r}"
    return None, f"tipo no convertible: {type(valor).__name__}"


def extraer_tabla(ws: Worksheet, archivo: Path) -> Tuple[List[dict], dict]:
    header = encontrar_cabecera(ws)
    comunidad = comunidad_desde_hoja(ws)
    if header is None:
        return [], {
            "comunidad_autonoma": comunidad,
            "archivo_origen": archivo.name,
            "hoja_origen": ws.title,
            "preguntas_detectadas": 0,
            "preguntas_numericas_validas": 0,
            "controles_realizados": None,
            "preguntas_suma_correcta": 0,
            "estado": "DESCARTADA",
            "observacion": "No se encontró cabecera Pregunta/Sí/No/No procede",
        }
    header_row, cols = header
    registros: List[dict] = []
    validas = 0
    suma_correcta = 0
    realizados_vals: List[int] = []
    incidencias: List[str] = []
    preguntas_detectadas = 0
    for r in range(header_row + 1, ws.max_row + 1):
        pregunta = ws.cell(r, cols["pregunta"]).value
        n = numero_pregunta(pregunta)
        if n is None:
            continue
        preguntas_detectadas += 1
        crudos = {
            "si": ws.cell(r, cols["si"]).value,
            "no": ws.cell(r, cols["no"]).value,
            "no_procede": ws.cell(r, cols["no procede"]).value,
        }
        convertidos = {}
        errores = []
        for k, v in crudos.items():
            conv, err = convertir_entero(v)
            convertidos[k] = conv
            if err:
                errores.append(f"P{n} {k}: {err}")
        numeric_ok = not errores and all(v is not None for v in convertidos.values())
        total = None
        if numeric_ok:
            validas += 1
            total = int(convertidos["si"]) + int(convertidos["no"]) + int(convertidos["no_procede"])
            realizados_vals.append(total)
        else:
            incidencias.extend(errores)
        registros.append({
            "comunidad_autonoma": comunidad,
            "numero_pregunta": n,
            "bloque": bloque_de_pregunta(n),
            "pregunta": str(pregunta),
            "si": convertidos["si"],
            "no": convertidos["no"],
            "no_procede": convertidos["no_procede"],
            "realizados": total,
            "archivo_origen": archivo.name,
            "hoja_origen": ws.title,
            "valores_numericos_validos": numeric_ok,
        })
    controles_realizados = max(set(realizados_vals), key=realizados_vals.count) if realizados_vals else None
    # Coherencia: cada pregunta debe sumar los controles realizados por la CCAA (el valor más frecuente).
    suma_correcta = sum(1 for t in realizados_vals if t == controles_realizados)
    estado = "OK" if preguntas_detectadas == 25 and validas == 25 and suma_correcta == 25 else "REVISAR"
    observacion = "; ".join(incidencias[:3])
    if len(incidencias) > 3:
        observacion += f"; ... ({len(incidencias)} incidencias)"
    return registros, {
        "comunidad_autonoma": comunidad,
        "archivo_origen": archivo.name,
        "hoja_origen": ws.title,
        "preguntas_detectadas": preguntas_detectadas,
        "preguntas_numericas_validas": validas,
        "controles_realizados": controles_realizados,
        "preguntas_suma_correcta": suma_correcta,
        "estado": estado,
        "observacion": observacion,
    }


def libros_de_entrada(base_12: Path, pendientes: Path) -> List[Path]:
    return [base_12] + sorted(pendientes.glob("*.xlsx"))


def consolidar(base_12: Path, pendientes: Path, salida: Path, ampliar=None) -> None:
    registros: List[dict] = []
    controles: List[dict] = []
    descartadas: List[dict] = []
    for libro in libros_de_entrada(base_12, pendientes):
        wb = load_workbook(libro, data_only=True)
        for ws in wb.worksheets:
            regs, ctrl = extraer_tabla(ws, libro)
            if regs:
                registros.extend(regs)
                controles.append(ctrl)
            else:
                descartadas.append(ctrl)
    crear_excel(salida, registros, controles, descartadas, ampliar)
    print("Proceso completado.")
    print(f"Comunidades detectadas: {len(controles)}")
    print(f"Registros consolidados: {len(registros)}")
    print(f"Registros numéricamente válidos: {sum(1 for r in registros if r['valores_numericos_validos'])}")
    print(f"Comunidades con incidencias: {sum(1 for c in controles if c['estado'] != 'OK')}")
    print(f"Archivo creado: {salida}")


def porcentaje(x: int, total: int) -> float:
    return x / total if total else 0.0


def crear_excel(salida: Path, registros: List[dict], controles: List[dict], descartadas: List[dict], ampliar=None) -> None:
    wb = Workbook()
    instr = wb.active
    instr.title = "INSTRUCCIONES"
    instr.append(["Bloque 2 · Solución completa de referencia"])
    instr.append(["Genera consolidado, estadísticas, nacional, control y cuatro gráficas."])
    instr.append(["La conversión de textos numéricos es segura: los no convertibles se registran como incidencia y no se sustituyen por cero."])

    headers = ["comunidad_autonoma", "numero_pregunta", "bloque", "pregunta", "si", "no", "no_procede", "realizados", "archivo_origen", "hoja_origen", "valores_numericos_validos"]
    ws = wb.create_sheet("DATOS_CONSOLIDADOS")
    ws.append(headers)
    for r in sorted(registros, key=lambda x: (x["comunidad_autonoma"], x["numero_pregunta"])):
        ws.append([r[h] for h in headers])

    est = wb.create_sheet("ESTADISTICAS_CCAA")
    est_headers = ["comunidad_autonoma", "numero_pregunta", "bloque", "pregunta", "si", "no", "no_procede", "realizados", "% si", "% no", "% no procede", "archivo_origen", "hoja_origen"]
    est.append(est_headers)
    for r in sorted(registros, key=lambda x: (x["comunidad_autonoma"], x["numero_pregunta"])):
        total = r["realizados"] or 0
        est.append([r["comunidad_autonoma"], r["numero_pregunta"], r["bloque"], r["pregunta"], r["si"], r["no"], r["no_procede"], total, porcentaje(r["si"] or 0, total), porcentaje(r["no"] or 0, total), porcentaje(r["no_procede"] or 0, total), r["archivo_origen"], r["hoja_origen"]])

    nacional = wb.create_sheet("NACIONAL")
    nacional.append(["NACIONAL POR PREGUNTA"])
    nacional.append(["numero_pregunta", "bloque", "pregunta", "si", "no", "no_procede", "realizados", "% si", "% no", "% no procede"])
    por_preg: Dict[int, dict] = {}
    for r in registros:
        n = r["numero_pregunta"]
        if n not in por_preg:
            por_preg[n] = {"bloque": r["bloque"], "pregunta": r["pregunta"], "si": 0, "no": 0, "no_procede": 0, "realizados": 0}
        por_preg[n]["si"] += r["si"] or 0
        por_preg[n]["no"] += r["no"] or 0
        por_preg[n]["no_procede"] += r["no_procede"] or 0
        por_preg[n]["realizados"] += r["realizados"] or 0
    for n in range(1, 26):
        p = por_preg[n]
        total = p["realizados"]
        nacional.append([n, p["bloque"], p["pregunta"], p["si"], p["no"], p["no_procede"], total, porcentaje(p["si"], total), porcentaje(p["no"], total), porcentaje(p["no_procede"], total)])
    resumen_start = nacional.max_row + 3
    nacional.cell(resumen_start, 1, "RESUMEN POR BLOQUE")
    nacional.append(["bloque", "si", "no", "no_procede", "realizados", "% si", "% no", "% no procede"])
    by_bloque: Dict[str, dict] = {}
    for r in registros:
        b = r["bloque"]
        by_bloque.setdefault(b, {"si": 0, "no": 0, "no_procede": 0, "realizados": 0})
        by_bloque[b]["si"] += r["si"] or 0
        by_bloque[b]["no"] += r["no"] or 0
        by_bloque[b]["no_procede"] += r["no_procede"] or 0
        by_bloque[b]["realizados"] += r["realizados"] or 0
    for b in ["Información necesaria en la oferta comercial", "Información previa al contrato", "Contratación, facturación y cláusulas abusivas"]:
        d = by_bloque[b]
        total = d["realizados"]
        nacional.append([b, d["si"], d["no"], d["no_procede"], total, porcentaje(d["si"], total), porcentaje(d["no"], total), porcentaje(d["no_procede"], total)])

    ctrl = wb.create_sheet("CONTROL_CARGA")
    ctrl_headers = ["comunidad_autonoma", "archivo_origen", "hoja_origen", "preguntas_detectadas", "preguntas_numericas_validas", "controles_realizados", "preguntas_suma_correcta", "estado", "observacion"]
    ctrl.append(ctrl_headers)
    for c in sorted(controles, key=lambda x: x["comunidad_autonoma"]):
        ctrl.append([c.get(h) for h in ctrl_headers])
    desc = wb.create_sheet("HOJAS_DESCARTADAS")
    desc.append(ctrl_headers)
    for c in descartadas:
        desc.append([c.get(h) for h in ctrl_headers])

    aplicar_formato(wb)
    crear_graficas(nacional, resumen_start)
    if ampliar is not None:  # gancho opcional (lo usa 90_BOLA_EXTRA_AUDITORIA/02_CONTROLES_INTEGRADOS/solucion_controles_reforzados.py)
        ampliar(wb, registros, controles)
    salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(salida)


def crear_graficas(ws, resumen_start: int) -> None:
    """Crea cuatro tablas auxiliares y cuatro gráficas nacionales."""
    # Tabla auxiliar 1: resumen por bloques.
    aux_col = 12  # L
    ws.cell(1, aux_col, "DATOS_GRAFICA_BLOQUES")
    ws.cell(2, aux_col, "bloque")
    ws.cell(2, aux_col + 1, "% si")
    ws.cell(2, aux_col + 2, "% no")
    ws.cell(2, aux_col + 3, "% no procede")
    for i in range(3):
        src_row = resumen_start + 2 + i
        dst_row = 3 + i
        ws.cell(dst_row, aux_col, ws.cell(src_row, 1).value)
        ws.cell(dst_row, aux_col + 1, ws.cell(src_row, 6).value)
        ws.cell(dst_row, aux_col + 2, ws.cell(src_row, 7).value)
        ws.cell(dst_row, aux_col + 3, ws.cell(src_row, 8).value)
    chart = BarChart()
    chart.type = "bar"
    chart.title = "Resultados por tipo de requisitos"
    chart.y_axis.title = "Bloque"
    chart.x_axis.title = "Porcentaje"
    data = Reference(ws, min_col=aux_col + 1, max_col=aux_col + 3, min_row=2, max_row=5)
    cats = Reference(ws, min_col=aux_col, min_row=3, max_row=5)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 7
    chart.width = 15
    ws.add_chart(chart, "Q2")

    # Detalles por bloques: una tabla auxiliar limpia por cada bloque.
    blocks = [
        (1, 5, "Información en la oferta comercial", 18, "Q18"),
        (6, 14, "Información previa al contrato", 34, "Q34"),
        (15, 25, "Contratación, facturación y cláusulas abusivas", 54, "Q54"),
    ]
    for q_min, q_max, title, table_row, anchor in blocks:
        ws.cell(table_row, aux_col, f"DATOS_GRAFICA_{q_min}_{q_max}")
        ws.cell(table_row + 1, aux_col, "pregunta")
        ws.cell(table_row + 1, aux_col + 1, "% si")
        ws.cell(table_row + 1, aux_col + 2, "% no")
        ws.cell(table_row + 1, aux_col + 3, "% no procede")
        out_row = table_row + 2
        for q in range(q_min, q_max + 1):
            src_row = 2 + q  # tabla nacional empieza en fila 3 para pregunta 1
            ws.cell(out_row, aux_col, q)
            ws.cell(out_row, aux_col + 1, ws.cell(src_row, 8).value)
            ws.cell(out_row, aux_col + 2, ws.cell(src_row, 9).value)
            ws.cell(out_row, aux_col + 3, ws.cell(src_row, 10).value)
            out_row += 1
        ch = BarChart()
        ch.type = "bar"
        ch.title = title
        ch.y_axis.title = "Pregunta"
        ch.x_axis.title = "Porcentaje"
        data = Reference(ws, min_col=aux_col + 1, max_col=aux_col + 3, min_row=table_row + 1, max_row=out_row - 1)
        cats = Reference(ws, min_col=aux_col, min_row=table_row + 2, max_row=out_row - 1)
        ch.add_data(data, titles_from_data=True)
        ch.set_categories(cats)
        ch.height = 7
        ch.width = 15
        ws.add_chart(ch, anchor)

def aplicar_formato(wb: Workbook) -> None:
    fill = PatternFill("solid", fgColor="D9EAF7")
    title_fill = PatternFill("solid", fgColor="E2F0D9")
    thin = Side(style="thin", color="BFBFBF")
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin)
                if isinstance(cell.value, float) and 0 <= cell.value <= 1:
                    cell.number_format = "0.0%"
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = fill
        if ws.title == "NACIONAL":
            ws[1][0].font = Font(bold=True, size=14)
            ws[1][0].fill = title_fill
        for col in ws.columns:
            letter = col[0].column_letter
            max_len = min(max(len(str(c.value)) if c.value is not None else 0 for c in col) + 2, 55)
            ws.column_dimensions[letter].width = max(10, max_len)


def main() -> None:
    reto = Path(__file__).resolve().parents[1]  # 05_RETO_CAMPANA_ESTATAL
    entradas = reto / "01_ENTRADAS"
    parser = argparse.ArgumentParser(description="Genera la solución completa del Reto 5 (campaña estatal).")
    parser.add_argument("--base-12", type=Path, default=entradas / "BASE_12_CCAA.xlsx")
    parser.add_argument("--pendientes", type=Path, default=entradas / "CCAA_PENDIENTES")
    parser.add_argument("--salida", type=Path, default=reto / "03_TRABAJO" / "SALIDAS" / "SOLUCION_COMPLETA_17_CCAA.xlsx")
    args = parser.parse_args()
    consolidar(args.base_12, args.pendientes, args.salida)


if __name__ == "__main__":
    main()
