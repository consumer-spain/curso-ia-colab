# Cinco preguntas antes de confiar

Un único «OK» no demuestra que el resultado sea correcto. Cada control responde a una pregunta distinta, y todas las hemos vivido ya en el bloque:

1. **Cobertura** — ¿Está todo? Ej.: 17 CCAA · 425 registros · 25 preguntas por CCAA.
2. **Tipo / interpretación** — ¿He entendido correctamente cada dato? Ej.: `12` (número) frente a `'12'` (texto).
3. **Coherencia** — ¿Se cumplen las relaciones internas? Ej.: `Sí + No + No procede = controles realizados`.
4. **Reconciliación** — ¿Coincide con un control independiente? Ej.: 49 controles en el caso de 2 CCAA; 351 por pregunta en la campaña estatal de este ejercicio.
5. **Lógica** — ¿Estoy calculando realmente lo que quería calcular? Ej.: 52,5 % (promediar porcentajes) frente a 36 % (sumar recuentos y calcular después).

Las preguntas son complementarias: superar una no sustituye a las demás.

## Un control responde a la pregunta para la que fue diseñado

- `CONTROL_NORMALIZACION` (Reto 4) responde a: **¿la transformación estructural ha conservado los datos?** Para Comunitat Valenciana dio OK, y era correcto: la normalización no alteró nada.
- `CONTROL_CARGA` (Reto 5) responde a: **¿qué ha leído la herramienta estatal y qué ha podido interpretar y utilizar?** Ahí apareció Comunitat Valenciana con 25 preguntas detectadas y 0 valores válidos: un problema de tipo / interpretación.

Son dos controles distintos para dos preguntas distintas; ninguno es requisito del otro.

## ¿Y si automatizamos también la revisión?

Es la **bola extra** del bloque (`../90_BOLA_EXTRA_AUDITORIA/`): un auditor independiente que convierte estas cinco preguntas en comprobaciones automáticas, y controles integrados en la propia herramienta. Es opcional.
