# Bola extra · repetir el cambio controlado sobre la herramienta completa

Opcional. Repite, sobre la herramienta completa del Reto 5, la técnica de cambio controlado aprendida en el Reto 3 con el caso pequeño de Madrid + Castilla y León.

`ARAGON_CORREGIDO.xlsx` cambia únicamente la pregunta 1:

- antes: Sí 8 · No 10 · No procede 0;
- después: Sí 9 · No 9 · No procede 0;
- total: 18 → 18.

Antes de ejecutar, predice qué debe cambiar y qué debe permanecer igual. Trabaja sobre una copia de `../../05_RETO_CAMPANA_ESTATAL/01_ENTRADAS/CCAA_PENDIENTES/` en la que sustituyas `ARAGON.xlsx` por este archivo (con el mismo nombre `ARAGON.xlsx`), ejecuta tu herramienta o `solucion_completa.py --pendientes <tu_copia>` y compara con tu predicción.

Si aparecen a la vez `ARAGON.xlsx` y `ARAGON_CORREGIDO.xlsx`, una herramienta robusta debería señalar la ambigüedad en vez de elegir o sumar silenciosamente ambos.
