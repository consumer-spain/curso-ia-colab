#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bloque 2 · Bola extra · Solución con CONTROLES INTEGRADOS (referencia de PROMPT_CONTROLES_INTEGRADOS.txt)

Reutiliza la solución del Reto 5 (05_RETO_CAMPANA_ESTATAL/04_RESUELTO/solucion_completa.py) SIN cambiar sus reglas de cálculo y amplía los controles:

- CONTROL_CARGA ampliado: preguntas esperadas/detectadas/repetidas, valores válidos,
  valores convertidos desde texto, incidencias de conversión y coherencia de totales.
- COMPROBACIONES: las cinco capas (cobertura, tipo, coherencia, reconciliación, lógica)
  con valor esperado, valor obtenido y resultado. Si una comprobación no puede hacerse,
  se indica expresamente («NO EVALUABLE»). Nunca se convierte lo desconocido en cero.

No modifica los archivos originales.
"""
from __future__ import annotations

import argparse
import importlib.util
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

AQUI = Path(__file__).resolve().parent
RETO5 = AQUI.parents[1] / "05_RETO_CAMPANA_ESTATAL"  # fuente canónica de la solución: no se duplica
_spec = importlib.util.spec_from_file_location("solucion_completa", RETO5 / "04_RESUELTO" / "solucion_completa.py")
base = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(base)  # type: ignore[union-attr]

PREGUNTAS_ESPERADAS = 25
COLUMNAS = ("si", "no", "no procede")


def tipo_crudo(v: Any) -> str:
    if v is None:
        return "vacio"
    if isinstance(v, bool):
        return "otro"
    if isinstance(v, (int, float)):
        return "numero"
    if isinstance(v, str) and re.fullmatch(r"[+-]?\d+", v.replace(" ", " ").strip()):
        return "texto_numerico"
    return "texto_no_numerico"


def revisar_origen(archivo: Path, hoja: str) -> dict:
    """Vuelve a leer la tabla de origen y clasifica los valores tal como están almacenados."""
    ws = load_workbook(archivo, data_only=True)[hoja]
    fila, cols = base.encontrar_cabecera(ws)
    tipos: Counter = Counter()
    numeros: list[int] = []
    for r in range(fila + 1, ws.max_row + 1):
        n = base.numero_pregunta(ws.cell(r, cols["pregunta"]).value)
        if n is None:
            continue
        numeros.append(n)
        for k in COLUMNAS:
            tipos[tipo_crudo(ws.cell(r, cols[k]).value)] += 1
    return {"tipos": tipos, "repetidas": sum(c - 1 for c in Counter(numeros).values() if c > 1)}


def ampliar_controles(wb, registros: list[dict], controles: list[dict], rutas: dict[str, Path], ccaa_esperadas: int, total_esperado: int) -> None:
    # ---------------- CONTROL_CARGA ampliado
    idx = wb.sheetnames.index("CONTROL_CARGA")
    del wb["CONTROL_CARGA"]
    ws = wb.create_sheet("CONTROL_CARGA", idx)
    cab = ["comunidad_autonoma", "archivo_origen", "hoja_origen", "preguntas_esperadas", "preguntas_detectadas",
           "preguntas_repetidas", "valores_esperados", "valores_numericos_validos", "convertidos_desde_texto",
           "incidencias_conversion", "controles_realizados", "preguntas_con_total_distinto", "estado", "observacion"]
    ws.append(cab)
    por_ccaa = defaultdict(list)
    for r in registros:
        por_ccaa[r["comunidad_autonoma"]].append(r)
    for c in sorted(controles, key=lambda x: x["comunidad_autonoma"]):
        regs = por_ccaa[c["comunidad_autonoma"]]
        origen = revisar_origen(rutas[c["archivo_origen"]], c["hoja_origen"])
        validos = sum(1 for r in regs for k in ("si", "no", "no_procede") if isinstance(r[k], int))
        incid = sum(1 for r in regs for k in ("si", "no", "no_procede") if r[k] is None)
        cr = c["controles_realizados"]
        distinto = sum(1 for r in regs if r["realizados"] is not None and r["realizados"] != cr)
        no_eval = sum(1 for r in regs if r["realizados"] is None)
        problemas = []
        if c["preguntas_detectadas"] != PREGUNTAS_ESPERADAS:
            problemas.append(f"preguntas detectadas {c['preguntas_detectadas']} de {PREGUNTAS_ESPERADAS}")
        if origen["repetidas"]:
            problemas.append(f"{origen['repetidas']} preguntas repetidas")
        if incid:
            problemas.append(f"{incid} valores no convertibles (registrados, no sustituidos por 0)")
        if distinto:
            problemas.append(f"{distinto} preguntas no suman {cr}")
        if no_eval:
            problemas.append(f"coherencia NO EVALUABLE en {no_eval} preguntas")
        obs = "; ".join(problemas)
        if origen["tipos"]["texto_numerico"]:
            obs = (obs + "; " if obs else "") + f"{origen['tipos']['texto_numerico']} valores leídos como texto numérico y convertidos"
        ws.append([c["comunidad_autonoma"], c["archivo_origen"], c["hoja_origen"], PREGUNTAS_ESPERADAS,
                   c["preguntas_detectadas"], origen["repetidas"], PREGUNTAS_ESPERADAS * 3, validos,
                   origen["tipos"]["texto_numerico"], incid, cr, distinto, "REVISAR" if problemas else "OK", obs])

    # ---------------- COMPROBACIONES · cinco capas
    ch = wb.create_sheet("COMPROBACIONES", idx + 1)
    ch.append(["capa", "comprobacion", "esperado", "obtenido", "resultado"])
    filas = []
    n_ccaa = len(por_ccaa)
    filas.append(["1 · cobertura", "CCAA encontradas", ccaa_esperadas, n_ccaa, n_ccaa == ccaa_esperadas])
    filas.append(["1 · cobertura", "registros comunidad-pregunta", ccaa_esperadas * PREGUNTAS_ESPERADAS, len(registros), len(registros) == ccaa_esperadas * PREGUNTAS_ESPERADAS])
    malas = [k for k, v in por_ccaa.items() if sorted(r["numero_pregunta"] for r in v) != list(range(1, 26))]
    filas.append(["1 · cobertura", "CCAA con preguntas 1–25 una sola vez", n_ccaa, n_ccaa - len(malas), not malas])
    total_vals = len(registros) * 3
    validos = sum(1 for r in registros for k in ("si", "no", "no_procede") if isinstance(r[k], int))
    filas.append(["2 · tipo", "valores numéricamente válidos", total_vals, validos, validos == total_vals])
    incid = total_vals - validos
    filas.append(["2 · tipo", "incidencias de conversión (no sustituidas por 0)", 0, incid, incid == 0])
    no_eval = [r for r in registros if r["realizados"] is None]
    cr = {c["comunidad_autonoma"]: c["controles_realizados"] for c in controles}
    incoh = sum(1 for r in registros if r["realizados"] is not None and r["realizados"] != cr[r["comunidad_autonoma"]])
    filas.append(["3 · coherencia", "preguntas cuyo Sí + No + No procede ≠ controles de su CCAA", 0,
                  incoh if not no_eval else f"{incoh} (+{len(no_eval)} NO EVALUABLES)", incoh == 0 and not no_eval])
    tot = defaultdict(int)
    for r in registros:
        if r["realizados"] is not None:
            tot[r["numero_pregunta"]] += r["realizados"]
    distintas = [n for n in range(1, 26) if tot.get(n) != total_esperado]
    filas.append(["4 · reconciliación", f"preguntas cuyo total nacional ≠ control independiente ({total_esperado})", 0,
                  len(distintas) if not no_eval else f"{len(distintas)} · NO EVALUABLE con datos incompletos", not distintas and not no_eval])
    # lógica: porcentajes de NACIONAL frente a recálculo sobre la suma de recuentos
    nac = wb["NACIONAL"]
    hdr: dict = {}
    for c in range(1, nac.max_column + 1):  # primera aparición: a la derecha hay tablas auxiliares de gráficas
        hdr.setdefault(nac.cell(2, c).value, c)
    sumas = defaultdict(lambda: [0, 0, 0, 0])
    for r in registros:
        if r["realizados"] is not None:
            s = sumas[r["numero_pregunta"]]
            s[0] += r["si"]; s[1] += r["no"]; s[2] += r["no_procede"]; s[3] += r["realizados"]
    discrepancias = 0
    for fila in range(3, 28):
        n = nac.cell(fila, hdr["numero_pregunta"]).value
        si, no, np_, t = sumas[n]
        for col, num in (("% si", si), ("% no", no), ("% no procede", np_)):
            v = nac.cell(fila, hdr[col]).value
            if t == 0 or not isinstance(v, (int, float)) or abs(v - num / t) > 1e-9:
                discrepancias += 1
    filas.append(["5 · lógica", "% nacionales distintos del recálculo sobre la suma de recuentos (no promedio de %)", 0,
                  discrepancias if not no_eval else f"{discrepancias} · NO EVALUABLE con datos incompletos", discrepancias == 0 and not no_eval])
    for f in filas:
        ch.append(f[:4] + ["OK" if f[4] else "REVISAR"])

    fill = PatternFill("solid", fgColor="D9EAF7")
    for hoja in (ws, ch):
        for cell in hoja[1]:
            cell.font = Font(bold=True)
            cell.fill = fill
        for col in hoja.columns:
            hoja.column_dimensions[col[0].column_letter].width = min(max(len(str(c.value or "")) for c in col) + 2, 60)


def main() -> None:
    entradas = RETO5 / "01_ENTRADAS"
    parser = argparse.ArgumentParser(description="Solución completa con controles integrados (bola extra).")
    parser.add_argument("--base-12", type=Path, default=entradas / "BASE_12_CCAA.xlsx")
    parser.add_argument("--pendientes", type=Path, default=entradas / "CCAA_PENDIENTES")
    parser.add_argument("--salida", type=Path, default=AQUI.parent / "SALIDAS" / "SOLUCION_CONTROLES_REFORZADOS.xlsx")
    parser.add_argument("--ccaa-esperadas", type=int, default=17)
    parser.add_argument("--total-esperado", type=int, default=351, help="Control independiente: total nacional por pregunta")
    args = parser.parse_args()
    rutas = {p.name: p for p in base.libros_de_entrada(args.base_12, args.pendientes)}
    base.consolidar(args.base_12, args.pendientes, args.salida,
                    ampliar=lambda wb, regs, ctrls: ampliar_controles(wb, regs, ctrls, rutas, args.ccaa_esperadas, args.total_esperado))
    wb = load_workbook(args.salida, data_only=True)
    print("COMPROBACIONES")
    for row in wb["COMPROBACIONES"].iter_rows(min_row=2, values_only=True):
        print(f"  {row[4]:8} {row[0]} · {row[1]}: esperado {row[2]} · obtenido {row[3]}")


if __name__ == "__main__":
    main()
