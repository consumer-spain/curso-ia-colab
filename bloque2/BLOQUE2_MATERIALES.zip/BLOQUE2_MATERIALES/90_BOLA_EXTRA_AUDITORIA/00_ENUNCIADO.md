# Bola extra · ¿Podemos automatizar también la revisión?

**Opcional.** El bloque termina con el Reto 5 resuelto y las cinco preguntas antes de confiar. Esta carpeta es un segundo nivel para quien quiera ir más allá; puede omitirse por completo.

## 1 · Auditor independiente (`01_AUDITOR/`)

Las cinco preguntas antes de confiar se convierten en requisitos de un **segundo programa** que recibe el Excel generado por la herramienta y lo revisa sin modificarlo: cobertura, tipo / interpretación, coherencia, reconciliación y lógica. Informa OK / REVISAR / NO EVALUABLE por capa.

- `PROMPT_AUDITOR.txt` — el encargo para la IA;
- `auditar_salida.py` — referencia;
- `AUDITORIA_REFERENCIA.txt` — resultado sobre la solución del Reto 5: las cinco capas OK.

```bash
python 01_AUDITOR/auditar_salida.py                              # audita ../05_RETO_CAMPANA_ESTATAL/04_RESUELTO/SOLUCION_REFERENCIA.xlsx
python 01_AUDITOR/auditar_salida.py --entrada <tu_salida.xlsx>   # audita tu propia salida
```

Escribe `SALIDAS/AUDITORIA_SALIDA.txt`.

**Un auditor útil también debe saber decir REVISAR.** En `01_AUDITOR/EJEMPLOS/`:

- `INFORME_A_PROMEDIO.xlsx` — la misma solución, pero con los porcentajes nacionales calculados como promedio simple de los porcentajes autonómicos;
- `AUDITORIA_INFORME_A.txt` — el auditor da OK en las capas 1–4 y **LÓGICA = REVISAR**;
- `P15_INFORME_A_Y_B.md` — el caso de la pregunta 15 (44,7 % promediando frente a 43,9 % sumando recuentos): la misma regla que el 52,5 % frente a 36 % del Reto 3.

## 2 · Controles integrados (`02_CONTROLES_INTEGRADOS/`)

La propia herramienta deja constancia de qué ha comprobado mientras trabaja: `CONTROL_CARGA` ampliado y una hoja `COMPROBACIONES` con las cinco capas. Es complementario del auditor, no lo sustituye.

- `PROMPT_CONTROLES_INTEGRADOS.txt`;
- `solucion_controles_reforzados.py` — reutiliza `../05_RETO_CAMPANA_ESTATAL/04_RESUELTO/solucion_completa.py` sin cambiar sus reglas de cálculo (escribe `SALIDAS/SOLUCION_CONTROLES_REFORZADOS.xlsx`);
- `SOLUCION_CONTROLES_REFORZADOS_REFERENCIA.xlsx` — 8 comprobaciones de las cinco capas, todas OK.

## 3 · Cambio controlado sobre la herramienta completa (`03_CAMBIO_CONTROLADO_ARAGON/`)

Repite la técnica de cambio controlado del Reto 3 con `ARAGON_CORREGIDO.xlsx` sobre la herramienta completa. Enunciado en esa carpeta.
