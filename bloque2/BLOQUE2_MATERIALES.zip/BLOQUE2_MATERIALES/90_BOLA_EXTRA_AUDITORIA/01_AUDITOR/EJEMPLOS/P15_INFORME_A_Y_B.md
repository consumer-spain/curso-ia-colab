# Ejemplo · pregunta 15 · informe A frente a informe B

Dos informes tienen 17 CCAA, 425 registros, 425 válidos y 351 controles en la pregunta 15, con los mismos recuentos: Sí 154 · No 23 · No procede 174. Los dos pasan cobertura, tipo, coherencia y reconciliación.

| | Sí | No | No procede | Cómo se calcula |
|---|---|---|---|---|
| **Informe A** (`INFORME_A_PROMEDIO.xlsx`) | 44,7 % | 6,2 % | 49,1 % | promedio simple de los 17 porcentajes autonómicos ✗ |
| **Informe B** (`SOLUCION_REFERENCIA.xlsx`) | 43,9 % | 6,6 % | 49,6 % | suma de recuentos y después porcentaje: 154 / 351 ✓ |

El informe A da el mismo peso a una comunidad con 12 controles en esa pregunta que a una con 34. Es la misma regla que el 52,5 % frente a 36 % del Reto 3, ahora en la herramienta real.

`auditar_salida.py` lo detecta en la capa 5 (LÓGICA): ver `AUDITORIA_INFORME_A.txt`.
