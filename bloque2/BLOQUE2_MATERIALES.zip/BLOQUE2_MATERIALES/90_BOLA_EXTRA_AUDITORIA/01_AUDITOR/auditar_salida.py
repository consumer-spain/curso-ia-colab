#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bola extra · Auditor independiente de la salida del Reto 5 (cinco capas).

Es un SEGUNDO programa: recibe el Excel generado por la herramienta y lo revisa
sin modificarlo. Para cada capa emite OK / REVISAR / NO EVALUABLE.

1 COBERTURA ............ 17 CCAA, 25 preguntas por comunidad, 425 registros.
2 TIPO / INTERPRETACIÓN  recuentos y totales numéricos; señala los no interpretables.
3 COHERENCIA ........... Sí + No + No procede = realizados.
4 RECONCILIACIÓN ....... 25 preguntas nacionales; total por pregunta = control independiente.
5 LÓGICA ............... recalcula los porcentajes nacionales sobre la suma de recuentos
                         y los compara con los publicados; no acepta un promedio simple
                         de porcentajes autonómicos.
"""
from __future__ import annotations

import argparse
import hashlib
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

OK, REV, NE = "OK", "REVISAR", "NO EVALUABLE"
CAMPOS = ("si", "no", "no_procede", "realizados")
TOL = 1e-6


def es_numero(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def cabecera(ws, clave: str):
    """Fila de cabecera que contiene `clave` (primera aparición de cada nombre)."""
    for row in ws.iter_rows():
        vals = [c.value for c in row]
        if clave in vals:
            m = {}
            for c in row:
                if c.value is not None and c.value not in m:
                    m[c.value] = c.column
            return row[0].row, m
    return None, {}


def leer_datos(wb):
    if "DATOS_CONSOLIDADOS" not in wb.sheetnames:
        return None
    ws = wb["DATOS_CONSOLIDADOS"]
    h, m = cabecera(ws, "comunidad_autonoma")
    if h is None or any(k not in m for k in ("comunidad_autonoma", "numero_pregunta") + CAMPOS):
        return None
    filas = []
    for r in range(h + 1, ws.max_row + 1):
        ca = ws.cell(r, m["comunidad_autonoma"]).value
        if ca is None:
            continue
        d = {"comunidad_autonoma": ca, "numero_pregunta": ws.cell(r, m["numero_pregunta"]).value}
        d.update({k: ws.cell(r, m[k]).value for k in CAMPOS})
        filas.append(d)
    return filas


def leer_nacional(wb):
    if "NACIONAL" not in wb.sheetnames:
        return None
    ws = wb["NACIONAL"]
    h, m = cabecera(ws, "numero_pregunta")
    need = ("numero_pregunta",) + CAMPOS + ("% si", "% no", "% no procede")
    if h is None or any(k not in m for k in need):
        return None
    out = {}
    for r in range(h + 1, ws.max_row + 1):
        n = ws.cell(r, m["numero_pregunta"]).value
        if not es_numero(n) or not 1 <= int(n) <= 25:
            continue
        out[int(n)] = {k: ws.cell(r, m[k]).value for k in need[1:]}
    return out


def auditar(path: Path, total_esperado: int):
    huella_antes = hashlib.sha256(path.read_bytes()).hexdigest()
    wb = load_workbook(path, data_only=True)
    filas = leer_datos(wb)
    nac = leer_nacional(wb)
    res = {}

    # 1 COBERTURA
    if filas is None:
        res[1] = (NE, "no hay DATOS_CONSOLIDADOS con las columnas esperadas")
    else:
        cuenta = Counter(f["comunidad_autonoma"] for f in filas)
        pregs = defaultdict(set)
        for f in filas:
            pregs[f["comunidad_autonoma"]].add(f["numero_pregunta"])
        ok = len(cuenta) == 17 and len(filas) == 425 and all(cuenta[c] == 25 and pregs[c] == set(range(1, 26)) for c in cuenta)
        res[1] = (OK if ok else REV, f"{len(cuenta)} CCAA · {len(filas)} registros · 25 por CCAA={all(v == 25 for v in cuenta.values())}")

    # 2 TIPO / INTERPRETACIÓN
    malos = []
    if filas is not None:
        for f in filas:
            for k in CAMPOS:
                if not es_numero(f[k]):
                    malos.append((f["comunidad_autonoma"], f["numero_pregunta"], k, f[k]))
    if nac is not None:
        for n, d in nac.items():
            for k, v in d.items():
                if not es_numero(v):
                    malos.append(("NACIONAL", n, k, v))
    if filas is None and nac is None:
        res[2] = (NE, "no hay datos que revisar")
    elif not malos:
        res[2] = (OK, "recuentos y totales numéricos")
    else:
        por_ca = Counter(m[0] for m in malos)
        clases = Counter("texto" if isinstance(m[3], str) else ("vacío" if m[3] is None else "otro") for m in malos)
        ej = next((m for m in malos if isinstance(m[3], str)), malos[0])
        res[2] = (REV, f"{len(malos)} valores no interpretables en {', '.join(por_ca)} ({', '.join(f'{n} {c}' for c, n in clases.items())}) · ej. P{ej[1]} {ej[2]}={ej[3]!r}")

    # 3 COHERENCIA
    if filas is None:
        res[3] = (NE, "sin datos")
    else:
        evaluables = [f for f in filas if all(es_numero(f[k]) for k in CAMPOS)]
        fallos = [f for f in evaluables if f["realizados"] != f["si"] + f["no"] + f["no_procede"]]
        no_eval = len(filas) - len(evaluables)
        if fallos:
            res[3] = (REV, f"{len(fallos)} filas con Sí+No+NP ≠ realizados")
        elif no_eval:
            res[3] = (NE, f"{no_eval} filas no evaluables (valores no numéricos)")
        else:
            res[3] = (OK, "Sí+No+NP=realizados")

    # sumas por pregunta a partir de los recuentos (solo si todo es numérico)
    sumas = None
    if filas is not None and all(es_numero(f[k]) for f in filas for k in CAMPOS):
        sumas = defaultdict(lambda: dict.fromkeys(CAMPOS, 0))
        for f in filas:
            for k in CAMPOS:
                sumas[int(f["numero_pregunta"])][k] += f[k]

    # 4 RECONCILIACIÓN
    if nac is None:
        res[4] = (NE, "no hay hoja NACIONAL con las columnas esperadas")
    else:
        totales = [nac[n]["realizados"] for n in sorted(nac)]
        ok = set(nac) == set(range(1, 26)) and all(t == total_esperado for t in totales)
        if sumas is not None:
            ok = ok and all(sumas[n]["realizados"] == total_esperado for n in range(1, 26))
        distintos = sorted({t for t in totales if t != total_esperado}, key=str)
        res[4] = (OK if ok else REV, f"{len(nac)} preguntas · control independiente={total_esperado}" + (f" · encontrados {distintos}" if distintos else ""))

    # 5 LÓGICA
    if nac is None:
        res[5] = (NE, "no hay resultado nacional que recalcular")
    elif sumas is None:
        res[5] = (NE, "no se puede recalcular: hay recuentos no numéricos")
    else:
        dif, promedio = [], 0
        por_ca = defaultdict(dict)
        for f in filas:
            if f["realizados"]:
                por_ca[int(f["numero_pregunta"])][f["comunidad_autonoma"]] = (f["si"] / f["realizados"], f["no"] / f["realizados"], f["no_procede"] / f["realizados"])
        for n in range(1, 26):
            d, s = nac.get(n), sumas[n]
            if d is None or not all(es_numero(v) for v in d.values()):
                dif.append(n); continue
            t = s["realizados"]
            esperado = (s["si"] / t, s["no"] / t, s["no_procede"] / t)
            publicado = (d["% si"], d["% no"], d["% no procede"])
            if any(d[k] != s[k] for k in CAMPOS) or any(abs(a - b) > TOL for a, b in zip(publicado, esperado)):
                dif.append(n)
                vals = list(por_ca[n].values())
                media = tuple(sum(v[i] for v in vals) / len(vals) for i in range(3))
                if any(abs(a - b) > TOL for a, b in zip(esperado, media)) and all(abs(a - b) <= TOL for a, b in zip(publicado, media)):
                    promedio += 1
        if not dif:
            res[5] = (OK, "nacional coincide con recuentos y porcentajes recalculados")
        else:
            txt = f"{len(dif)} preguntas no coinciden con el recálculo sobre la suma de recuentos"
            if promedio:
                txt += f" · en {promedio} los % publicados son el promedio simple de % autonómicos"
            res[5] = (REV, txt)

    intacto = hashlib.sha256(path.read_bytes()).hexdigest() == huella_antes
    return res, intacto


def main() -> None:
    extra = Path(__file__).resolve().parents[1]  # 90_BOLA_EXTRA_AUDITORIA
    reto5 = extra.parent / "05_RETO_CAMPANA_ESTATAL"
    parser = argparse.ArgumentParser(description="Auditor independiente de la salida del Bloque 2 (cinco capas).")
    parser.add_argument("--entrada", type=Path, default=reto5 / "04_RESUELTO" / "SOLUCION_REFERENCIA.xlsx")
    parser.add_argument("--salida", type=Path, default=extra / "SALIDAS" / "AUDITORIA_SALIDA.txt")
    parser.add_argument("--total-esperado", type=int, default=351, help="Control independiente del ejercicio: total nacional por pregunta")
    args = parser.parse_args()

    res, intacto = auditar(args.entrada, args.total_esperado)
    nombres = {1: "COBERTURA", 2: "TIPO / INTERPRETACIÓN", 3: "COHERENCIA", 4: "RECONCILIACIÓN", 5: "LÓGICA"}
    lineas = [f"AUDITORÍA DE SALIDA · {args.entrada.name}", ""]
    lineas += [f"{i} {nombres[i]}: {res[i][0]} · {res[i][1]}" for i in range(1, 6)]
    lineas += ["", f"Archivo auditado sin modificar: {'SÍ' if intacto else 'NO'}", "Un OK en una capa no sustituye a las demás."]
    args.salida.parent.mkdir(parents=True, exist_ok=True)
    args.salida.write_text("\n".join(lineas), encoding="utf-8")
    print("\n".join(lineas))
    print(f"Informe: {args.salida}")
    if not intacto or any(v[0] != OK for v in res.values()):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
