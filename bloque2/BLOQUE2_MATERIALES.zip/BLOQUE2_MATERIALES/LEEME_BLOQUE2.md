# Bloque 2 · De datos dispersos a estadísticas fiables

El bloque es una progresión de **cinco retos**. Cada uno añade una dificultad al anterior:

| Reto | Carpeta | Qué haces | Dificultad nueva |
|---|---|---|---|
| 1 | `01_RETO_DOCUMENTACION/` | Reconciliar un Excel esperado con una carpeta real | dos fuentes |
| 2 | `02_RETO_MUESTRA_SINTETICA/` | Crear datos ficticios que conserven las propiedades necesarias | transformar una fuente |
| 3 | `03_RETO_DOS_CCAA/` | Automatizar el núcleo de un modelo manual de 2 CCAA (Madrid + Castilla y León) | combinar dos fuentes |
| 4 | `04_RETO_NORMALIZACION/` | Llevar cinco formatos distintos a una estructura común | tolerar estructuras distintas |
| 5 | `05_RETO_CAMPANA_ESTATAL/` | 12 + 5 CCAA → consolidado, estadísticas, nacional, gráficas y control de carga | escalar a 17 CCAA |
| extra | `90_BOLA_EXTRA_AUDITORIA/` | Automatizar también la revisión (auditor independiente, controles integrados) | **opcional** |

## Cómo está organizada cada carpeta

Todas siguen el mismo recorrido: **ENTRADAS → TRABAJO → RESUELTO**.

- `00_ENUNCIADO.md` — qué hay que hacer y cómo comprobarlo.
- `01_ENTRADAS/` — los archivos de partida. No se modifican.
- `02_TRABAJO/` — donde guardas tus scripts y tus salidas (en el Reto 5, `03_TRABAJO/`).
- `03_RESUELTO/` — la vía de desbloqueo (en el Reto 5, `04_RESUELTO/`):
  - un **prompt de referencia** (`PROMPT_REFERENCIA.txt` o `PROMPT_SOLUCION.txt`): cómo describir correctamente el problema a una IA. No promete el mismo script, sino una solución funcional equivalente;
  - un **script de referencia**;
  - la **salida esperada**.

Particularidades:

- Reto 3: `00_MODELO_MANUAL/MODELO_2_CCAA.xlsx` es el prototipo construido a mano que queremos automatizar. Es una referencia, no una entrada.
- Reto 5: `02_PUNTO_DE_PARTIDA/` contiene el primer hito (`PROMPT_PRIMER_HITO.txt` con los MENSAJES 1–5 de la conversación y `01_CONSOLIDAR_BASE.py`).

## Dependencias

```bat
py -3 -m pip install -r requirements.txt
```

Las soluciones de referencia usan `openpyxl` (y `pandas` en el Reto 1). La ampliación gráfica del Reto 1 puede usar `tkinter`.

Los scripts de referencia localizan sus entradas a partir de su propia ubicación: puedes ejecutarlos desde cualquier carpeta, por ejemplo `py -3 03_RESUELTO\combinar_2_ccaa.py` desde la carpeta del Reto 3.

## Tres ideas transversales

- No modifiques los originales: genera archivos nuevos o trabaja sobre copias.
- Que un script termine sin error no demuestra que el resultado sea correcto.
- Los problemas grandes se pueden dividir en piezas pequeñas, comprobables y reutilizables.
