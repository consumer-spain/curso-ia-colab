# Reto 3 · Automatizar un modelo de 2 CCAA

**Combinar dos fuentes:** Madrid + Castilla y León.

## Situación

En `00_MODELO_MANUAL/MODELO_2_CCAA.xlsx` tienes un **prototipo construido a mano**: los datos de Madrid y de Castilla y León, su consolidado, las estadísticas, el resultado conjunto y las gráficas. Es el destino conocido: así debería quedar.

**No es una entrada de datos.** Es una referencia de cómo debe quedar el resultado.

Ahora queremos automatizar su núcleo. Empezamos por las dos entradas de las que salió:

- `01_ENTRADAS/MADRID.xlsx` — 27 controles en cada pregunta;
- `01_ENTRADAS/CASTILLA_Y_LEON.xlsx` — 22 controles en cada pregunta.

## Regla de agregación

Para obtener el resultado conjunto, suma primero los recuentos Sí, No y No procede de las dos comunidades para cada pregunta y calcula los porcentajes después, sobre esos totales. No promedies los porcentajes autonómicos.

## Mini-práctica · combinar las dos comunidades

Crea un script que genere un archivo **nuevo** con 25 preguntas y los recuentos conjuntos `Sí`, `No`, `No procede` y `total`.

- localizar las 25 preguntas;
- sumar los recuentos de ambas CCAA pregunta a pregunta;
- cada pregunta aparece una sola vez;
- no modificar los originales;
- la pregunta 1 debe sumar 49 controles (27 + 22).

## Control 1 · caso pequeño conocido

Compara tu salida con `03_RESUELTO/RESULTADO_ESPERADO_2_CCAA.xlsx`, calculado de forma independiente: 25 preguntas, 49 controles en cada una, mismos recuentos.

## Control 2 · cambio controlado

`01_ENTRADAS/CAMBIO_CONTROLADO/MADRID_CAMBIO_CONTROLADO.xlsx` cambia **una sola cosa** en Madrid, pregunta 1:

- antes: Sí 12 · No 15 · NP 0;
- después: Sí 13 · No 14 · NP 0;
- total de Madrid: 27 → 27.

**Antes de ejecutar, predice** qué debe cambiar en la pregunta 1 del consolidado, qué debe permanecer igual y qué preguntas no deberían verse afectadas. Después ejecuta el script con el nuevo Madrid y compara con `03_RESUELTO/RESULTADO_ESPERADO_CAMBIO.xlsx`:

```bash
python 03_RESUELTO/combinar_2_ccaa.py --madrid 01_ENTRADAS/CAMBIO_CONTROLADO/MADRID_CAMBIO_CONTROLADO.xlsx --salida 02_TRABAJO/SALIDA_CAMBIO.xlsx
```

Resultado: la pregunta 1 conjunta pasa de 24 / 25 / 0 a 25 / 24 / 0; el total sigue en 49; las preguntas 2–25 no cambian.

## ¿Hemos reproducido el núcleo del modelo?

Compara tu consolidado con la hoja `CONSOLIDADO_2_CCAA` del modelo manual: las 25 preguntas deben coincidir (pregunta 1: 24 / 25 / 0; 49 controles en todas).

## Carpetas

- `00_MODELO_MANUAL/` — prototipo manual (referencia, no entrada).
- `01_ENTRADAS/` — Madrid, Castilla y León y el Madrid del cambio controlado.
- `02_TRABAJO/` — tu script y tus salidas.
- `03_RESUELTO/` — `PROMPT_REFERENCIA.txt`, `combinar_2_ccaa.py` (escribe `02_TRABAJO/CONSOLIDADO_2_CCAA_GENERADO.xlsx`), `RESULTADO_ESPERADO_2_CCAA.xlsx` y `RESULTADO_ESPERADO_CAMBIO.xlsx`.
