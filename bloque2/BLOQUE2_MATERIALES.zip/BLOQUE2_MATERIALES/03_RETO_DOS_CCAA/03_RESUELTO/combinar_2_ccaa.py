#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mini-práctica · combinar dos CCAA limpias.

Lee Madrid y Castilla y León, suma los recuentos pregunta a pregunta y genera
un libro nuevo con un consolidado de 25 preguntas. No modifica los originales.
"""
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path
from typing import Dict, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

RESPUESTAS = {"pregunta", "si", "no", "no procede"}


def norm(v: object) -> str:
    return "" if v is None else str(v).strip().lower().replace("í", "i")


def numero_pregunta(v: object) -> int | None:
    if v is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(v))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def encontrar_cabecera(ws) -> Tuple[int, Dict[str, int]]:
    for row in ws.iter_rows():
        cols: Dict[str, int] = {}
        for c in row:
            n = norm(c.value)
            if n in RESPUESTAS:
                cols[n] = c.column
        if RESPUESTAS.issubset(cols):
            return row[0].row, cols
    raise ValueError(f"No se encontró cabecera en {ws.title}")


def leer(path: Path) -> Dict[int, dict]:
    wb = load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    fila, cols = encontrar_cabecera(ws)
    out: Dict[int, dict] = {}
    for r in range(fila + 1, ws.max_row + 1):
        texto = ws.cell(r, cols["pregunta"]).value
        n = numero_pregunta(texto)
        if n is None:
            continue
        vals = []
        for k in ("si", "no", "no procede"):
            v = ws.cell(r, cols[k]).value
            if not isinstance(v, (int, float)) or isinstance(v, bool):
                raise ValueError(f"{path.name} · P{n} · {k}: se esperaba un número y se obtuvo {v!r}")
            vals.append(int(v))
        if n in out:
            raise ValueError(f"{path.name}: pregunta {n} duplicada")
        out[n] = {"pregunta": str(texto), "si": vals[0], "no": vals[1], "no_procede": vals[2]}
    if set(out) != set(range(1, 26)):
        raise ValueError(f"{path.name}: se esperaban preguntas 1–25 y se obtuvieron {sorted(out)}")
    return out


def huella(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def totales(datos: Dict[int, dict]) -> str:
    """Totales Sí + No + No procede por pregunta, resumidos (p. ej. "27" o "27, 28")."""
    vals = sorted({d["si"] + d["no"] + d["no_procede"] for d in datos.values()})
    return ", ".join(str(v) for v in vals)


def combinar(madrid: Path, cyl: Path, salida: Path) -> None:
    huellas_antes = {madrid: huella(madrid), cyl: huella(cyl)}
    a = leer(madrid)
    b = leer(cyl)
    wb = Workbook()
    ws = wb.active
    ws.title = "CONSOLIDADO_2_CCAA"
    ws.append(["numero_pregunta", "pregunta", "si", "no", "no_procede", "total"])
    combinadas: Dict[int, int] = {}
    for n in range(1, 26):
        if a[n]["pregunta"] != b[n]["pregunta"]:
            raise ValueError(f"P{n}: el texto de la pregunta difiere entre las dos entradas")
        si = a[n]["si"] + b[n]["si"]
        no = a[n]["no"] + b[n]["no"]
        np = a[n]["no_procede"] + b[n]["no_procede"]
        ws.append([n, a[n]["pregunta"], si, no, np, si + no + np])
        combinadas[n] = si + no + np

    # Controles CALCULADOS a partir de los datos (no escritos a mano).
    originales_modificados = any(huella(p) != h for p, h in huellas_antes.items())
    ctrl = wb.create_sheet("CONTROL")
    ctrl.append(["comprobacion", "resultado"])
    ctrl.append(["preguntas_generadas", len(combinadas)])
    ctrl.append(["preguntas_distintas_1_25", sorted(combinadas) == list(range(1, 26))])
    ctrl.append(["total_madrid_por_pregunta", totales(a)])
    ctrl.append(["total_castilla_y_leon_por_pregunta", totales(b)])
    ctrl.append(["total_conjunto_por_pregunta", ", ".join(str(v) for v in sorted(set(combinadas.values())))])
    ctrl.append(["originales_modificados", "SÍ" if originales_modificados else "NO"])

    for sheet in (ws, ctrl):
        for cell in sheet[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor="D9EAF7")
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.column_dimensions["A"].width = 16
    ws.column_dimensions["B"].width = 95
    for col in "CDEF":
        ws.column_dimensions[col].width = 14
    ctrl.column_dimensions["A"].width = 38
    ctrl.column_dimensions["B"].width = 28
    ws.freeze_panes = "A2"

    salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(salida)
    print("Proceso completado.")
    print(f"Preguntas combinadas: {len(combinadas)}")
    print(f"Total conjunto por pregunta: {', '.join(str(v) for v in sorted(set(combinadas.values())))}")
    print(f"Archivo creado: {salida}")


def main() -> None:
    reto = Path(__file__).resolve().parents[1]  # 03_RETO_DOS_CCAA
    entradas = reto / "01_ENTRADAS"
    parser = argparse.ArgumentParser(description="Combina Madrid y Castilla y León en un consolidado de 25 preguntas.")
    parser.add_argument("--madrid", type=Path, default=entradas / "MADRID.xlsx")
    parser.add_argument("--cyl", type=Path, default=entradas / "CASTILLA_Y_LEON.xlsx")
    parser.add_argument("--salida", type=Path, default=reto / "02_TRABAJO" / "CONSOLIDADO_2_CCAA_GENERADO.xlsx")
    args = parser.parse_args()
    combinar(args.madrid, args.cyl, args.salida)


if __name__ == "__main__":
    main()
