# Bloque 2 · De datos dispersos a estadísticas fiables

Este paquete sigue el recorrido actual del Bloque 2. Las actividades pequeñas son modulares: si el grupo necesita avanzar, puede abrirse la referencia y continuar desde la comprobación.

## Dependencias

```bat
py -3 -m pip install -r requirements.txt
```

Las soluciones de referencia usan `openpyxl`. La ampliación gráfica del primer reto puede usar `tkinter`.

## Recorrido

1. `01_reto_documentacion` — reconciliar un Excel con una carpeta y definir criterios antes de programar.
2. `02_muestra_sintetica` — crear una muestra ficticia que conserve las propiedades necesarias.
3. `03_modelo_2_ccaa` — reglas, caso pequeño conocido y controles independientes; incluye dos entradas limpias separadas, resultado esperado y cambio controlado.
4. `04_construccion_guiada` — conversación acumulada y primer hito operativo (`DATOS_CONSOLIDADOS` + `CONTROL_CARGA`).
5. `05_reto_gimnasios` — inventario real, variaciones, normalización de la estructura de los cinco pendientes (con comprobador independiente) y reto estatal de 17 CCAA.
6. `06_diagnostico_y_validacion` — auditar la salida: diagnosticar tipos, corregir con evidencia, cinco capas, micro-auditoría y auditor independiente (`auditar_salida.py`).
7. `07_ampliacion_cambio_controlado` — repetición opcional de la prueba de cambio controlado con Aragón sobre la herramienta completa.
8. `99_ayudas_y_referencias` — soluciones completas, salidas de referencia y prompts de apoyo.

## Tres ideas transversales

- No modifiques los originales: genera archivos nuevos o trabaja sobre copias.
- Que un script termine sin error no demuestra que el resultado sea correcto.
- Los problemas grandes se pueden dividir en piezas pequeñas, comprobables y reutilizables.
