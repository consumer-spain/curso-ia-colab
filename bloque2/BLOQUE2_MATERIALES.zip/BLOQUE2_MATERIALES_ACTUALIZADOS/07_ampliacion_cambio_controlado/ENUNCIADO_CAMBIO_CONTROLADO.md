# Ampliación opcional · repetir el cambio controlado sobre la herramienta completa

Esta actividad ya no forma parte del flujo principal. Repite, sobre la herramienta completa, la técnica aprendida en **CONTROLES** con el caso pequeño de Madrid + Castilla y León.

`ARAGON_CORREGIDO.xlsx` cambia únicamente la pregunta 1:

- antes: Sí 8 · No 10 · No procede 0;
- después: Sí 9 · No 9 · No procede 0;
- total: 18 → 18.

Antes de ejecutar, predice qué debe cambiar y qué debe permanecer igual. Trabaja sobre una copia y compara después con tu predicción.

Si aparecen a la vez `ARAGON.xlsx` y `ARAGON_CORREGIDO.xlsx`, una herramienta robusta debería señalar la ambigüedad en vez de elegir o sumar silenciosamente ambos.
