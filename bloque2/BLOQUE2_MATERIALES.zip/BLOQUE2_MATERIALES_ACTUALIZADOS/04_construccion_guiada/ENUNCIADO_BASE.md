# Primer hito · una base común

En esta iteración no buscamos todavía el informe final.

Objetivo mínimo:

- leer el libro con 12 CCAA y los cinco archivos pendientes;
- generar `DATOS_CONSOLIDADOS` conservando la trazabilidad de comunidad, archivo y hoja;
- generar `CONTROL_CARGA` para saber qué se ha utilizado y qué incidencias se han detectado;
- no modificar los originales.

Puedes partir de `01_CONSOLIDAR_BASE.py` o construir tu propia versión. El normalizador previo puede utilizarse como contexto, pero no es una dependencia obligatoria.
