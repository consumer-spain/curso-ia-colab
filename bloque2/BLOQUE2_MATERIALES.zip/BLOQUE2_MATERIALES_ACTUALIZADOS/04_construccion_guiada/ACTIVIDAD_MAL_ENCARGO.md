# Pregunta abierta · ¿basta con este encargo?

> Hazme un programa en Python que junte estos Excel, saque estadísticas y gráficas.

Ya sabemos que queremos convertir aportaciones autonómicas en una visión estatal reproducible.

Sin escribir todavía un prompt completo, piensa: **¿qué decisiones o información necesitaría una IA antes de escribir código?**

Durante el bloque iremos resolviendo ocho piezas: objetivo, estructura, restricciones, reglas, controles, resultado, archivos y variaciones.
