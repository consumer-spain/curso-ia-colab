# Las 8 piezas del encargo

No es una plantilla universal ni un “prompt mágico”. Es un mapa de las decisiones que hay que tomar para este problema.

1. **Objetivo** — ¿para qué quiero la herramienta?
2. **Estructura** — ¿qué significan mis datos?
3. **Restricciones** — ¿qué puedo hacer o compartir?
4. **Reglas** — ¿cómo debe calcularse?
5. **Controles** — ¿cómo demuestro que funciona?
6. **Resultado** — ¿qué debe entregar exactamente?
7. **Archivos** — ¿qué fuentes concretas procesa?
8. **Variaciones** — ¿qué diferencias debe tolerar?

En otros problemas el orden puede ser distinto. Lo importante es no obligar a la IA a adivinar decisiones que nosotros todavía no hemos tomado.
