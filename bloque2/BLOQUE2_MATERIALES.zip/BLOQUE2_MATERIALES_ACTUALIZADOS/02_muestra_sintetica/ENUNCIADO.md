# Mini-práctica · crear una muestra sintética

Partimos de `00_MADRID_SIMULADO_PARA_MUESTRA.xlsx`.

Genera un archivo **nuevo** que:

- conserve las mismas 25 preguntas;
- conserve los encabezados y la estructura útil;
- use cifras ficticias nuevas;
- use enteros no negativos;
- mantenga el mismo total por pregunta;
- no modifique el original.

## Prompt mínimo orientativo

> Tengo el archivo 00_MADRID_SIMULADO_PARA_MUESTRA.xlsx, con 25 preguntas y recuentos Sí / No / No procede. Escribe un script en Python que cree una COPIA nueva del archivo en la que: se conserven las 25 preguntas y la misma estructura de columnas; los recuentos se sustituyan por enteros no negativos generados al azar; el total Sí + No + No procede de cada pregunta sea el mismo que en el original. No modifiques el archivo original.

Después abre el resultado y comprueba que realmente conserva esas propiedades.

Referencia si te bloqueas: `generar_muestra_sintetica.py` y `REFERENCIA/MUESTRA_MADRID_PARA_IA.xlsx`.
