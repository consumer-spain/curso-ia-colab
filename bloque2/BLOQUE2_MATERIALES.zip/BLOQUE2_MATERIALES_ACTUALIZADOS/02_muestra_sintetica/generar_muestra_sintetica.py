#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bloque 2 · Generador de muestra sintética

Lee un Excel de ejemplo de Madrid, conserva la estructura útil de las 25 preguntas
 y genera un libro nuevo con recuentos ficticios coherentes. No modifica el original.
"""
from __future__ import annotations

import argparse
import random
import re
from pathlib import Path
from typing import Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

BLOQUES = {
    range(1, 6): "1. INFORMACIÓN NECESARIA EN LA OFERTA COMERCIAL",
    range(6, 15): "2. INFORMACIÓN PREVIA AL CONTRATO",
    range(15, 26): "3. CONTRATACIÓN, FACTURACIÓN Y CLÁUSULAS ABUSIVAS",
}


def numero_pregunta(texto: object) -> Optional[int]:
    if texto is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(texto))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def bloque_de_pregunta(n: int) -> str:
    for rg, nombre in BLOQUES.items():
        if n in rg:
            return nombre
    return ""


def encontrar_cabecera(ws) -> Tuple[int, dict]:
    """Devuelve fila de cabecera y mapa normalizado encabezado -> columna."""
    objetivos = {"pregunta", "si", "no", "no procede"}
    for row in ws.iter_rows():
        valores = {}
        for cell in row:
            if cell.value is None:
                continue
            norm = str(cell.value).strip().lower().replace("í", "i")
            if norm in objetivos:
                valores[norm] = cell.column
        if {"pregunta", "si", "no", "no procede"}.issubset(valores.keys()):
            return row[0].row, valores
    raise ValueError(f"No se encontró cabecera Pregunta/Sí/No/No procede en la hoja {ws.title}")


def generar_recuentos(total: int, originales: Tuple[int, int, int], rnd: random.Random) -> Tuple[int, int, int]:
    """Genera enteros ficticios no negativos que suman total y suelen diferir del original."""
    if total <= 0:
        return originales
    si, no, np = originales
    # Mantener No procede en 0 cuando en el original sea 0 para no crear categorías inexistentes en ese tramo de preguntas.
    if np == 0:
        nuevo_si = max(0, min(total, si + rnd.randint(-3, 3)))
        if nuevo_si == si and total > 1:
            nuevo_si = max(0, min(total, nuevo_si + 1 if nuevo_si < total else nuevo_si - 1))
        return nuevo_si, total - nuevo_si, 0
    # Variar con reparto ponderado cercano al original.
    pesos = [max(si, 1), max(no, 1), max(np, 1)]
    valores = [0, 0, 0]
    for _ in range(total):
        r = rnd.uniform(0, sum(pesos))
        acum = 0
        for i, p in enumerate(pesos):
            acum += p
            if r <= acum:
                valores[i] += 1
                break
    if tuple(valores) == originales and total > 2:
        # Pequeño intercambio para garantizar diferencia sin romper suma.
        i = 0 if valores[0] > 0 else 1
        j = 1 if i == 0 else 2
        valores[i] -= 1
        valores[j] += 1
    return tuple(valores)  # type: ignore[return-value]


def crear_muestra(entrada: Path, salida: Path, seed: int = 42) -> None:
    rnd = random.Random(seed)
    wb_in = load_workbook(entrada, data_only=True)
    ws_in = wb_in[wb_in.sheetnames[0]]
    header_row, cols = encontrar_cabecera(ws_in)

    wb_out = Workbook()
    ws = wb_out.active
    ws.title = "MUESTRA_MADRID"

    # Títulos sintéticos. No copiamos propiedades ni hojas ocultas/comentarios/macros.
    ws.append(["Muestra sintética para explicar estructura a una IA", None, None, None])
    ws.append(["Campaña recreada: gimnasios. Datos ficticios.", None, None, None])
    ws.append(["PRODUCTO: R9313 - Servicios de gimnasios", None, None, None])
    ws.append([None, None, None, None])
    ws.append(["Pregunta", "Sí", "No", "No procede"])

    preguntas_procesadas = 0
    sumas_correctas = 0
    bloques_insertados = set()

    for row in range(header_row + 1, ws_in.max_row + 1):
        texto = ws_in.cell(row, cols["pregunta"]).value
        n = numero_pregunta(texto)
        if n is None:
            continue
        bloque = bloque_de_pregunta(n)
        if bloque and bloque not in bloques_insertados:
            ws.append([bloque, None, None, None])
            bloques_insertados.add(bloque)
        vals = [ws_in.cell(row, cols[c]).value for c in ["si", "no", "no procede"]]
        try:
            originales = tuple(int(v) for v in vals)  # type: ignore[arg-type]
        except Exception as exc:
            raise ValueError(f"La pregunta {n} no contiene tres enteros válidos: {vals}") from exc
        total = sum(originales)
        nuevos = generar_recuentos(total, originales, rnd)
        if sum(nuevos) != total or any(v < 0 for v in nuevos):
            raise RuntimeError(f"Recuento sintético incoherente en pregunta {n}: {nuevos} vs total {total}")
        preguntas_procesadas += 1
        sumas_correctas += 1
        ws.append([texto, *nuevos])

    if preguntas_procesadas != 25:
        raise RuntimeError(f"Se esperaban 25 preguntas y se han procesado {preguntas_procesadas}")

    # Formato básico.
    header_fill = PatternFill("solid", fgColor="D9EAF7")
    thin = Side(style="thin", color="BFBFBF")
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=thin)
    for cell in ws[5]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
    for row in range(1, ws.max_row + 1):
        val = ws.cell(row, 1).value
        if isinstance(val, str) and val.startswith(("1. ", "2. ", "3. ")):
            ws.cell(row, 1).font = Font(bold=True)
            ws.cell(row, 1).fill = PatternFill("solid", fgColor="E2F0D9")
    widths = {"A": 95, "B": 10, "C": 10, "D": 14}
    for col, width in widths.items():
        ws.column_dimensions[col].width = width
    for i in range(1, ws.max_row + 1):
        ws.row_dimensions[i].height = 18
    ws.freeze_panes = "A6"

    # Hoja de comprobación.
    ctrl = wb_out.create_sheet("COMPROBACION")
    ctrl.append(["comprobacion", "resultado"])
    ctrl.append(["preguntas_procesadas", preguntas_procesadas])
    ctrl.append(["sumas_correctas", sumas_correctas])
    ctrl.append(["archivo_original", str(entrada.name)])
    ctrl.append(["archivo_creado", str(salida.name)])
    for cell in ctrl[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
    ctrl.column_dimensions["A"].width = 28
    ctrl.column_dimensions["B"].width = 80

    salida.parent.mkdir(parents=True, exist_ok=True)
    wb_out.save(salida)
    print("Proceso completado.")
    print(f"25 preguntas procesadas: {preguntas_procesadas == 25}")
    print(f"25 sumas comprobadas correctamente: {sumas_correctas == 25}")
    print(f"Archivo creado: {salida}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Genera una muestra sintética a partir del Excel de Madrid.")
    parser.add_argument("--entrada", default="00_MADRID_SIMULADO_PARA_MUESTRA.xlsx", help="Excel de entrada")
    parser.add_argument("--salida", default="MUESTRA_MADRID_PARA_IA.xlsx", help="Excel de salida")
    parser.add_argument("--seed", type=int, default=42, help="Semilla para obtener resultados reproducibles")
    args = parser.parse_args()
    crear_muestra(Path(args.entrada), Path(args.salida), args.seed)


if __name__ == "__main__":
    main()
