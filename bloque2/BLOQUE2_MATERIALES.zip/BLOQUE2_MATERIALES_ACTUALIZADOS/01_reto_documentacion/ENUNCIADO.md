# Reto 1 · Comprobar la documentación de un expediente

## Situación

Tienes:

- un Excel con la documentación que debería existir;
- una carpeta con los archivos que existen realmente;
- y puede haber subcarpetas.

El objetivo es construir una herramienta que compare ambas fuentes y genere un Excel nuevo con el resultado.

## Criterios que debe cumplir

Para cada fila del Excel debe indicar:

- `Encontrado` — el archivo existe;
- `No encontrado` — debería existir, pero no está;
- `Sin nombre indicado` — la fila no especifica un archivo.

Además debe:

- buscar también dentro de subcarpetas;
- detectar archivos presentes en la carpeta pero no registrados en el Excel;
- crear una hoja `Sin registrar`;
- generar un Excel nuevo;
- preservar el Excel y las imágenes originales.

## Material

- `MATERIAL/listado_inspeccion.xlsx`
- `MATERIAL/imagenes/`

## Si te bloqueas o terminas pronto

En `AYUDAS_Y_REFERENCIAS` tienes prompts y soluciones posibles. La interfaz gráfica es una ampliación opcional: no es necesaria para completar el reto.
