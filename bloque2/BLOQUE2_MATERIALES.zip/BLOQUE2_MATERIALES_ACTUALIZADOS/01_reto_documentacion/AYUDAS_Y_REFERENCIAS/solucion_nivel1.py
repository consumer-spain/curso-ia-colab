from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


EXTENSIONES_ADMITIDAS = {".jpg", ".jpeg", ".png", ".webp"}


def normalizar_nombre(valor: object) -> str | None:
    """Convierte una celda del Excel en un nombre de archivo utilizable."""
    if pd.isna(valor):
        return None
    nombre = str(valor).strip()
    return nombre or None


def indexar_archivos(carpeta: Path) -> tuple[dict[str, list[Path]], list[Path]]:
    """Crea un índice por nombre, buscando también dentro de subcarpetas."""
    todos = sorted(
        ruta
        for ruta in carpeta.rglob("*")
        if ruta.is_file() and ruta.suffix.lower() in EXTENSIONES_ADMITIDAS
    )
    indice: dict[str, list[Path]] = {}
    for ruta in todos:
        indice.setdefault(ruta.name.casefold(), []).append(ruta)
    return indice, todos


def comprobar_documentacion(excel: Path, carpeta: Path, salida: Path) -> dict[str, int]:
    if not excel.exists():
        raise FileNotFoundError(f"No se encuentra el Excel: {excel}")
    if not carpeta.is_dir():
        raise NotADirectoryError(f"No se encuentra la carpeta: {carpeta}")

    datos = pd.read_excel(excel, sheet_name="Documentacion")
    columna = "nombre_archivo"
    if columna not in datos.columns:
        raise KeyError(
            f"El Excel debe contener la columna '{columna}'. "
            f"Columnas disponibles: {list(datos.columns)}"
        )

    indice, archivos_carpeta = indexar_archivos(carpeta)
    nombres_registrados: set[str] = set()
    estados: list[str] = []
    rutas: list[str] = []

    for valor in datos[columna]:
        nombre = normalizar_nombre(valor)
        if nombre is None:
            estados.append("Sin nombre indicado")
            rutas.append("")
            continue

        clave = nombre.casefold()
        nombres_registrados.add(clave)
        coincidencias = indice.get(clave, [])

        if coincidencias:
            estados.append("Encontrado")
            rutas.append(str(coincidencias[0].relative_to(carpeta)))
        else:
            estados.append("No encontrado")
            rutas.append("")

    resultado = datos.copy()
    resultado["estado"] = estados
    resultado["ruta_encontrada"] = rutas

    sin_registrar = [
        {
            "nombre_archivo": ruta.name,
            "ruta": str(ruta.relative_to(carpeta)),
        }
        for ruta in archivos_carpeta
        if ruta.name.casefold() not in nombres_registrados
    ]

    salida.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(salida, engine="openpyxl") as escritor:
        resultado.to_excel(escritor, sheet_name="Comprobacion", index=False)
        pd.DataFrame(sin_registrar, columns=["nombre_archivo", "ruta"]).to_excel(
            escritor, sheet_name="Sin registrar", index=False
        )

    return {
        "encontrados": estados.count("Encontrado"),
        "no_encontrados": estados.count("No encontrado"),
        "sin_nombre": estados.count("Sin nombre indicado"),
        "sin_registrar": len(sin_registrar),
    }


def parse_args() -> argparse.Namespace:
    carpeta_script = Path(__file__).resolve().parent
    reto = carpeta_script.parent
    material = reto / "MATERIAL"

    parser = argparse.ArgumentParser(description="Comprueba un Excel frente a una carpeta.")
    parser.add_argument("--excel", type=Path, default=material / "listado_inspeccion.xlsx")
    parser.add_argument("--carpeta", type=Path, default=material / "imagenes")
    parser.add_argument(
        "--salida", type=Path, default=reto / "SALIDAS" / "resultado_comprobacion.xlsx"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    resumen = comprobar_documentacion(args.excel, args.carpeta, args.salida)
    print("Comprobación terminada.")
    print(f"Resultado: {args.salida.resolve()}")
    print(
        "Resumen: "
        f"{resumen['encontrados']} encontrados, "
        f"{resumen['no_encontrados']} ausentes, "
        f"{resumen['sin_nombre']} sin nombre y "
        f"{resumen['sin_registrar']} sin registrar."
    )


if __name__ == "__main__":
    main()
