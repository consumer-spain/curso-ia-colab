#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mini-práctica · normalizar la ESTRUCTURA de los cinco archivos pendientes.

Lleva Aragón, Asturias, Galicia, Murcia y Comunitat Valenciana a una estructura
común de 25 filas (Pregunta | Sí | No | No procede) sin modificar los originales.

Separación deliberada de responsabilidades:
- resuelve diferencias de ESTRUCTURA (posición de la tabla, filas vacías,
  orden de las columnas, elementos ajenos);
- NO valida ni corrige el CONTENIDO: copia cada valor tal como llega, con su
  tipo original (no convierte texto a número ni sustituye valores).
"""
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

OBJETIVOS = {"pregunta", "si", "no", "no procede"}
ARCHIVOS = ["ARAGON.xlsx", "ASTURIAS.xlsx", "GALICIA.xlsx", "MURCIA.xlsx", "COMUNITAT_VALENCIANA.xlsx"]


def norm(v: Any) -> str:
    return "" if v is None else str(v).strip().lower().replace("í", "i").replace("  ", " ")


def numero_pregunta(v: Any) -> Optional[int]:
    if v is None:
        return None
    m = re.match(r"\s*(\d{1,2})\s*-", str(v))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 25 else None


def encontrar_cabecera(ws) -> Optional[Tuple[int, Dict[str, int]]]:
    for row in ws.iter_rows():
        cols: Dict[str, int] = {}
        for c in row:
            n = norm(c.value)
            if n in OBJETIVOS:
                cols[n] = c.column
        if OBJETIVOS.issubset(cols):
            return row[0].row, cols
    return None


def comunidad(ws, fallback: str) -> str:
    for row in ws.iter_rows(min_row=1, max_row=min(5, ws.max_row), values_only=True):
        for v in row:
            if isinstance(v, str) and "—" in v:
                return v.split("—")[-1].strip()
    return ws.title or fallback


def extraer(path: Path) -> tuple[str, list[list[Any]]]:
    wb = load_workbook(path, data_only=True)
    candidatos = []
    for ws in wb.worksheets:
        cab = encontrar_cabecera(ws)
        if cab is None:
            continue
        fila, cols = cab
        preguntas: Dict[int, list[Any]] = {}
        for r in range(fila + 1, ws.max_row + 1):
            texto = ws.cell(r, cols["pregunta"]).value
            n = numero_pregunta(texto)
            if n is None:
                continue
            if n in preguntas:
                raise ValueError(f"{path.name} · {ws.title}: pregunta {n} duplicada")
            preguntas[n] = [
                str(texto),
                ws.cell(r, cols["si"]).value,
                ws.cell(r, cols["no"]).value,
                ws.cell(r, cols["no procede"]).value,
            ]
        if preguntas:
            candidatos.append((ws, preguntas))
    if len(candidatos) != 1:
        raise ValueError(f"{path.name}: se esperaba una única tabla de datos y se encontraron {len(candidatos)}")
    ws, preguntas = candidatos[0]
    if set(preguntas) != set(range(1, 26)):
        raise ValueError(f"{path.name}: preguntas detectadas {sorted(preguntas)}; se esperaban 1–25")
    filas = [preguntas[n] for n in range(1, 26)]
    return comunidad(ws, path.stem), filas


def guardar(nombre_comunidad: str, filas: list[list[Any]], salida: Path, original_modificado: bool, origen: str, huella: str) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "DATOS"
    ws.append(["Pregunta", "Sí", "No", "No procede"])
    for row in filas:
        ws.append(row)
    for c in ws[1]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="D9EAF7")
    for row in ws.iter_rows():
        for c in row:
            c.alignment = Alignment(vertical="top", wrap_text=True)
    ws.column_dimensions["A"].width = 95
    for col in ("B", "C", "D"):
        ws.column_dimensions[col].width = 14
    ws.freeze_panes = "A2"
    meta = wb.create_sheet("CONTROL")
    meta.append(["campo", "valor"])
    meta.append(["comunidad", nombre_comunidad])
    meta.append(["preguntas_exportadas", len(filas)])
    meta.append(["estructura", "Pregunta | Sí | No | No procede"])
    meta.append(["archivo_origen", origen])
    meta.append(["huella_original_sha256", huella])
    meta.append(["original_modificado", "SÍ" if original_modificado else "NO"])
    meta.append(["valores", "copiados tal como llegan, sin convertir tipos"])
    for c in meta[1]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="D9EAF7")
    meta.column_dimensions["A"].width = 28
    meta.column_dimensions["B"].width = 50
    salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(salida)


def main() -> None:
    here = Path(__file__).resolve().parent
    reto = here.parent
    parser = argparse.ArgumentParser(description="Normaliza la estructura de los cinco archivos pendientes (sin convertir tipos).")
    parser.add_argument("--entrada", type=Path, default=reto / "CCAA_PENDIENTES")
    parser.add_argument("--salida", type=Path, default=here / "SALIDAS_NORMALIZADAS")
    args = parser.parse_args()
    args.salida.mkdir(parents=True, exist_ok=True)
    for nombre in ARCHIVOS:
        src = args.entrada / nombre
        if not src.exists():
            raise FileNotFoundError(src)
        antes = hashlib.sha256(src.read_bytes()).hexdigest()
        comunidad_nombre, filas = extraer(src)
        out = args.salida / f"{src.stem}_NORMALIZADO.xlsx"
        guardar(comunidad_nombre, filas, out, hashlib.sha256(src.read_bytes()).hexdigest() != antes, nombre, antes)
        print(f"{nombre}: 25 preguntas → {out.name}")
    print(f"Proceso completado: {len(ARCHIVOS)} archivos normalizados.")


if __name__ == "__main__":
    main()
