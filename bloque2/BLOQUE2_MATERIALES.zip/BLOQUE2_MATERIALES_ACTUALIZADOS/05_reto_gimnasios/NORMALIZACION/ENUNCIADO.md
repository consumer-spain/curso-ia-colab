# Mini-práctica · normalizar las entradas

Trabaja con los cinco archivos pendientes de `../CCAA_PENDIENTES/`:

- `ARAGON.xlsx`
- `ASTURIAS.xlsx`
- `GALICIA.xlsx`
- `MURCIA.xlsx`
- `COMUNITAT_VALENCIANA.xlsx`

## Objetivo

Crear copias nuevas con una estructura común:

`Pregunta | Sí | No | No procede`

25 preguntas por archivo.

## El script debe

- localizar la tabla por sus encabezados, no por coordenadas fijas;
- identificar las columnas por nombre, no por posición;
- localizar las preguntas 1–25 aunque haya filas vacías;
- ignorar filas, hojas o elementos que no pertenezcan a esa estructura;
- crear nuevas copias normalizadas en `SALIDAS_NORMALIZADAS/`;
- conservar exactamente los valores originales, con su tipo: **no convierte tipos ni corrige valores**;
- no modificar los originales.

Normalizar resuelve la **estructura**. No valida ni corrige el **contenido**.

No generes todavía estadísticas, consolidado ni gráficas.

Prompt sugerido: `PROMPTS_NORMALIZACION.txt` (primer prompt). Referencia: `normalizar_entradas.py`.

## Después: ¿hemos perdido o cambiado algo?

Construye un comprobador independiente (segundo prompt de `PROMPTS_NORMALIZACION.txt`). Referencia: `comprobar_normalizacion.py`, que genera `CONTROL_NORMALIZACION.xlsx` con una fila por archivo y estado OK / REVISAR.

Un OK en este control significa que la normalización **no ha perdido ni alterado datos**. No significa todavía que todos los valores sean utilizables para calcular: esa es otra pregunta.

Salidas de referencia: `REFERENCIA/NORMALIZADOS/` (5 archivos) y `REFERENCIA/CONTROL_NORMALIZACION.xlsx`.
