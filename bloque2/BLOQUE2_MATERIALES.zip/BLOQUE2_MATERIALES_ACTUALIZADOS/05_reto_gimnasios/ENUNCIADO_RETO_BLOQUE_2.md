# Reto · campaña estatal de gimnasios

## Situación

Doce CCAA ya están integradas en un libro y cinco llegan como archivos pendientes. El modelo de dos CCAA es una **referencia**, no una entrada.

## Entradas

- `02_BASE_12_CCAA_INTEGRADAS.xlsx`
- `CCAA_PENDIENTES/ARAGON.xlsx`
- `CCAA_PENDIENTES/ASTURIAS.xlsx`
- `CCAA_PENDIENTES/GALICIA.xlsx`
- `CCAA_PENDIENTES/MURCIA.xlsx`
- `CCAA_PENDIENTES/COMUNITAT_VALENCIANA.xlsx`

Referencia funcional: `../03_modelo_2_ccaa/01_MODELO_REFORZADO_2_CCAA.xlsx`.

Primera base: `../04_construccion_guiada/01_CONSOLIDAR_BASE.py`.

El normalizador de `NORMALIZACION/` (cubre los cinco pendientes) puede reutilizarse como contexto, pero no es una dependencia obligatoria. Recuerda que solo normaliza la estructura: no convierte ni valida valores.

## GENERA

Crea un libro con:

- `DATOS_CONSOLIDADOS` — 425 registros;
- `ESTADISTICAS_CCAA`;
- `NACIONAL` por pregunta y resumen por bloque;
- cuatro gráficas nacionales;
- `CONTROL_CARGA`.

## AUDITA

Antes de darlo por terminado, comprueba al menos:

- 17 CCAA;
- 25 preguntas por CCAA;
- 425 combinaciones comunidad-pregunta;
- valores numéricamente válidos;
- `Sí + No + No procede = realizados`;
- ninguna comunidad omitida;
- nacional calculado sumando recuentos y recalculando porcentajes.

## ESCALA · opcional

Solo después de validar:

- gráficas por CCAA;
- ranking de preguntas;
- índice;
- registro de incidencias;
- controles adicionales.

## Regla de seguridad

No modifiques, renombres ni sobrescribas los archivos originales. Genera salidas nuevas.
