# Mini-práctica · combinar dos comunidades

Trabaja solo con las entradas limpias de `ENTRADAS_LIMPIAS/`:

- `MADRID.xlsx`
- `CASTILLA_Y_LEON.xlsx`

Crea un script que genere un archivo **nuevo** con 25 preguntas y los recuentos conjuntos `Sí`, `No`, `No procede` y `total`.

## Criterios

- localizar las 25 preguntas;
- sumar los recuentos de ambas CCAA pregunta a pregunta;
- cada pregunta aparece una sola vez;
- no modificar los originales;
- la pregunta 1 debe sumar 49 controles (27 + 22).

Cuando termines, compara tu salida con `RESULTADO_ESPERADO_2_CCAA.xlsx`. La referencia `combinar_2_ccaa.py` está disponible si te bloqueas.
