# Control 2 · cambio controlado

Ya sabemos que el mini-script combina correctamente Madrid y Castilla y León. Ahora comprobamos qué ocurre cuando cambia **una sola cosa**.

Usa `MADRID_CAMBIO_CONTROLADO.xlsx` en lugar de `MADRID.xlsx`.

Cambio introducido en la pregunta 1:

- antes: Sí 12 · No 15 · NP 0;
- después: Sí 13 · No 14 · NP 0;
- total de Madrid: 27 → 27.

## Antes de ejecutar, predice

1. Qué debe cambiar en la pregunta 1 del consolidado.
2. Qué debe permanecer igual.
3. Qué preguntas no deberían verse afectadas.

Después ejecuta de nuevo `combinar_2_ccaa.py` indicando el nuevo Madrid y compara con `RESULTADO_ESPERADO_CAMBIO.xlsx`.

Ejemplo:

```bash
python combinar_2_ccaa.py --madrid CAMBIO_CONTROLADO/MADRID_CAMBIO_CONTROLADO.xlsx --salida CAMBIO_CONTROLADO/SALIDA_CAMBIO.xlsx
```

Esta técnica permite comprobar que una modificación produce exactamente los efectos esperados y ningún otro.
