# Diagnóstico y validación

Este tramo se realiza después del reto completo: el programa ha terminado y ahora **auditamos la salida**.

## 1. Diagnosticar sin corregir

Si una comunidad aparece con preguntas detectadas pero sin valores válidos, no reescribas el programa a ciegas. Usa el PROMPT 1 de `PROMPTS_DIAGNOSTICO_Y_CORRECCION.txt` o ejecuta `diagnosticar_tipos.py`.

El script de diagnóstico solo observa tipos; no modifica archivos.

## 2. Corregir de forma limitada

Cuando la evidencia identifica la causa, utiliza el PROMPT 2. Los valores no convertibles deben registrarse como incidencia; nunca convertirse silenciosamente en cero.

## 3. Construir un auditor independiente

Con el PROMPT 3, pide un **segundo programa** que reciba el Excel generado y lo audite en cinco capas (cobertura, tipo / interpretación, coherencia, reconciliación y lógica) sin modificarlo. Referencia: `auditar_salida.py`.

```bash
python auditar_salida.py                         # audita 05_reto_gimnasios/SALIDAS/SOLUCION_COMPLETA_17_CCAA.xlsx
python auditar_salida.py --entrada <tu_salida.xlsx>
```

Informa OK / REVISAR / NO EVALUABLE por capa y escribe `SALIDAS/AUDITORIA_SALIDA.txt`.

## 4. Ampliación · reforzar los controles integrados

Con el PROMPT 4, la propia herramienta deja constancia de qué ha comprobado mientras trabaja. Es complementario del auditor, no lo sustituye. Referencia: `99_ayudas_y_referencias/03_SOLUCION_CONTROLES_REFORZADOS.py`, que amplía `CONTROL_CARGA` y añade la hoja `COMPROBACIONES` con las cinco capas, sin cambiar las reglas de cálculo.
