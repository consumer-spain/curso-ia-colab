# Micro-auditoría · ambos pasan los primeros controles

Dos informes tienen:

- 17 CCAA;
- 425 registros;
- 425 registros numéricamente válidos;
- 351 controles en la pregunta 15;
- los mismos recuentos: Sí 154 · No 23 · No procede 174.

## Informe A

- Sí: 44,7 %
- No: 6,2 %
- No procede: 49,1 %

## Informe B

- Sí: 43,9 %
- No: 6,6 %
- No procede: 49,6 %

**Pregunta:** ¿cuál firmarías? ¿Qué comprobación falta para decidirlo?
