# Cinco capas de validación

Un único “OK” no demuestra que el resultado sea correcto.

1. **Cobertura** — ¿Está todo lo que esperaba? Ej.: 17 CCAA, 425 registros, 25 preguntas por CCAA.
2. **Tipo / interpretación** — ¿He entendido correctamente cada dato? Ej.: `12` número frente a `'12'` texto.
3. **Coherencia** — ¿Se cumplen las relaciones internas? Ej.: `Sí + No + No procede = realizados`.
4. **Reconciliación** — ¿El agregado coincide con un control independiente? Ej.: 49 controles en el caso pequeño; 351 por pregunta en el conjunto de este ejercicio.
5. **Lógica** — ¿Estoy calculando realmente lo que quería? Ej.: sumar recuentos antes de calcular porcentajes; no promediar porcentajes autonómicos.

Las capas son complementarias: superar una no sustituye a las demás.

Ejemplo del propio bloque: Comunitat Valenciana parecía estructuralmente normal, el normalizador la procesó y `CONTROL_NORMALIZACION` dio OK. Todo eso era correcto: ese control solo responde a «¿hemos alterado los datos al normalizar?». Su problema estaba en otra capa: tipo / interpretación.

`auditar_salida.py` automatiza las cinco capas como un programa independiente que revisa la salida sin modificarla.
