# Referencias de diagnóstico

- `diagnostico_tipos.csv` es la salida esperada de `diagnosticar_tipos.py` con los materiales de este paquete.
- La anomalía relevante se observa como 75 celdas de `texto_numerico` en Comunitat Valenciana y 75 celdas numéricas en las demás CCAA.

La referencia sirve para comparar; el script no modifica ningún archivo de entrada.
